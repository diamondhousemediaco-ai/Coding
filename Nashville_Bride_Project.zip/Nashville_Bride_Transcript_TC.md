# NASHVILLE BRIDE — Episode "The Yes Dress" (Sarah & Garrison)
## Verbatim Transcript — EXACT (for DaVinci script / text-based editing)

> This file is an exact, unaltered reproduction of the source transcript: original timecodes,
> original ASR speaker labels (Speaker N), and verbatim text. No merging, no name guesses, no edits.
> For best-guess speaker identities, see the companion file: Nashville_Bride_SpeakerID_Worksheet.md

---

[01:00:00:06 - 01:00:00:09]
Speaker 2
 Sorry

[01:00:02:13 - 01:00:04:04]
Speaker 2
 I had to do y'all like that. That's gay.

[01:00:05:12 - 01:00:08:09]
Speaker 2
 So pick the ball you need to touch paddles.

[01:00:09:21 - 01:00:11:19]
Speaker 2
 Yeah, yeah, yeah, yeah.

[01:00:11:19 - 01:00:14:13]
Speaker 6
 I get a little pick from the girls. Yeah, thank you, Dawn, for teaching me.

[01:00:14:13 - 01:00:15:07]
Speaker 2
 Y'all had fun?

[01:00:15:07 - 01:00:17:19]
Speaker 6
 Yes. I love pickle ball. Oh yeah. Alright, let's go. Yeah.

[01:00:17:19 - 01:00:20:06]
Speaker 2
 So are you guys excited about our bride next week?

[01:00:20:06 - 01:00:23:12]
Speaker 6
 Super excited. I cannot wait. She seems really nice.

[01:00:23:12 - 01:00:24:14]
Speaker 2
 Yeah, do you guys get the email?

[01:00:24:14 - 01:00:26:19]
Speaker 6
 The beach wedding. Sarah. Sarah.

[01:00:26:19 - 01:00:29:00]
Speaker 2
 Yep. And her fiance's name is Garrison.

[01:00:29:00 - 01:00:29:15]
Speaker 6
 Garrison.

[01:00:29:15 - 01:00:30:03]
Speaker 2
 Yep.

[01:00:30:03 - 01:00:31:04]
Speaker 2
 picked her dresses.

[01:00:31:04 - 01:00:36:04]
Speaker 2
 And so I guess the plan is we can meet at the rooftop.

[01:00:36:04 - 01:00:38:06]
Speaker 2
 at the bottom line. You can count that address.

[01:00:38:06 - 01:00:38:21]
Speaker 6
 Okay.

[01:00:38:21 - 01:00:48:02]
Speaker 2
 And then I actually have a model coming. She's going to model the dresses first. Nice. Okay, that's fun. And then we all sit on some champagne, relax.

[01:00:48:02 - 01:00:53:10]
Speaker 2
 we're gonna sip some champagne. Look at some dresses. See what we do. You want them to

[01:00:53:10 - 01:00:55:03]
Speaker 6
 convince us to be there. Yeah,

[01:00:55:03 - 01:00:57:09]
Speaker 6
 Sold. Y'all sold? Sold. Yeah,

[01:00:57:09 - 01:01:00:21]
Speaker 6
 Wedding dresses. Nashville silhouette

[01:01:00:21 - 01:01:02:23]
Speaker 2
 in the background. It's gonna be a good time.

[01:01:02:23 - 01:01:07:10]
Speaker 2
 More than anything, I appreciate y'all for being here with me. Celebrating this, like, awesome moment.

[01:01:07:10 - 01:01:09:00]
Speaker 2
 You guys are a blessing, like,

[01:01:10:01 - 01:01:20:23]
Speaker 2
 You know, like, something I've always wanted to do is just give back. And we all know there's a lot of brides out there that just can't afford to get married. You know, they can't afford the dress. It's like the first piece to the puzzle. And so, you guys are amazing.

[01:01:20:23 - 01:01:22:18]
Speaker 2
 Y'all are like my best friends.

[01:01:22:18 - 01:01:27:06]
Speaker 6
 Aww, you're so sweet. Aww. You're creepy.

[01:01:29:00 - 01:01:31:03]
Speaker 6
 Alright, girls. Yeah, we need to do this again.

[01:01:31:03 - 01:01:31:19]
Speaker 2
 We got to do it again.

[01:01:31:19 - 01:01:33:18]
Speaker 15
 I

[01:01:35:13 - 01:01:42:18]
Speaker 19
 love it. Thank you for taking me. I literally have never been there before. Ever. I love that dress that you're on. I can't wait to put that on.

[01:01:42:18 - 01:01:43:03]
Speaker 15
 Oh my God.

[01:01:43:03 - 01:01:47:17]
Speaker 19
 You tell

[01:01:49:18 - 01:01:50:18]
Speaker 19
 me about all the time.

[01:01:53:13 - 01:01:54:20]
Speaker 15
 That's right downtown.

[01:01:55:23 - 01:01:56:06]
Speaker 15
 Okay.

[01:02:00:17 - 01:02:01:14]
Speaker 19
 That's right. That's right.

[01:02:02:23 - 01:02:08:23]
Speaker 19
 I'm over here asking you what's your favorite spot is? I don't even know anything about it. But one thing I could do is have more.

[01:02:10:11 - 01:02:11:15]
Speaker 19
 Perceptive. Yeah.

[01:02:13:00 - 01:02:13:21]
Speaker 19
 Lunch at our age.

[01:02:15:12 - 01:02:16:23]
Speaker 19
 Oh, yeah. The Kalamar.

[01:02:23:06 - 01:02:24:11]
Speaker 15
 Oh, yeah.

[01:02:24:11 - 01:02:29:15]
Speaker 19
 Thank you. I

[01:02:32:03 - 01:02:32:15]
Speaker 15
 don't know.

[01:02:36:02 - 01:02:36:22]
Speaker 19
 It's the Pennsylvania.

[01:02:36:22 - 01:02:38:13]
Speaker 15
 I

[01:02:39:23 - 01:02:42:17]
Speaker 15
 need to get the girl. Oh,

[01:02:44:01 - 01:02:48:16]
Speaker 15
 yeah. They're so well behaved. You've only seen them really on my Instagram. Right.

[01:02:50:17 - 01:02:50:23]
Speaker 19
 Like

[01:02:52:21 - 01:02:54:04]
Speaker 19
 the show. Like the show.

[01:02:55:19 - 01:02:59:07]
Speaker 15
 I need to get that little. They

[01:03:01:09 - 01:03:02:03]
Speaker 15
 don't love wearing.

[01:03:03:04 - 01:03:03:11]
Speaker 19
 The weather.

[01:03:05:09 - 01:03:06:17]
Speaker 19
 Oh, yeah.

[01:03:09:18 - 01:03:11:19]
Speaker 15
 Coming from Toronto. I'm loving this weather.

[01:03:11:19 - 01:03:13:23]
Speaker 19
 Okay.

[01:03:15:12 - 01:03:17:21]
Speaker 19
 We did it. Once I came down here.

[01:03:19:03 - 01:03:22:04]
Speaker 19
 I can do this. I can do this. Yeah.

[01:03:22:04 - 01:03:23:11]
Speaker 15
 I'm with you on that.

[01:03:24:17 - 01:03:30:02]
Speaker 15
 And it pulls down a little bit. And the girls love it.

[01:03:31:23 - 01:03:32:09]
Speaker 15
 How

[01:03:33:10 - 01:03:36:14]
Speaker 19
 long do you plan to be here? What's your next? What's your next?

[01:03:36:14 - 01:03:44:15]
Speaker 15
 I don't know. So I've been here what a month now. Okay. Probably like. I don't know. At least until the end of the year.

[01:03:44:15 - 01:03:52:16]
Speaker 19
 I'm going to give it a year. I'm enjoying. Yeah. I'm going to see what's going on. Exactly. And now that we do this. I'm really excited to see where it's going. Kind of go.

[01:03:52:16 - 01:03:56:08]
Speaker 15
 Exactly. Now. I'm loving being at the store.

[01:03:56:08 - 01:03:59:13]
Speaker 19
 It's really fun. It's such a cool opportunity.

[01:04:01:01 - 01:04:07:10]
Speaker 19
 It's really cool. How people. Yeah. It's nothing I would have ever like imagined doing at this point, but it's cool that we're doing it now.

[01:04:07:10 - 01:04:15:11]
Speaker 15
 Yeah. I'm having a lot of fun. So I can't wait to see, you know, who else we can help. I love seeing all the dresses that Dom picked out there.

[01:04:15:11 - 01:04:23:23]
Speaker 19
 Right. And I'm excited to meet you girls. Like you and Savannah are like super super cool. And you guys made me so comfortable being here so far. So I'm digging Nashville so far for sure.

[01:04:23:23 - 01:04:28:11]
Speaker 15
 Good. Okay. Well, we need to take that dress out for a while. Like I said, we are.

[01:04:28:11 - 01:04:32:08]
Speaker 19
 No, we absolutely are. And you said downtown. Downtown.

[01:04:32:08 - 01:04:35:16]
Speaker 15
 There's so many different places. Okay. I mean, we'll pick a fun group.

[01:04:35:16 - 01:04:39:00]
Speaker 19
 Either way. It's getting on my body. And we're going outside. Yeah.

[01:04:39:00 - 01:04:44:05]
Speaker 15
 You haven't dated in a while. So you need to try out the mermaid in Nashville. We need to get acquainted.

[01:04:45:07 - 01:04:52:20]
Speaker 15
 I personally like them better than Toronto. Okay. Like it's such a different dating scene. Okay. So hopefully that you have a little bit better luck.

[01:04:52:20 - 01:05:01:05]
Speaker 19
 I never, I haven't heard anybody say they actually like dating here better than anywhere else so far. So I'm excited for that. Yeah. I'm excited to see.

[01:05:03:11 - 01:05:06:10]
Speaker 15
 We'll go out. You'll have lots of chances to meet you girls. Okay. Yeah.

[01:05:13:05 - 01:05:26:21]
Speaker 19
 Hello. Hi, guys. Hey, guys. You guys look beautiful. You look beautiful. You look beautiful. You look amazing. I love this one. Thank you, boo. My spurt is a little short.

[01:05:26:21 - 01:05:27:10]
Speaker 15
 How are

[01:05:28:14 - 01:05:30:22]
Speaker 15
 you? Your dogs are so cute.

[01:05:32:09 - 01:05:32:17]
Speaker 15
 It's great.

[01:05:34:05 - 01:05:37:21]
Speaker 15
 They're so cute. What's the breed? They're more keys.

[01:05:39:00 - 01:05:41:00]
Speaker 15
 You have a dog too, right?

[01:05:41:00 - 01:05:43:23]
Speaker 1
 She's a teddy bear breed. She's so cute.

[01:05:45:01 - 01:05:46:02]
Speaker 1
 She's darling.

[01:05:46:02 - 01:05:46:09]
Speaker 19
 I'm

[01:05:49:01 - 01:05:53:19]
Speaker 19
 loving her. I'm so excited to see you. We're just talking about dating. You've been here a little

[01:05:53:19 - 01:05:54:02]
Speaker 19
 bit.

[01:05:54:02 - 01:05:57:06]
Speaker 15
 You've lived here for so long. How are you finding it?

[01:05:57:06 - 01:06:00:17]
Speaker 1
 I've lived here for three years now.

[01:06:01:21 - 01:06:14:14]
Speaker 1
 I find that it's a big poll of different people that move here from California, which I used to live in California, and pretty much all over. I feel like the dating scene here is one of those things where it's like, "We don't have so many options."

[01:06:16:08 - 01:06:22:03]
Speaker 1
 There's so many beautiful women here. Yeah, exactly. And where are you guys originally from? There's a lot of quality people here

[01:06:22:03 - 01:06:37:09]
Speaker 15
 as well. I find that. I'm from Toronto, and the dating scene is not great. I love it here a lot longer. But I still have only been here a lot, so I'm getting used to the scene. You probably have so much experience to tell us about.

[01:06:37:09 - 01:06:53:07]
Speaker 1
 Oh, goodness. Well, have you guys been to Broadway? Because that's the interesting... I mean, there's so many different areas. I feel like here in Nashville, but Broadway is kind of... It's very like the New York vibe. It's the most city part of your country, boys, though. Country boys, though?

[01:06:53:07 - 01:06:57:13]
Speaker 19
 Very country. Because being from Pennsylvania. You know what I mean? I need to know where they're at.

[01:06:57:13 - 01:07:04:19]
Speaker 1
 I need a lot of bachelorette parties. You're going to see a lot of metal taverns. Just be prepared. A lot of drunk people.

[01:07:04:19 - 01:07:06:19]
Speaker 15
 Guys, I'll put a dog.

[01:07:06:19 - 01:07:18:22]
Speaker 19
 That's a great question. He takes longer than any of us to get ready, though. The training is now... He's in the bridal world. The bridal world. That's right. He does own a bridal store. True. Exactly.

[01:07:18:22 - 01:07:23:23]
Speaker 1
 So did you go to Broadway the other night? She was texting me earlier, telling me

[01:07:23:23 - 01:07:50:12]
Speaker 15
 that you did. My phone got stolen right out of my pocket. Okay. Welcome to Nashville. Yeah. I heard you have it all the time. I went to a couple different places, but it's been very inconvenient. I was taken right out of my back pocket, and now I don't. All my contacts, because I'm Canadian, I still haven't set up a proper phone plan here. So yeah. I'm trying to get through my days right now. Oh, no.

[01:07:50:12 - 01:08:05:02]
Speaker 1
 I'm trying to figure out who's texting me, but that's not so far away. I'm sure everybody was freaking out, trying to hit you up. I feel like the times in my life where my phone wasn't working for a day, I was like, "Everybody thought I died." At least she's single, because I was on my phone working

[01:08:05:02 - 01:08:10:00]
Speaker 19
 or doing stuff. Yeah, true. At least we're all single, and you don't have to worry about hitting anybody up. Yeah. That.

[01:08:10:00 - 01:08:16:05]
Speaker 15
 I don't have to worry about that. I met two potentials, though, ladies, on the weekend, so they are hitting me up.

[01:08:16:05 - 01:08:26:21]
Speaker 19
 Oh, okay. Yes. So they're new saved numbers in the new phone. They're not saved yet. I know that's crazy. Yeah, that's because it sounds so good. Saved is crazy. It's how long it takes them to lie down.

[01:08:26:21 - 01:08:48:15]
Speaker 1
 Are you guys that way? Because I know I am. If I meet somebody that I like, but I'm still giving them the seven-day trial period, I'm going to call it, "I won't save their number until they prove themselves to me." I know. That sounds really bad, but I just purposely will not save their number until I go on a date with them, and then I decide I like them. No, I heard that girl is like that high.

[01:08:48:15 - 01:08:55:01]
Speaker 19
 I know a lot of girls that are like that high. The sooner you save someone's number, the sooner they start cutting up. Yeah.

[01:08:55:01 - 01:09:03:09]
Speaker 1
 Yeah. So you kind of like... Yeah, because as soon as you tell your girlfriends you like them, it's over. It's over. It's over. Because I feel like it's like... It's like men. Yeah.

[01:09:04:10 - 01:09:08:02]
Speaker 1
 It's like men in the universe. It's like as soon as you like them, it's over.

[01:09:08:02 - 01:09:08:18]
Speaker 19
 I know.

[01:09:14:01 - 01:09:15:13]
Speaker 6
 What's up girls?

[01:09:18:14 - 01:09:30:19]
 (Crosstalk)

[01:09:30:19 - 01:09:41:18]
Speaker 2
 All right girls, so this is Alex.

[01:09:41:18 - 01:09:43:01]
Speaker 6
 Hey, Alex. Hi.

[01:09:43:01 - 01:09:45:01]
Speaker 2
 Hi. Hi. Hi. Hi. Hi. Hi. Hi. Hi. Hi.

[01:09:48:17 - 01:09:52:00]
Speaker 6
 Hey, it's me. It's fun to see you turn on. I can't wait to see you.

[01:09:52:00 - 01:09:53:21]
Speaker 2
 Yeah, we got Sarah. She's our patron.

[01:09:53:21 - 01:10:00:22]
Speaker 6
 You guys ready? Yeah, we're ready. Let's do it.

[01:11:03:15 - 01:11:08:10]
 (Music)

[01:11:32:23 - 01:11:33:19]
Speaker 25
 Hi, we're acting.

[01:13:04:13 - 01:13:04:18]
Speaker 25
 Hi.

[01:13:04:18 - 01:13:16:17]
 (Music)

[01:13:18:19 - 01:13:19:14]
Speaker 25
 Hi, we're acting.

[01:13:19:14 - 01:13:29:22]
 (Music)

[01:13:48:14 - 01:13:50:06]
Speaker 25
 Hi.

[01:13:50:06 - 01:14:01:00]
 (Music)

[01:14:04:14 - 01:14:05:10]
Speaker 25
 Hi.

[01:14:05:10 - 01:15:13:20]
Speaker 20
 love it. Are we ready for number two? Number two. Bring it on.

[01:15:17:18 - 01:16:09:20]
Speaker 19
 That's so cool. Wow.

[01:16:09:20 - 01:16:13:03]
Speaker 2
 Yeah, because it like popped out and floated, so it stayed on top.

[01:16:13:03 - 01:16:16:03]
Speaker 1
 Oh my gosh. Yeah. Yeah, it was really cool. That's crazy.

[01:16:16:03 - 01:16:18:15]
Speaker 1
 Have you guys been line dancing? I do want a line dancing.

[01:16:18:15 - 01:16:22:18]
Speaker 19
 We have to do that. That's your talent. Yeah, we have to get you boots. Let's go.

[01:16:22:18 - 01:16:26:11]
Speaker 15
 We have to do it. We have to get her boots first. I don't know what I'm saying.

[01:16:26:11 - 01:16:26:22]
Speaker 19
 I don't know what I'm saying.

[01:16:26:22 - 01:16:27:14]
Speaker 15
 You don't own any.

[01:16:27:14 - 01:16:28:12]
Speaker 19
 That's the Pennsylvania.

[01:16:28:12 - 01:16:31:03]
Speaker 1
 Oh my gosh. It's the Pennsylvania indeed. Wow.

[01:16:31:03 - 01:16:31:15]
Speaker 2
 The Broadway trip.

[01:16:35:23 - 01:16:37:01]
Speaker 19
 Yeah.

[01:16:37:01 - 01:16:37:02]
 (Laughing)

[01:16:37:02 - 01:16:40:16]
Speaker 1
 It looks like our night might end in line dancing, swing dancing.

[01:16:40:16 - 01:16:42:11]
Speaker 1
 what are you guys excited about? Oh, we got number two.

[01:16:42:11 - 01:16:46:08]
Speaker 19
 Oh, number two. Okay. Oh, wow.

[01:16:46:08 - 01:16:51:02]
Speaker 15
 All right, right off the bat, I'm loving this one as much. Wait a minute.

[01:16:51:02 - 01:17:01:09]
Speaker 19
 Well. I'm loving this one more. Really? Oh, it's very graphic to me. It's very graphicly. What's the art in here? It's the artist. It's the artist. It's the artist. Yeah.

[01:17:01:09 - 01:17:29:06]
Speaker 2
 Yeah, I wanted to give her options. Yeah, yeah. You know, so like all the dresses kind of have the same shape. Yeah. Right, which is what she's looking for. But I wanted to give her options so that she, you know, a lot of times when brides come in, they have this picture of like exactly the dress, like since I was a little girl. And then they come in and they try it on, and they're like, oh, that's not the dress. That's not the one. So we end up typically, you know, searching for the dress. So I wanted to give her multiple options so she could see herself in different styles of dress.

[01:17:30:07 - 01:17:39:23]
Speaker 2
 And then that way, maybe if she says she's like this one, but there's something that she doesn't like about it, then I can go to the rack and say, let me try this. So I wanted her to have a-- Yeah.

[01:17:39:23 - 01:18:06:03]
Speaker 15
 I like the top on this one too. Yeah, the shape is perfect. And the roof shape on the top, the way it sits, it's very beautiful. Would you say you didn't like it? Would you not like it? I just, I don't love it. I don't not like it. I don't love it as much as the first one because personally I would go for ease on the beach. And like you said, the light hits the pearl. Makes that-- But this one is unique in itself. So unique.

[01:18:06:03 - 01:18:11:20]
Speaker 1
 Yeah. I wanted a little more ballroom a little bit. Maybe it's really the ballroom venue.

[01:18:11:20 - 01:18:13:15]
Speaker 15
 I love it. Yeah.

[01:18:13:15 - 01:18:14:20]
Speaker 2
 So not a beach vibe?

[01:18:14:20 - 01:18:25:00]
Speaker 19
 Maybe not beachy. If the flowers were a different flower. I don't know. It's a contender. Maybe a little smaller. I love them though.

[01:18:26:05 - 01:18:29:19]
Speaker 19
 It's a contender for sure. The bride could definitely probably maybe like this.

[01:18:29:19 - 01:18:33:19]
Speaker 2
 Right, exactly. Like I said, that's all one thing in her options because I think that was important. I can see

[01:18:33:19 - 01:18:35:00]
Speaker 2
 that. What'd you get these clips from?

[01:18:36:14 - 01:18:38:08]
Speaker 1
 I got real clips by the way. From where?

[01:18:38:08 - 01:18:40:11]
Speaker 2
 They're in my bag.

[01:18:41:12 - 01:18:42:00]
Speaker 2
 But anyway.

[01:18:43:08 - 01:18:52:00]
Speaker 1
 Yeah, I think I like the first one better. Do you love it? I like the first one. I think, I know, I like it. Oh my gosh. I think I like the first one. But you know, I think the day.

[01:18:52:00 - 01:18:53:21]
Speaker 19
 Oh my gosh. This one's beautiful.

[01:18:53:21 - 01:18:55:01]
Speaker 2
 You're supposed to ask me.

[01:18:57:10 - 01:18:59:02]
Speaker 19
 Did all of them have the black clap? Yes.

[01:19:00:19 - 01:19:01:00]
Speaker 19
 Yeah.

[01:19:01:00 - 01:19:02:02]
 (Laughing)

[01:19:04:06 - 01:19:05:22]
Speaker 19
 Gosh, with the red thing on it.

[01:19:09:00 - 01:19:11:23]
Speaker 1
 It looks like something to like, restart your car.

[01:19:11:23 - 01:19:13:23]
Speaker 19
 These are when we're stopping at Lowe's.

[01:19:13:23 - 01:19:16:07]
Speaker 15
 Like a jumper. Yeah, like a jumper cable.

[01:19:16:07 - 01:19:19:03]
Speaker 2
 But that was good for TV, so we'll keep it. Those are for the Lowe's.

[01:19:19:03 - 01:19:20:06]
 (Laughing)

[01:19:20:06 - 01:19:21:22]
Speaker 15
 Even the dogs are confused about it.

[01:19:23:04 - 01:19:26:03]
Speaker 2
 Lowe's clips. Anyway,

[01:19:27:07 - 01:19:28:06]
Speaker 2
 everything looks great.

[01:19:28:06 - 01:19:31:01]
Speaker 15
 They're like, what is happening? Grace is over it.

[01:19:32:06 - 01:19:32:18]
Speaker 15
 I'm tired.

[01:19:33:21 - 01:19:36:20]
Speaker 2
 I can't stay awake for Grace. I'm just trying to figure out where those clips came from.

[01:19:36:20 - 01:19:40:20]
Speaker 19
 They were like big, like huge. I can gush real clips.

[01:19:40:20 - 01:19:43:06]
Speaker 2
 It's all good, it's all good. That's so funny.

[01:19:43:06 - 01:19:48:20]
Speaker 19
 We figured it out. They're doing a job, it's so good. I didn't see that, it's beautiful. No, it's beautiful. It looks beautiful, you

[01:19:48:20 - 01:19:53:08]
Speaker 1
 I'm not an angry or a dirty-marty. I look angry or a dirty thing. Yeah, I love beer. So sweet.

[01:19:54:10 - 01:19:55:14]
Speaker 19
 I love beer. So sweet.

[01:19:55:14 - 01:20:02:06]
Speaker 15
 Okay, y'all, what about wine? I love red wine. I like red wine. Yeah, I like red wine.

[01:20:02:06 - 01:20:07:04]
Speaker 2
 Yeah. I like being on the water. Yeah, yep, that too. I feel like I'm being on the water and like a cigar.

[01:20:07:04 - 01:20:11:11]
Speaker 1
 Oh, I love a good cigar. You're so classy. That's a song. You love a cigar.

[01:20:11:11 - 01:20:14:19]
Speaker 2
 That's a song. Yeah, I like that. Being on the water is a good song.

[01:20:14:19 - 01:20:18:23]
Speaker 1
 Yeah, that's a good song. I love a good cigar. Oh, you're gonna make a song and start singing?

[01:20:18:23 - 01:20:20:16]
Speaker 2
 That was the first time we hung out really.

[01:20:20:16 - 01:20:27:05]
Speaker 1
 Oh yeah, we cigar-led. We went to a cigar spot. Yeah. Oh, because he found out that I liked cigars.

[01:20:27:05 - 01:20:32:19]
Speaker 19
 Okay, I'm gonna need to get into Nashville integrated, because we are cigars, like-- Oh, I love cigars.

[01:20:32:19 - 01:20:48:21]
Speaker 1
 I need to get in there. I mean, cowgirl boots. Like, I lived here for three years, and I swear, like I wasn't a beer girl. I didn't own a pair of cowgirl boots. And then you moved here, and then it just happens. You know? All of a sudden, like, you see the country music.

[01:20:48:21 - 01:20:53:01]
Speaker 2
 I have a country dance, though. I gotta send you that country music, like--

[01:20:53:01 - 01:21:05:22]
Speaker 19
 Yes, I told you that. I got money. Yeah, yeah, yeah. So what do you normally listen to? Oh, like an R&B, like-- Okay. Like, alternative. Okay. Yeah, like an old alternative music. I love R&B, I love it all. Okay.

[01:21:05:22 - 01:21:09:11]
Speaker 15
 Okay, yeah. Well, I'm excited to start. I'm excited to start seeing countries.

[01:21:09:11 - 01:21:26:12]
Speaker 1
 Yeah, that's what I'm gonna say. Yeah, I'm ready. Yeah, I'm excited just for, like, you guys, like, after moving here, like, getting to merge yourself into culture. Like, I'm excited for me and Dom to kind of, like, show you all that. I think you guys are gonna absolutely love Nashville. I know it's so cool, it's so fast-paced, but also, so many people are moving here.

[01:21:26:12 - 01:21:27:18]
Speaker 2
 Yeah, it's super eclectic.

[01:21:27:18 - 01:21:28:15]
Speaker 1
 Yeah.

[01:21:28:15 - 01:21:29:14]
Speaker 2
 It's so many different countries.

[01:21:29:14 - 01:21:39:15]
Speaker 15
 Yeah. So much development, too. Right, exactly. So much housing. Yeah. You know, interesting architecture. Yeah. It's a growing city. It's brilliant.

[01:21:39:15 - 01:21:43:12]
Speaker 2
 It's like the bride and catwalk. It's like, literally, like, so many brides between here and on the base.

[01:21:43:12 - 01:21:47:01]
Speaker 15
 Yeah. So we're gonna be so many brides. So many people.

[01:21:47:01 - 01:22:00:03]
Speaker 19
 Oh, how do you help them? The funny issue that they're having is actually going through with the weddings due to finances and stuff like that, I think. Right, yeah, I mean, I mean, to me, like, that's one of the most important things. Like, some of the, some of the, can't afford to be here. Oh,

[01:22:00:03 - 01:22:03:09]
Speaker 19
 there she comes. Wow, okay.

[01:22:03:09 - 01:22:07:11]
Speaker 1
 Okay. We love that. Okay. Everything looks really good.

[01:22:08:14 - 01:22:12:01]
Speaker 19
 Okay. That set, top, speaks to me. I love a corset. Right.

[01:22:13:02 - 01:22:25:05]
Speaker 15
 The girls are popping out. I love a corset. All right. I love you. I love a corset. Yeah, girl, you know I mentioned that earlier. I was like, I love a corset. Girls, the sleeves on this one, it's pretty, right?

[01:22:25:05 - 01:22:28:10]
Speaker 1
 I do, yeah, I love the sleeves. Yeah, pretty.

[01:22:28:10 - 01:22:56:16]
Speaker 2
 Yeah, you know, I wanted to give her an option on sleeves because a lot of times, like, they trust, like, they don't think about sleeves, and then they tie them on, and they're like, oh my gosh, I actually look really good with sleeves. You know, but I think that's like one of the most, like, to me, the most beautiful moment is like, whenever she finds the dress. Yeah. You know, so like, when you give them those options, and then you see those baby tears for the first time, it's like, you know that she found her dress, you know? So it's like, when you give them options like this, and she's like, I didn't know I was gonna like,

[01:22:56:16 - 01:23:04:07]
 (Dramatic Music)

[01:23:04:07 - 01:23:06:00]
Speaker 19
 I love the waistline on that one.

[01:23:07:20 - 01:23:08:04]
 (Laughing)

[01:23:08:04 - 01:23:09:15]
Speaker 19
 I love

[01:23:12:19 - 01:23:14:08]
Speaker 19
 the flowers detail.

[01:23:16:00 - 01:23:16:13]
Speaker 19
 Does it feel heavy?

[01:23:20:20 - 01:23:23:22]
Speaker 15
 Oh, so the first one being the head, oh, the feet.

[01:23:26:16 - 01:23:31:14]
Speaker 1
 Got it. So it's the feet. What about the second? The second one is like-- Really?

[01:23:31:14 - 01:23:32:16]
Speaker 2
 Got it.

[01:23:34:14 - 01:23:44:04]
Speaker 2
 So the heavy, so that's the bead. It's the beads. Anytime you have beads, you're gonna have weight. And then I can do that. So most of it, most of our heavy, like the beads were like different.

[01:23:45:08 - 01:23:54:01]
Speaker 15
 When she first walked out, I didn't think I really liked it, but it's really growing on me. It's growing on you? Yeah. Yeah. I like the sleeves. And the waistline, like you said, it's pretty.

[01:23:54:01 - 01:24:01:16]
Speaker 19
 And I know she didn't want anything like, but I think like right where it's sitting is like perfect. Before it's like too huggy.

[01:24:01:16 - 01:24:03:11]
Speaker 2
 Right. Yeah, I think it was great.

[01:24:03:11 - 01:24:06:21]
Speaker 1
 So I'll get on the hands too. Or the picture, truly.

[01:24:06:21 - 01:24:10:13]
Speaker 19
 I think that's-- I think that's-- I think that's enough. An eight.

[01:24:10:13 - 01:24:11:17]
Speaker 15
 An eight? Yeah.

[01:24:11:17 - 01:24:12:15]
Speaker 19
 So we got two eights.

[01:24:12:15 - 01:24:16:15]
Speaker 15
 Well, 8.5 for the first one. Perfect. Okay. Okay. Right, is that your memory?

[01:24:16:15 - 01:24:18:00]
Speaker 19
 Yes, it's a 10 for

[01:24:19:09 - 01:24:20:13]
Speaker 19
 me, I want it. Let's go.

[01:24:20:13 - 01:24:21:15]
 (Laughing)

[01:24:21:15 - 01:24:24:02]
Speaker 2
 Oh, really? Well, that's great though, because we got different personalities.

[01:24:24:02 - 01:24:27:23]
Speaker 19
 Yeah, it's a marriage. You gotta find a man first.

[01:24:30:16 - 01:24:30:21]
Speaker 19
 Yeah.

[01:24:30:21 - 01:24:31:00]
 (Laughing)

[01:24:31:00 - 01:24:34:16]
Speaker 2
 Here we are, like, single, single, single.

[01:24:34:16 - 01:24:35:09]
Speaker 19
 Yeah.

[01:24:35:09 - 01:24:37:09]
 (Laughing)

[01:24:37:09 - 01:24:43:20]
Speaker 2
 No, that looks great. I like it. It looks really good on the team. All of them, wow. Which one does you choose?

[01:24:45:02 - 01:25:28:07]
Speaker 2
 I'm stuck between the first one and the second one. Okay. I really like the sleeves on this one. Yeah. I think they're very elegant. Yes, it is. I think the one thing I liked about the first one was just kind of like that champagne color. Yeah. And so when she's on the beach, you get a kind of like offset, like the sand, and then her white flowers, and then like her arch and everything else. And so that's kind of what I was thinking when we were first. And even though we can like change the color, just kind of like, yeah, champagne. I wanted you guys to be able to see the difference in like maybe if she were to get distressed and champagne, how she would feel about it. Yeah, yeah. You know what I mean? Great options, Tom. So I think like when we get to the appointment, I mean, I think that's one thing that we'll try to make sure that we find in the first one. Yeah. She can change the actual color.

[01:25:28:07 - 01:25:30:03]
Speaker 15
 You guys are right. Strong variety.

[01:25:31:05 - 01:25:31:13]
Speaker 15
 Right.

[01:25:31:13 - 01:25:33:09]
Speaker 19
 Variety. Variety, y'all variety.

[01:25:33:09 - 01:25:34:12]
Speaker 2
 Yeah, I think too many times.

[01:25:34:12 - 01:25:38:21]
Speaker 15
 Oh, hey, you know, too much for fat though. I'm telling you, that's a lot of Canadian twang.

[01:25:38:21 - 01:25:40:00]
 (Laughing)

[01:25:40:00 - 01:25:43:02]
Speaker 2
 It's that Canadian twang. Yeah. That might be a new song.

[01:25:43:02 - 01:25:44:13]
Speaker 1
 Canadian twang.

[01:25:44:13 - 01:25:55:04]
Speaker 19
 Canadian twang. Which one? Canadian twang. And, you know, noir and stars. Yeah, if you know noir and stars. Yeah, no, no, no, no. A lot of songs for rain. We're making an hour. Yeah.

[01:25:55:04 - 01:25:55:21]
Speaker 2
 All right,

[01:25:57:08 - 01:26:01:10]
Speaker 2
 Alex, thank you so much. You did a great job. Yeah.

[01:26:03:05 - 01:26:04:11]
Speaker 2
 You too, you look gorgeous.

[01:26:05:18 - 01:26:05:23]
Speaker 2
 Yeah.

[01:26:05:23 - 01:26:07:07]
Speaker 19
 You look so good.

[01:26:10:21 - 01:26:14:12]
Speaker 19
 All right, what'd you guys think? Love, love. Great choices. Yeah, I did good.

[01:26:14:12 - 01:32:59:01]
 (Chattering) (Laughing)

[01:32:59:01 - 01:33:04:20]
Speaker 1
 Okay,

[01:33:05:23 - 01:33:06:13]
Speaker 1
 two

[01:33:08:13 - 01:33:09:20]
Speaker 1
 seconds, two seconds.

[01:33:12:04 - 01:33:13:05]
Speaker 1
 I'm rolling also.

[01:33:19:03 - 01:33:22:17]
Speaker 1
 Both half step that way, half step to your right, perfect.

[01:33:24:16 - 01:33:28:19]
Speaker 1
 Now y'all can go and start talking, don't get to the juicy stuff yet. Cool.

[01:33:31:01 - 01:33:31:10]
Speaker 1
 Wow.

[01:33:33:14 - 01:33:51:06]
Speaker 1
 Like the fat band building over here. Like Bonnie, fat band building. You've been at a third top before, right? Yeah, a lot of times ago I actually sang here and did like a little show that way. Yeah, it was so fun. You do music as well, so are you normally doing like shows or more like studio stuff? More studio

[01:33:51:06 - 01:34:01:19]
Speaker 1
 stuff right now. I'm building my album. Oh my gosh. Maybe I'll sing here. Okay, we'll do a show together. Oh my gosh, wait, I forgot to tell you, there's no key. Okay,

[01:34:02:20 - 01:34:09:19]
Speaker 1
 so I just knew. But like, obviously no, I was like dating somebody a couple months ago. Got you done, so embarrassing.

[01:34:09:19 - 01:34:10:10]
Speaker 1
 Just but,

[01:34:11:16 - 01:34:19:07]
Speaker 1
 cheer on me with a bartender. Shouldn't I know, never go for a bartender. So they build into dating a bartender and choosing.

[01:34:20:08 - 01:34:25:06]
Speaker 1
 I know, I know. No bartender. I know, I know. Especially in this house.

[01:34:27:01 - 01:34:31:08]
Speaker 1
 I know, I shouldn't have done it. But anyways, did that, I ran into

[01:34:31:08 - 01:34:33:00]
Speaker 1
 them literally a week ago.

[01:34:35:11 - 01:34:35:17]
Speaker 1
 Oh

[01:34:35:17 - 01:35:27:16]
Speaker 1
 my gosh, girl. I had to really tap into my mentality at the time because it was just like, I could feel the petty vibes. Like they kissed right in front of me. Like they made sure they stood right in front of me. Like, pug. Uh, that was a little sad. Yeah, yeah. But it was nice. That's a hard thing to see. You know a lot of people like that deserve each other. And you're going to find a guy that doesn't love you because you are so much better than that. Because you really pour your heart and soul into it. And relationships and your energy. And you just need to get out. You both do. We do. We both do. Yeah, exactly. You've got good things coming. I think we have very good things coming our way. And even after that, she was stalking me for a little bit to count. 30 followers. It was very obvious. Yeah, like her profile. I can't not laugh. No, the profile picture was literally hers.

[01:35:28:20 - 01:35:59:03]
Speaker 1
 I guess it wasn't the screen. I probably had that on. Oh, all the time. Because I'm public so much. Oh, yeah. What's this all about? You too. Yeah. Oh, yeah. Do you belong to them? No, I just let them watch my movie. Oh, OK. Yeah. If you want to see what I'm doing, I'm doing lots of little things. Yeah. And you want to just like your Instagram's your family page. So it's like, oh my. Do you know what it is now? Well, here's the better things for us. And they're loved. Yeah, they're loved. I'm just excited for this journey of getting to help people that are in love find

[01:36:00:06 - 01:36:17:22]
Speaker 1
 the great dress. And I'm just excited, I think, through this process and working on ourselves and this self-love journey we're on, I think through that it's going to heal us. I think so too. And I can't wait to hear people's stories. I always love to hear their love stories. Yeah, exactly. How did you meet?

[01:36:18:23 - 01:36:45:16]
Speaker 1
 How did you prepare? 100%. I feel like a Canadian's firing for us. 100%. And I used to do home care. I don't know if you knew that. I actually did. Yeah. And so genuinely, I did for a couple of years. And I think one thing I learned-- because I've always been an old soul. It's like-- and I feel like you're the same way. If you're an old soul. It's you don't learn things in life until you've asked the right questions from people that have more experience. And you'll be like dying on their deathbed. We're

[01:36:45:16 - 01:36:53:05]
Speaker 1
 good to go. Cut. OK. OK. We're done. We have them wrapped up. It was good, cut. Good talking to you. What are we going to think?

[01:36:55:00 - 01:36:55:14]
Speaker 1
 I'm so glad

[01:36:55:14 - 01:37:00:00]
Speaker 1
 you're here. Just say, I'm so glad you're here. OK. Got it. Yeah, I'm so

[01:37:00:00 - 01:37:21:09]
Speaker 1
 glad you're here. We get to do this together. OK, you say that because you live here. OK. Yeah. I'm just giving as much meat. And you guys can cut at any point. What that was was just like-- which that was a good story. It was-- you knew where I was going with that. So you didn't hear. I feel like it was good. But you-- I'll say it for another one. You knew exactly where I was going.

[01:37:22:13 - 01:37:46:18]
Speaker 1
 It's people dying on their deathbed. They either let the love of their life get away, or their loved one pass away. But anyways, OK. I love that. We'll save it. Say that, keep it brief, and then go into like, this is what I love what we're doing. OK. That'd be perfect purchase. And then exit in. And then I'll just say, I'm so happy we're here together. Do your hug and hug. OK. So just say what you said about the home care. Yeah. Yeah.

[01:37:49:10 - 01:38:16:19]
Speaker 1
 And anyways, working in home care and all that, that's why I enjoyed that. Because I witnessed so many different walks of life of people that let love get away, or their loved one pass away. And so it's crazy being on this journey of getting to watch people in love and helping them. Yeah, I was happy we're doing this together. Yeah. Like to be together. Yeah, well, I better get going. But it was so good seeing you. You too. Well, we'll see you tomorrow. Yeah. We'll see you tomorrow. I'm excited. Cheers. Bye, girl.

[01:38:16:19 - 01:39:22:06]
Speaker 22
 We're here! Hey! What's up guys? Come on, come on, come on!

[01:39:24:09 - 01:39:26:06]
Speaker 8
 Oh

[01:39:28:05 - 01:39:35:11]
Speaker 8
 my gosh. What are you guys doing here? Hello. Oh my gosh, hello. So good to meet

[01:39:36:19 - 01:39:38:23]
Speaker 8
 you. What are you all doing here?

[01:39:40:16 - 01:39:41:10]
Speaker 8
 Did you do something?

[01:39:43:02 - 01:39:44:22]
Speaker 8
 You look suspicious. I didn't do anything.

[01:39:44:22 - 01:40:04:10]
Speaker 8
 guys have a seat. Thank you. I was just over here doing scones. Oh, let me put that on the way. Such a cute place. Thank you. We're just kind of getting settled in. We just moved in a few weeks ago. Yeah. Yeah. That's cute. Super cute. Yeah. That

[01:40:04:10 - 01:40:18:21]
 ( Inaudible )

[01:40:20:12 - 01:40:20:22]
Speaker 2
 Michigan.

[01:40:20:22 - 01:40:47:08]
Speaker 8
 Yeah, he's from Michigan. I lived here for a few years. I'm originally from Hawaii. Oh, I love Hawaii. Yes, and before that I was, or after that, I was in Spokane, Seattle area. Oh, of course. That's where I was from. That's where I was from. No way. Okay, crazy. Small world. I've been in Ashland for like three years now. Okay, we probably moved around the same planet here. That's crazy. Yeah. And where are you from, Garrison? Michigan. Michigan.

[01:40:48:16 - 01:40:51:06]
Speaker 1
 Close to Toronto. That's where I'm from. Oh, nice. Yeah, there you go.

[01:40:51:06 - 01:40:58:23]
Speaker 8
 Yeah, I grew up like 30 minutes from Detroit. Okay, yeah. That's fun. You're cold weather people? Oh, yeah. Oh, yeah. Yeah, Northerners. I'm from Pennsylvania, so. Yeah.

[01:40:58:23 - 01:41:01:01]
Speaker 1
 So you get the one jet jet on. Yeah. There you go.

[01:41:02:05 - 01:41:03:06]
Speaker 8
 I like cold.

[01:41:03:06 - 01:41:06:06]
Speaker 1
 Yeah. Does this area get all four seasons?

[01:41:06:06 - 01:41:24:18]
Speaker 8
 Kind of. Kind of. Our winters are super mild. They're pretty low-key compared to what you're used to. I mean, the snow lasts maybe a day. If it does snow, it's not common. You experience it, but look, it's short. It's perfect. It's like a little kiss of winter and then we're done. No, I want one. It's like the ice storm. That was fun.

[01:41:24:18 - 01:41:27:09]
Speaker 1
 That was fun. Oh, my gosh. That was wild.

[01:41:27:09 - 01:41:32:03]
Speaker 8
 Yeah, he was like out in it, sliding. Yeah, I was sliding around. That was a blast.

[01:41:32:03 - 01:41:35:10]
Speaker 1
 Yeah. Wow. So how did you guys meet? I'm so intrigued.

[01:41:35:10 - 01:41:37:00]
Speaker 2
 We met at a wedding.

[01:41:38:03 - 01:41:48:07]
Speaker 8
 We, yes. We met at my brother's wedding. We were both in the wedding. He's been friends with my brother for years. We knew of each other, but we met for the first time at my brother's wedding.

[01:41:48:07 - 01:41:49:13]
Speaker 2
 The whole world is about each other.

[01:41:50:20 - 01:41:52:07]
Speaker 2
 Everybody should be talking at one time.

[01:41:52:07 - 01:41:54:07]
Speaker 1
 Okay. Okay, got it.

[01:41:55:18 - 01:41:57:19]
Speaker 2
 Can you get used to a quick point? You want to fix the tape?

[01:41:59:02 - 01:42:00:01]
Speaker 1
 I think you're right.

[01:42:01:08 - 01:42:04:11]
Speaker 1
 No, no, sorry. Oh, yeah, the tape? What was he talking about?

[01:42:04:11 - 01:42:07:02]
Speaker 2
 Can we just try to move it over to the top? Oh, yeah, yeah, you're fine.

[01:42:07:02 - 01:42:08:11]
Speaker 1
 It's not good. You're too much.

[01:42:11:14 - 01:42:15:01]
Speaker 1
 Perfect. Okay, there you go. Okay, let's roll the video.

[01:42:17:15 - 01:42:22:03]
Speaker 1
 Yes, my turn is going. Okay, we're going. Let me just start with a word.

[01:42:22:03 - 01:42:27:11]
Speaker 8
 Wedding? Yeah, go ahead. So on a scale from one to ten, how excited are you today?

[01:42:29:07 - 01:42:30:01]
Speaker 8
 Ten? Ten?

[01:42:31:08 - 01:42:36:00]
Speaker 8
 I don't really know what's happening. I know a little, I guess I know a little bit of what's happening, but...

[01:42:37:08 - 01:42:39:06]
Speaker 8
 I guess you know everything about what's happening.

[01:42:39:06 - 01:42:40:00]
Speaker 1
 I don't know anything.

[01:42:41:00 - 01:42:50:09]
Speaker 8
 Well, that's how it's going to go. Okay. Everyone come with the girls. We're going to pick out some dresses for you. Okay. You're going to try them on and hopefully find some. Girls, you're excited to have the show out. Oh, they need that. That sounds amazing.

[01:42:51:16 - 01:42:53:02]
Speaker 2
 You didn't ask them about their story.

[01:42:53:02 - 01:42:55:18]
Speaker 8
 We did. You want to do us to do that again?

[01:42:55:18 - 01:42:56:03]
Speaker 2
 More.

[01:42:56:03 - 01:42:57:11]
Speaker 8
 More. More story.

[01:42:57:11 - 01:42:59:23]
Speaker 2
 I didn't hear it. Oh, I wasn't acknowledging it.

[01:42:59:23 - 01:43:02:18]
Speaker 8
 I was like, what part of the story? We kind of started it.

[01:43:02:18 - 01:43:04:23]
Speaker 2
 Why are they...

[01:43:04:23 - 01:43:19:16]
Speaker 1
 Oh, why are they going to ask? So we asked them about when they met. Okay. Let's roll from kind of... Okay. Well, because we cut scenes. Okay. So we'll start back to how they met maybe or just roll straight into that.

[01:43:19:16 - 01:43:21:21]
Speaker 2
 Let's just do that. Let's do how they met.

[01:43:21:21 - 01:43:23:13]
Speaker 1
 Yeah, let's do how they met. Yeah, let's do how they met. It's been done. It's been done. Okay.

[01:43:25:08 - 01:43:26:01]
Speaker 8
 We'll go back to that.

[01:43:26:01 - 01:43:28:00]
Speaker 1
 Okay. Here's the writing. I'll just ask that.

[01:43:28:00 - 01:43:29:05]
Speaker 2
 Yeah. Okay.

[01:43:30:20 - 01:43:33:19]
Speaker 1
 Just tell me you guys are right.

[01:43:34:23 - 01:43:36:14]
Speaker 1
 Just keep rolling. So you're right back.

[01:43:36:14 - 01:43:37:15]
Speaker 2
 What's up, dude?

[01:43:37:15 - 01:43:38:17]
Speaker 8
 All right.

[01:43:39:17 - 01:43:42:20]
Speaker 2
 Hey, what do you need? What do you need? What do you need?

[01:43:44:04 - 01:43:44:22]
Speaker 2
 What do you need? You want a snack?

[01:43:44:22 - 01:43:45:14]
Speaker 1
 What's a good way to ask?

[01:43:45:14 - 01:43:46:08]
Speaker 2
 You want sashias?

[01:43:47:17 - 01:43:51:08]
Speaker 1
 What do you want? Like, what's a good... like, verbiage wise? Well, we want them to do something.

[01:43:51:08 - 01:43:52:08]
Speaker 8
 We want them to do something.

[01:43:52:08 - 01:44:02:16]
Speaker 1
 No, no, no. We didn't get there. So I'm asking you verbiage wise, what's a good way to ask that question? So it's not the same question. We asked them, what's your... how do you guys meet? Yeah. But we're... we wanted... what's a good way to be like...

[01:44:02:16 - 01:44:08:18]
Speaker 2
 To segue into... Like, what we're doing. Yeah, so like, tell us why you got it or not. Tell us...

[01:44:11:07 - 01:44:12:18]
 (Inaudible)

[01:44:12:18 - 01:44:16:11]
Speaker 2
 I want to ask you about making it sound like fried.

[01:44:17:16 - 01:44:19:23]
Speaker 2
 So... These are just... Just these?

[01:44:19:23 - 01:44:21:14]
 (Inaudible)

[01:44:21:14 - 01:44:22:19]
Speaker 2
 What are these?

[01:44:22:19 - 01:44:23:15]
Speaker 8
 Those are chips.

[01:44:23:15 - 01:44:26:17]
Speaker 2
 Kind of. What chips you like for the corn chips?

[01:44:26:17 - 01:44:28:05]
 (Inaudible)

[01:44:30:07 - 01:44:34:23]
Speaker 2
 What's the quick snacks I can grab you right now? We're in the middle of something. I gotta go. Is that good? That's all I'm saying.

[01:44:34:23 - 01:44:37:08]
Speaker 8
 For right now, I'm getting more than here. Okay.

[01:44:37:08 - 01:44:40:03]
 (Inaudible)

[01:44:40:03 - 01:44:41:14]
Speaker 1
 Goodness, dude.

[01:44:41:14 - 01:44:43:02]
Speaker 8
 Like, what... yeah.

[01:44:43:02 - 01:44:45:01]
 (Inaudible)

[01:44:45:01 - 01:44:47:16]
Speaker 8
 Do you have a date set yet or something?

[01:44:47:16 - 01:44:47:20]
Speaker 1
 Buddy.

[01:44:47:20 - 01:44:48:22]
Speaker 8
 Buddy.

[01:44:48:22 - 01:44:49:23]
 (Inaudible)

[01:44:49:23 - 01:44:55:23]
Speaker 8
 Do you have a date set yet? And then that'll go into it. So why aren't you married yet?

[01:44:58:10 - 01:45:01:06]
 (Inaudible) (Laughter) (Inaudible)

[01:45:05:02 - 01:45:06:13]
Speaker 8
 Ouch. You wanna poach?

[01:45:07:23 - 01:45:11:15]
Speaker 8
 Do you want me to open that? He's the king of snacks. Okay. Those are your options right now. He's the king of snacks.

[01:45:13:00 - 01:45:13:02]
Speaker 8
 Okay.

[01:45:13:02 - 01:45:13:04]
Speaker 1
 Good?

[01:45:13:04 - 01:45:21:09]
 (Inaudible)

[01:45:21:09 - 01:45:22:16]
Speaker 2
 He's getting whiny.

[01:45:22:16 - 01:45:24:09]
Speaker 8
 Yeah, I know. He's ready.

[01:45:26:00 - 01:45:27:11]
 (Inaudible)

[01:45:27:11 - 01:45:30:04]
Speaker 1
 We go to the back. It doesn't show.

[01:45:30:04 - 01:45:31:17]
 (Inaudible)

[01:45:31:17 - 01:45:32:03]
Speaker 8
 You good?

[01:45:32:03 - 01:45:36:15]
 (Inaudible)

[01:45:36:15 - 01:45:38:07]
Speaker 1
 So we're picking up from where we met?

[01:45:38:07 - 01:45:42:15]
Speaker 2
 Yeah, we're gonna pick up and then she's got questions she's gonna ask and then it'll kind of segue into...

[01:45:45:10 - 01:45:45:11]
 (Inaudible)

[01:45:45:11 - 01:45:47:03]
Speaker 8
 The story? Okay.

[01:45:49:13 - 01:45:49:18]
 (Inaudible)

[01:45:49:18 - 01:45:52:09]
Speaker 1
 I fixed it, but if it won't go, he's down again. Let me know. Okay.

[01:45:54:14 - 01:45:55:09]
Speaker 1
 All right. You good?

[01:45:57:04 - 01:45:57:07]
 (Inaudible)

[01:45:58:09 - 01:46:02:00]
Speaker 1
 Wait, wait, wait. What was that? You came up with that question. What was it? Oh, okay.

[01:46:03:05 - 01:46:08:11]
Speaker 1
 And we don't want to expand more on how they met and on that, so we'll just go straight into hers maybe? Or do you want to go first into...

[01:46:08:11 - 01:46:20:05]
Speaker 2
 No, just go into her question. Okay. And then once you go from her to that question and they get done explaining, you guys can kind of just make it natural so whatever they say, you can be like, "Oh, whatever."

[01:46:20:05 - 01:46:20:17]
Speaker 1
 Yeah.

[01:46:20:17 - 01:46:22:05]
Speaker 2
 You know, the girly stuff. Okay.

[01:46:23:07 - 01:46:27:23]
Speaker 2
 And then you can maybe give them some credit and say, "Well, you have such a sweet pain."

[01:46:27:23 - 01:46:28:20]
Speaker 1
 Yeah.

[01:46:28:20 - 01:46:35:12]
Speaker 2
 No. And then you can reach out and reach out to that kind of situation. Okay. And then you can go in today. So this is how the day's going to go. Right.

[01:46:35:12 - 01:46:37:10]
Speaker 1
 So I'll be the last one. Yeah, yeah.

[01:46:37:10 - 01:46:37:17]
Speaker 2
 Okay.

[01:46:37:17 - 01:46:41:23]
Speaker 8
 Okay. Cool. Okay. So I'm starting with, do you have a date set?

[01:46:41:23 - 01:46:43:20]
Speaker 2
 So are you starting with it?

[01:46:43:20 - 01:47:07:01]
Speaker 8
 I can set. Okay. Cool. Yeah. So do you have a date set for your wedding? Not yet. Not yet. No? It's been kind of a process trying to set a date. Yeah. We had a date set. We changed it. And then we postponed it. So I think, ideally, June 5th of 2027 is kind of like our goal. Okay.

[01:47:07:01 - 01:47:07:19]
Speaker 1
 We like that date.

[01:47:07:19 - 01:47:48:05]
Speaker 8
 We like that date. It feels like our wedding date. It does. So I think we're just going to stick with it. It's a nice time of year. Yeah. Yeah. It's a good time. Yeah. And if you don't mind me asking, why have you guys postponed it? Yes. Financial reasons. Okay. There's financial reasons and like life stresses and other things going on in our life where we just felt like, you know, we want to. Let's finish those first and then we can finally focus on. Yes. I want to feel like a bride and be able to just, you know, have that bridal glow and just be able to focus on that and be happy and enjoy our engagement and not stress about other things in life too. So. Yeah. Yeah. So on a scale from one to 10, how excited were you to see us today?

[01:47:49:20 - 01:47:57:02]
Speaker 8
 I'm shocked and very excited. You're such a sweet man. I love that this is up for you. I do. I think it's a good time. So I do. I picked a good one.

[01:47:58:04 - 01:48:02:03]
Speaker 1
 So the way it's going to go today is we're going to, sorry, take you away from him today. Oh, that's fine.

[01:48:02:03 - 01:48:04:02]
Speaker 8
 Because we have to. Oh no.

[01:48:05:09 - 01:48:10:22]
Speaker 8
 And we're going to find you a dress today. Okay. And you're going to try some one and hopefully you look, I mean, feel beautiful. Yeah.

[01:48:12:04 - 01:48:12:09]
Speaker 8
 Yes.

[01:48:13:11 - 01:48:15:07]
Speaker 8
 That sounds so fun. Bye.

[01:48:16:10 - 01:48:18:06]
Speaker 8
 That's fun.

[01:48:19:21 - 01:48:25:14]
Speaker 8
 And you work at a coffee shop. I do. Yeah. So first things first, we need to get a coffee. That sounds great. Oh yeah. Yeah. Let's do it.

[01:48:25:14 - 01:48:25:22]
Speaker 1
 Yes.

[01:48:25:22 - 01:48:27:19]
Speaker 8
 I know a place. Let's go.

[01:48:27:19 - 01:48:33:08]
Speaker 8
 Okay. Are you ready to do this? I am. Okay. So get your bags packed. You're coming with us.

[01:48:33:08 - 01:48:34:01]
Speaker 8
 girls day.

[01:48:34:01 - 01:49:00:22]
 (Blank Audio)

[01:49:02:15 - 01:49:06:00]
Speaker 10
 We're here. Are you excited?

[01:49:07:04 - 01:49:07:15]
Speaker 10
 Good.

[01:49:09:05 - 01:49:10:17]
 (Blank Audio)

[01:49:10:17 - 01:49:11:05]
Speaker 10
 All

[01:49:13:21 - 01:49:13:23]
Speaker 2
 okay

[01:49:15:22 - 01:49:19:06]
Speaker 2
 ladies Is

[01:49:20:08 - 01:49:26:15]
Speaker 2
 this our Sarah So nice to meet you Yeah, we're so excited to have you here

[01:49:27:21 - 01:49:30:17]
Speaker 2
 Yeah, yeah ready to do this. Are you excited?

[01:49:31:21 - 01:49:36:22]
Speaker 2
 Thank you founder. Yes. I think I think yeah Awesome. All right, let's do it

[01:49:36:22 - 01:49:40:20]
Speaker 2
 right, Sarah, welcome to your VIP appointment.

[01:49:42:10 - 01:49:44:00]
Speaker 2
 my goodness. I know, welcome. We're

[01:49:44:00 - 01:49:48:02]
Speaker 2
 wait to get you in these dresses because I know

[01:49:48:02 - 01:49:49:00]
Speaker 2
 you.

[01:49:49:00 - 01:49:49:22]
Speaker 1
 Girls Day.

[01:49:49:22 - 01:49:52:20]
Speaker 2
 Yeah, and these are Danielle's pups, by the way.

[01:49:53:22 - 01:49:59:09]
Speaker 1
 Grace and Frankie, they're the welcoming committee, so they're going to be watching you try on all the dresses. Hope that's okay.

[01:49:59:09 - 01:50:01:16]
Speaker 2
 Yeah, can I get you water?

[01:50:01:16 - 01:50:02:01]
Speaker 1
 Yes.

[01:50:02:01 - 01:50:03:10]
Speaker 2
 All right, cool. You can have a seat.

[01:50:03:10 - 01:50:04:05]
Speaker 1
 Hey,

[01:50:04:05 - 01:50:06:21]
Speaker 2
 hot in Tennessee. It's from UV10.

[01:50:08:15 - 01:50:12:09]
Speaker 2
 There you go. Thank you, Consley. You're welcome.

[01:50:12:09 - 01:50:13:04]
Speaker 2
 is Yousuf.

[01:50:13:04 - 01:50:13:21]
Speaker 13
 Hello.

[01:50:13:21 - 01:50:21:06]
Speaker 2
 Yes. And Yousuf is going to be helping you get your dresses on today. All right. All right. He is the best. One of my most favorite people.

[01:50:23:05 - 01:50:23:05]
 ( Laughter )

[01:50:23:05 - 01:50:24:20]
Speaker 2
 Dress number one, you ready?

[01:50:24:20 - 01:50:25:09]
Speaker 14
 I'm ready.

[01:50:25:09 - 01:50:26:05]
Speaker 2
 All right, let's do it.

[01:50:26:05 - 01:50:28:22]
Speaker 14
 Let's go. Can't wait to see it. Yes.

[01:50:28:22 - 01:50:37:15]
 ( Background Noise )

[01:50:37:15 - 01:50:41:17]
Speaker 1
 So exciting.

[01:50:43:00 - 01:50:44:12]
Speaker 1
 So cool.

[01:50:44:12 - 01:50:47:13]
Speaker 2
 So tell me about you guys today. How's it been so far?

[01:50:47:13 - 01:50:50:14]
Speaker 1
 It's been good. Yeah. It's been really good. It's so hot outside.

[01:50:50:14 - 01:50:51:19]
Speaker 2
 It is hot outside.

[01:50:51:19 - 01:51:04:23]
Speaker 1
 Yeah, it's so nice and cool in here. I honestly kind of got a flat tire earlier. So that was kind of just a toll on my day. Yeah. I ran over now. So I had to get that fixed earlier on the way here. No way. Besides that, it's been such a good day. Yeah.

[01:51:04:23 - 01:51:08:13]
Speaker 3
 Once we got to the bride's house and then got her here, it was smooth.

[01:51:08:13 - 01:51:11:16]
Speaker 2
 Everything worked out. How was Garrison? Tell me about him.

[01:51:11:16 - 01:51:16:10]
Speaker 3
 He's cool. He's very nice. Yeah, he's very sweet. Yeah.

[01:51:16:10 - 01:51:18:12]
Speaker 2
 I like Garrison. He seems like a great guy. Yeah.

[01:51:18:12 - 01:51:21:04]
Speaker 1
 By the way he looks at her, it's just so in love.

[01:51:21:04 - 01:51:21:16]
Speaker 2
 Yeah.

[01:51:21:16 - 01:51:22:11]
Speaker 1
 It's adorable.

[01:51:22:11 - 01:51:40:00]
Speaker 2
 You know what? And I think that's my favorite thing is people who are really in love, we get an opportunity to fulfill their dream. I mean, it's to be married for her to find that dress, and I think it's just so cool. To be a part of this, we get to do it. We're at the beginning of somebody's forever. Oh, I love it.

[01:51:40:00 - 01:51:46:01]
Speaker 3
 And what's more romantic than a surprise wedding gown fitting? From your fiancee.

[01:51:46:01 - 01:51:47:03]
Speaker 2
 From your fiancee.

[01:51:47:03 - 01:51:51:07]
Speaker 1
 That's insane. Surprise Girls Day. Right. I'll take that. That's nice.

[01:51:51:07 - 01:51:55:10]
Speaker 2
 Yeah, it's so cool. So how are you guys like in Nashville? Tell me about it.

[01:51:57:15 - 01:51:58:02]
Speaker 2
 What's that mean?

[01:51:59:22 - 01:52:01:00]
Speaker 3
 Just these men.

[01:52:01:00 - 01:52:01:21]
Speaker 2
 The men.

[01:52:01:21 - 01:52:02:16]
Speaker 3
 The men.

[01:52:02:16 - 01:52:04:01]
Speaker 2
 You didn't hear that.

[01:52:05:03 - 01:52:07:10]
Speaker 2
 Not her man. We know you have a great guy.

[01:52:09:05 - 01:52:11:01]
Speaker 2
 You found the pick of the litter, so good job.

[01:52:11:01 - 01:52:15:02]
Speaker 3
 Yeah. I'm going to have to say her prayer. She didn't have to tell me after this. Yeah, no, I agree.

[01:52:15:02 - 01:52:19:04]
Speaker 2
 You got to give them some pointers on how to find a good man.

[01:52:19:04 - 01:52:24:01]
Speaker 1
 Yeah. You have to like Star Wars. You have to like Star Wars.

[01:52:24:01 - 01:52:35:07]
Speaker 2
 Right. You know what? I'm kind of in the same boat though. I'm single. Here we are all single, helping people find their dress and get them married. So cool. We'll find our people one day. We'll find our people one day. They'll rub off on

[01:52:36:13 - 01:52:36:17]
Speaker 2
 us.

[01:52:36:17 - 01:52:39:00]
Speaker 3
 Exactly. Yeah. I hope so.

[01:52:39:00 - 01:52:46:03]
Speaker 1
 I'd like to wear one of these dresses myself one day. I know. I want to try one. They're all so beautiful.

[01:52:46:03 - 01:52:46:17]
Speaker 2
 Yeah.

[01:52:46:17 - 01:52:47:12]
Speaker 1
 Gorgeous.

[01:52:47:12 - 01:52:57:08]
Speaker 2
 It's like a great one. It's fun. I'll tell you what. This is definitely probably-- this job is-- it doesn't even feel like a job. They say like if you-- what's the saying?

[01:52:57:08 - 01:52:58:04]
Speaker 3
 You love what you do?

[01:52:58:04 - 01:53:11:11]
Speaker 2
 Yeah, if you love what you do. You're not working. You're never working. Right. You know that. You're paying and you're saying-- Yeah, I love what I do. Real estate. And so like when you love what you do, and then we get to come together and help people find their dream dresses.

[01:53:11:11 - 01:53:12:15]
Speaker 1
 Yeah, exactly.

[01:53:12:15 - 01:53:14:19]
Speaker 2
 It's like superheroes.

[01:53:14:19 - 01:53:15:07]
Speaker 3
 Exactly.

[01:53:15:07 - 01:53:16:06]
Speaker 2
 We're kind of like superheroes.

[01:53:16:06 - 01:53:19:03]
Speaker 3
 Bridal superheroes. We are.

[01:53:19:23 - 01:53:20:00]
Speaker 1
 it.

[01:53:20:00 - 01:53:21:17]
Speaker 2
 I mean, I think you guys fit. Yeah.

[01:53:21:17 - 01:53:27:02]
Speaker 3
 Oh my god. Oh my goodness. You look so pretty. OK. Wow. OK, this one's perfect.

[01:53:27:02 - 01:53:29:09]
Speaker 2
 Oh my goodness. Yeah, thank you. You look incredible.

[01:53:30:12 - 01:53:30:23]
Speaker 1
 Wow.

[01:53:30:23 - 01:53:32:23]
Speaker 2
 Wow. You look great.

[01:53:32:23 - 01:53:35:05]
Speaker 1
 How do you feel? I feel like a princess.

[01:53:35:05 - 01:53:37:14]
Speaker 2
 I love you. You look like a princess.

[01:53:37:14 - 01:53:40:00]
Speaker 1
 Oh my god. So beautiful. This is gorgeous.

[01:53:40:00 - 01:53:41:15]
Speaker 2
 Wow.

[01:53:41:15 - 01:53:44:20]
Speaker 1
 Yeah, this is-- You love that one. I love the long tree.

[01:53:44:20 - 01:53:46:22]
Speaker 2
 Beach vibes. Yeah.

[01:53:46:22 - 01:53:48:11]
Speaker 1
 How do you feel about the beadwork?

[01:53:48:11 - 01:53:52:15]
Speaker 3
 I love the beach stuff vibes. I like the beadwork surprisingly.

[01:53:52:15 - 01:53:57:23]
Speaker 1
 Yeah. OK. Yeah, because you showed me something more simple before. So they know if you like this one.

[01:53:57:23 - 01:54:00:16]
Speaker 2
 But it does look beautiful on you. You're so pretty. You look great.

[01:54:00:16 - 01:54:00:20]
Speaker 1
 Right?

[01:54:00:20 - 01:54:01:07]
Speaker 2
 You know what?

[01:54:01:07 - 01:54:06:06]
Speaker 1
 I like how it snatches in your waist as well. Yeah. The club's really good. It looks really good on your figure.

[01:54:07:13 - 01:54:08:02]
Speaker 1
 Yeah, I love it.

[01:54:08:02 - 01:54:11:18]
Speaker 3
 I think my only concern is the beads starting to rub up my arm.

[01:54:11:18 - 01:54:21:12]
Speaker 1
 OK. Oh, I love his dancing. We want a wedding to be like 90% party. I love that. I remember you told me that. So I'm just worried about dancing in this. OK. Yeah.

[01:54:21:12 - 01:54:23:02]
Speaker 2
 Ah. Yeah.

[01:54:23:02 - 01:54:41:04]
Speaker 1
 Well, the good news is, at least the straps will keep it on while you dance, you know? It is a lot of fabric. It's a lot of fabric. But when you're on the beach, you can get a lot of flowy pictures. Oh, yeah, with the wind. The light on the beads would look nice. Yeah. It looks great. Does it feel happy too? Like walking in it? I honestly does it with all of this material.

[01:54:41:04 - 01:54:44:00]
Speaker 2
 Yeah, maybe like step down and then walk in it.

[01:54:44:00 - 01:54:45:10]
Speaker 1
 Oh, good.

[01:54:47:11 - 01:54:49:10]
Speaker 1
 Stunning. And I can picture it like that now too.

[01:54:49:10 - 01:54:50:18]
Speaker 2
 Maybe like hit the carpet a little bit.

[01:54:50:18 - 01:54:53:01]
Speaker 3
 Beautiful. Yeah. Gorgeous.

[01:54:53:01 - 01:54:54:17]
Speaker 1
 I mean, it does suit you.

[01:54:54:17 - 01:55:02:15]
Speaker 3
 So your only downside for this one-- well, not only, but it's a little uncomfortable underneath your arm with the beads rubbing.

[01:55:02:15 - 01:55:11:12]
Speaker 1
 It is a little more like ball gown than I think I would go for. Right. OK. But I think it's stunning. So it's not your dancing dress. I don't think it's my dancing dress. OK.

[01:55:11:12 - 01:55:16:06]
Speaker 2
 So we may have to get you a dance. You could get a dancing dress too. Yeah. Yeah.

[01:55:16:06 - 01:55:16:10]
Speaker 1
 OK.

[01:55:16:10 - 01:55:17:14]
 (Laughter)

[01:55:17:14 - 01:55:21:03]
Speaker 1
 Good job. You know it? That's the way you think. OK.

[01:55:21:03 - 01:55:22:13]
Speaker 2
 There's always two dresses, you know?

[01:55:22:13 - 01:55:25:22]
Speaker 1
 OK. Beautiful, but next. OK. Next.

[01:55:25:22 - 01:55:28:03]
Speaker 3
 OK. Can't wait to see the next one.

[01:55:28:03 - 01:55:29:08]
Speaker 1
 All right. I'm excited.

[01:55:30:21 - 01:55:32:13]
Speaker 1
 I'm sticking to number three, y'all.

[01:55:32:13 - 01:55:35:18]
Speaker 1
 That was number one for me. But I think three-- Yeah, I think three.

[01:55:35:18 - 01:55:43:14]
Speaker 3
 OK. Three. You're still-- We're still seeing. OK. You're still-- That could be the one that surprises us. Like that could be the one where we're-- She's like, oh.

[01:55:43:14 - 01:55:44:04]
Speaker 1
 And that's true.

[01:55:44:04 - 01:55:45:04]
Speaker 3
 We're like, oh.

[01:55:45:04 - 01:55:51:06]
Speaker 1
 That's so true. Never say never. Well, now it's down to y'all two. I'm out. She didn't like wine.

[01:56:35:07 - 01:56:36:03]
Speaker 1
 I would love to.

[01:56:36:03 - 01:56:50:10]
Speaker 2
 Yeah, no, he could tell you. So like one day I just was like. Started kicking on a skateboard and then he was like wait and so I got off and then he went and got it and just started doing it. Yeah, he just started doing it and just started kicking and I was like what?

[01:56:50:10 - 01:56:53:15]
Speaker 1
 That is so cool. I love that.

[01:56:53:15 - 01:56:57:21]
Speaker 2
 Yeah, so yeah, you ride a skateboard totally right. But you remember that one guy big and Rob or

[01:56:57:21 - 01:56:59:05]
Speaker 3
 yeah, I'll say Robin big one of their

[01:56:59:05 - 01:56:59:17]
Speaker 2
 dogs

[01:56:59:17 - 01:57:05:05]
Speaker 2
 was able to ride a skateboard. So I always wonder like is that like a bulldog thing?

[01:57:05:05 - 01:57:07:06]
Speaker 3
 Because it was a bulldog on that show wasn't it?

[01:57:07:06 - 01:57:07:21]
Speaker 2
 It was a bulldog.

[01:57:07:21 - 01:57:08:07]
Speaker 3
 Yeah.

[01:57:09:14 - 01:57:11:23]
Speaker 1
 Maybe he walks the show too much and then he's like I'm gonna learn.

[01:57:11:23 - 01:57:13:11]
Speaker 2
 He ain't never seen that show.

[01:57:13:11 - 01:57:14:08]
Speaker 1
 Oh he's never seen it.

[01:57:14:08 - 01:57:16:08]
Speaker 3
 That show is so old.

[01:57:16:08 - 01:57:17:15]
Speaker 2
 Yeah, it is an old show.

[01:57:17:15 - 01:57:20:20]
Speaker 3
 Because big passed away like years ago. Right. So like that, yeah.

[01:57:20:20 - 01:57:27:23]
Speaker 1
 Wow. Wow, wow. These two are good at sleeping. Never mind riding a skateboard.

[01:57:27:23 - 01:57:31:20]
Speaker 3
 Right. Yeah. They're good at sleeping. Yeah. It's funny.

[01:57:31:20 - 01:57:34:06]
Speaker 2
 Maybe that's why we all have dogs. That's our companion.

[01:57:35:10 - 01:57:38:13]
Speaker 1
 Oh, for sure is like hands. Yeah. Yeah.

[01:57:39:17 - 01:57:40:16]
Speaker 1
 This is who I kind of love.

[01:57:40:16 - 01:57:42:14]
Speaker 2
 My mom always says she was like, because

[01:57:42:14 - 01:57:44:07]
Speaker 2
 I, you know, we complain sometimes about our

[01:57:44:07 - 01:57:45:04]
Speaker 2
 dogs. You guys ready?

[01:57:45:04 - 01:57:47:05]
Speaker 3
 Yes, we are ready for Drew's show.

[01:57:47:05 - 01:57:48:22]
Speaker 2
 Let's go.

[01:57:48:22 - 01:57:49:14]
Speaker 1
 I

[01:57:51:07 - 01:57:51:22]
Speaker 1
 love that.

[01:57:51:22 - 01:57:55:18]
Speaker 2
 Love it. This is what it's gonna be. Can you get emotional? Oh my gosh.

[01:57:57:18 - 01:57:58:12]
Speaker 2
 You look pretty.

[01:57:58:12 - 01:58:04:10]
Speaker 1
 You look great. It's so nice. Wow. It's so beautiful. Yes. It's so pretty.

[01:58:05:10 - 01:58:09:01]
Speaker 1
 And I love the pattern on it. I think it fits that beachy vibe.

[01:58:09:01 - 01:58:09:16]
Speaker 2
 Right.

[01:58:09:16 - 01:58:11:12]
Speaker 1
 You have more of a glow in your face.

[01:58:11:12 - 01:58:13:13]
Speaker 2
 You do. You walked out like boom. Yes.

[01:58:13:13 - 01:58:17:02]
Speaker 1
 You were ready. I feel like pretty. Yeah. Wow.

[01:58:17:02 - 01:58:19:13]
Speaker 2
 You look great. You look pretty. It fits.

[01:58:19:13 - 01:58:23:10]
Speaker 1
 This one definitely fits you better than the other one.

[01:58:23:10 - 01:58:26:21]
Speaker 3
 I love this. The neckline is so flattering. Yeah.

[01:58:26:21 - 01:58:28:19]
Speaker 1
 Yeah. It's a good dancing dress.

[01:58:28:19 - 01:58:32:23]
Speaker 3
 I love the boning and the corset. It looks really good.

[01:58:32:23 - 01:58:40:07]
Speaker 1
 And it's simple but has interest. It's very classy too up top. I love how it's very just elegant. The top's my favorite. Yeah.

[01:58:40:07 - 01:58:43:14]
Speaker 3
 I told you guys graphic. You did. I told you guys graphic.

[01:58:43:14 - 01:58:47:11]
Speaker 2
 You did say it. You did say it. That looks great.

[01:58:47:11 - 01:58:50:20]
Speaker 1
 I love it. I don't know now. I felt dress number three but it might be...

[01:58:50:20 - 01:58:51:10]
Speaker 2
 You never know.

[01:58:51:10 - 01:58:52:06]
Speaker 3
 Good. You never know.

[01:58:52:06 - 01:58:54:21]
Speaker 1
 She might cry twice. You might cry twice.

[01:58:54:21 - 01:59:02:08]
Speaker 3
 Love it. I do love this one though. Sarah, you look so comfortable. You look so like... You actually do. Yeah.

[01:59:02:08 - 01:59:06:03]
Speaker 1
 And did you notice that there's beads all the way down the back?

[01:59:07:12 - 01:59:08:21]
Speaker 3
 That's beautiful detail.

[01:59:08:21 - 01:59:10:04]
Speaker 1
 I love this. That's so pretty.

[01:59:10:04 - 01:59:11:13]
Speaker 3
 Yeah. There you go.

[01:59:11:13 - 01:59:12:21]
Speaker 1
 It's very pretty.

[01:59:12:21 - 01:59:16:15]
Speaker 3
 And I love the way it's cut. It's not even like...

[01:59:16:15 - 01:59:17:04]
Speaker 1
 It's a cut out.

[01:59:17:04 - 01:59:18:02]
Speaker 3
 Yeah.

[01:59:18:02 - 01:59:18:15]
Speaker 1
 Yeah.

[01:59:20:16 - 01:59:22:09]
Speaker 1
 I love this. That's gorgeous.

[01:59:23:20 - 01:59:29:21]
Speaker 1
 Yes. It lays very nicely too. It feels like it'd be easier to carry it too. Yeah. Compared to the first. Uh-huh. I can see you in the top of me.

[01:59:29:21 - 01:59:30:19]
Speaker 2
 Garrison's gonna be like, "Oh

[01:59:30:19 - 01:59:32:10]
Speaker 3
 my gosh, I love you in the corner."

[01:59:34:08 - 01:59:34:17]
Speaker 3
 Yeah.

[01:59:34:17 - 01:59:38:18]
Speaker 2
 Yeah. I can't wait to meet this guy. He writes songs for you? He does. Oh my gosh.

[01:59:39:20 - 01:59:44:18]
Speaker 2
 Wow. Excuse these songs with our kids. Really? Aww. Yeah. I need to step my game up. Yeah.

[01:59:46:07 - 01:59:49:23]
Speaker 2
 Maybe that's why I'm single, you know. Find a girl and help me write this song. There we go.

[01:59:51:06 - 01:59:51:17]
Speaker 1
 Okay.

[01:59:51:17 - 01:59:53:14]
Speaker 2
 Oh my gosh. You should take a step down. We want to see you walk with us.

[01:59:53:14 - 01:59:57:00]
Speaker 3
 Yes, please. Please take a step down. Let's get the full look. All right.

[01:59:58:15 - 02:00:02:21]
Speaker 1
 Is it lightweight? It is. Okay. I don't know.

[02:00:02:21 - 02:00:07:00]
Speaker 2
 Yeah, I think that's one of our lighter dresses. That's why I kind of... We went with that one.

[02:00:07:00 - 02:00:08:20]
Speaker 3
 I can dance out full with having that.

[02:00:08:20 - 02:00:13:07]
Speaker 2
 Love it. Right. And you can kind of move and dance and line dance, two step, whatever you want to do.

[02:00:13:07 - 02:00:14:23]
Speaker 1
 I'm sorry. The dance moves now. I'm ready.

[02:00:14:23 - 02:00:24:07]
Speaker 3
 Yeah. It kind of has like a transparent vibe to it. Like, it looks like you can kind of see through it, but like not really. So you can tell that it's airy as well. Yeah. Yeah.

[02:00:24:07 - 02:00:26:21]
Speaker 1
 We stunning on the beach. Yes. Yeah.

[02:00:29:19 - 02:00:30:06]
Speaker 3
 Beautiful.

[02:00:30:06 - 02:00:37:08]
Speaker 1
 Yeah, it looks beautiful on you. It would match my bouquet perfectly. Oh, there we go. Awesome. That's important. Important details.

[02:00:38:15 - 02:00:41:00]
Speaker 2
 Sweet. Looks great. Dress number three.

[02:00:41:00 - 02:00:41:22]
Speaker 1
 One more dress.

[02:00:41:22 - 02:00:43:00]
Speaker 3
 Let's see it.

[02:00:43:00 - 02:00:43:16]
Speaker 2
 Let's go.

[02:00:43:16 - 02:00:48:03]
Speaker 3
 I'm excited. She's like, "I don't want to go anywhere." Take it off. I'm safe.

[02:00:48:03 - 02:00:50:20]
Speaker 2
 Do you want to get this one again? All right.

[02:00:52:09 - 02:00:52:15]
Speaker 2
 Yep.

[02:00:52:15 - 02:00:55:19]
Speaker 2
 you guys sit on the way here. She showed you dresses.

[02:00:55:19 - 02:00:58:12]
Speaker 1
 Oh yeah, so she likes, like fleas.

[02:00:58:12 - 02:00:58:23]
Speaker 2
 Fleas.

[02:00:58:23 - 02:01:04:05]
Speaker 1
 That's why I was thinking this third one. She's gonna go with for sure. But I don't know after the reaction from the last one.

[02:01:04:05 - 02:01:09:02]
Speaker 3
 Dress two. Dress two, she was glowing. She was literally glowing. Yeah, she was glowing.

[02:01:09:02 - 02:01:11:01]
Speaker 1
 And now I like that dress even more.

[02:01:11:01 - 02:01:11:17]
Speaker 3
 We're seeing it.

[02:01:12:17 - 02:01:18:06]
Speaker 2
 Well, keep in mind, you can always, if it is number two, we can always add sleeves.

[02:01:18:06 - 02:01:20:13]
Speaker 3
 If that's exactly what she's looking for.

[02:01:20:13 - 02:01:22:02]
Speaker 2
 We can always add sleeves.

[02:01:22:02 - 02:01:24:22]
Speaker 1
 That's good to know. You're always going above and beyond for your brides.

[02:01:24:22 - 02:01:27:12]
Speaker 2
 Yeah, we have to. I mean, you know, they have to have options.

[02:01:27:12 - 02:01:28:05]
Speaker 1
 Yeah, sure.

[02:01:28:05 - 02:01:31:12]
Speaker 2
 You know, I mean, there's a wedding dress and then there's a party dress.

[02:01:31:12 - 02:01:32:12]
 (Laughing)

[02:01:34:19 - 02:01:38:21]
Speaker 3
 It's her special, special day. So giving her exactly what she wants.

[02:01:38:21 - 02:01:45:17]
Speaker 2
 And this is real for her because like, think about it. Like she wouldn't have got to experience this if even this didn't happen.

[02:01:45:17 - 02:01:46:12]
Speaker 1
 Yeah.

[02:01:48:00 - 02:01:48:15]
Speaker 1
 Exactly.

[02:01:49:17 - 02:01:58:12]
Speaker 3
 And to know this is like the only thing that was like standing in their way of getting married is like, that's gold. And now she's like, yeah, that's the only thing. It's happening.

[02:01:58:12 - 02:01:59:17]
Speaker 1
 It's happening now.

[02:01:59:17 - 02:02:00:22]
Speaker 1
 It's nice to help.

[02:02:00:22 - 02:02:01:03]
Speaker 1
 Yeah.

[02:02:01:03 - 02:02:01:18]
Speaker 1
 It's amazing.

[02:02:03:01 - 02:02:04:16]
Speaker 1
 Changing lives one bride at a time.

[02:02:04:16 - 02:02:06:11]
Speaker 2
 One way. One bride at a time.

[02:02:06:11 - 02:02:07:17]
Speaker 1
 I like that. We need it

[02:02:08:19 - 02:02:09:15]
Speaker 1
 all on the front.

[02:02:09:15 - 02:02:11:08]
Speaker 2
 That does need to be on the front.

[02:02:11:08 - 02:02:13:16]
Speaker 1
 That's one bride at a time. That is cute.

[02:02:13:16 - 02:02:22:21]
Speaker 3
 I love that. That is cute. Actually that is really cute. Yeah. Next bride, I'm going to get us t-shirts, Maeve. Right. T-shirts, Maeve. Our next bride, we're pulling up to her house like that.

[02:02:22:21 - 02:02:24:13]
Speaker 1
 Oh yeah.

[02:02:24:13 - 02:02:24:13]
 (Laughing)

[02:02:24:13 - 02:02:25:12]
Speaker 1
 Oh my God.

[02:02:25:12 - 02:02:28:04]
Speaker 1
 I'll have a look. We got the dog settle sweaters too.

[02:02:28:04 - 02:02:31:01]
Speaker 2
 Yup. We do got to get the dog sweaters. That's a good idea.

[02:02:31:01 - 02:02:32:00]
Speaker 1
 Yeah that'd be so cute.

[02:02:32:00 - 02:02:33:13]
Speaker 2
 Yeah they got to meet the dogs next time too.

[02:02:33:13 - 02:02:34:04]
Speaker 1
 Yeah.

[02:02:34:04 - 02:02:36:00]
Speaker 2
 Because everybody seems to love those.

[02:02:36:00 - 02:02:37:07]
Speaker 1
 Yeah.

[02:02:37:07 - 02:02:40:11]
Speaker 3
 It'll be really nice to see. We're ready for dress number three.

[02:02:40:11 - 02:02:42:02]
Speaker 2
 Oh my God.

[02:02:42:02 - 02:02:44:05]
Speaker 1
 Oh my God.

[02:02:45:10 - 02:02:46:23]
Speaker 1
 Yeah. You look incredible.

[02:02:46:23 - 02:02:47:16]
Speaker 2
 Oh my God.

[02:02:47:16 - 02:02:49:06]
Speaker 1
 Yeah. I'm gonna cry right now.

[02:02:49:06 - 02:02:51:12]
Speaker 2
 I think you're getting ready to have a tough decision for me.

[02:02:51:12 - 02:02:52:13]
 (Laughing)

[02:02:52:13 - 02:02:53:15]
Speaker 3
 That is beautiful.

[02:02:53:15 - 02:02:54:09]
Speaker 2
 Oh my goodness.

[02:02:55:22 - 02:02:59:11]
Speaker 3
 The squeeze. It's perfect. Yeah. It's so perfect. Yes.

[02:02:59:11 - 02:03:00:10]
Speaker 1
 Oh my gosh you're making me cry.

[02:03:00:10 - 02:03:16:11]
Speaker 3
 That corset. I love the deep corset. Yeah the deep V there. Love that. So pretty. It sits on your waist just perfect. You're like the perfect length. Yeah I'm ready to walk down the aisle. You ready? Yeah. I knew it, dress number three. I gotta get a picture of this one too. Oh my gosh.

[02:03:16:11 - 02:03:21:10]
Speaker 1
 It looks gorgeous the lace on your hands too. But it's just like stunning for photo.

[02:03:21:10 - 02:03:22:13]
Speaker 2
 Oh my gosh.

[02:03:22:13 - 02:03:24:00]
Speaker 1
 I need a picture of this too.

[02:03:24:00 - 02:03:24:22]
Speaker 2
 You love the sleeves?

[02:03:24:22 - 02:03:28:22]
Speaker 1
 I love the sleeves. Beautiful. You look like a princess, like genuinely.

[02:03:28:22 - 02:03:32:19]
Speaker 3
 Wow. Yeah. Can we see the back? Okay. Oh yeah.

[02:03:32:19 - 02:03:41:13]
Speaker 1
 This just suits your body in every way. Yeah it's so flattering. Oh yes. Oh okay the train. Wow. Look at myself though.

[02:03:41:13 - 02:03:42:21]
Speaker 3
 Oh yeah.

[02:03:42:21 - 02:03:43:04]
 (Laughing)

[02:03:43:04 - 02:03:45:14]
Speaker 3
 I'm sorry. I remember playing me.

[02:03:45:14 - 02:03:47:11]
Speaker 1
 I'm already tearing up over here.

[02:03:47:11 - 02:03:48:16]
Speaker 2
 Oh my gosh.

[02:03:48:16 - 02:03:52:12]
Speaker 1
 Done it, I wanna go get you a hug. Yeah, literally.

[02:03:53:18 - 02:03:54:04]
Speaker 1
 Wow.

[02:03:54:04 - 02:03:55:15]
Speaker 3
 That is beautiful Sarah.

[02:03:55:15 - 02:03:59:23]
Speaker 1
 How do you feel in this dress? Like compared to dress two? I feel like a white.

[02:03:59:23 - 02:04:01:03]
Speaker 2
 You feel like a white?

[02:04:01:03 - 02:04:03:07]
 (Laughing)

[02:04:03:07 - 02:04:04:06]
Speaker 2
 I love you.

[02:04:04:06 - 02:04:05:09]
 (Laughing)

[02:04:05:09 - 02:04:08:16]
Speaker 3
 I think I'm a white. No that is beautiful.

[02:04:08:16 - 02:04:13:17]
Speaker 2
 I feel like a white. I love, that was like the best answer ever. I feel like a white. I feel like a white.

[02:04:13:17 - 02:04:18:13]
Speaker 3
 I love the sleeves, how long they go in your hands. I love that.

[02:04:18:13 - 02:04:22:15]
Speaker 1
 You look like a medieval princess or something. I know. I look amazing. I don't know.

[02:04:23:17 - 02:04:24:12]
Speaker 2
 I'm medieval princess.

[02:04:24:12 - 02:04:27:12]
Speaker 3
 She's us. Just Renaissance? Renaissance.

[02:04:27:12 - 02:04:28:22]
Speaker 2
 Yeah, oh Renaissance. Yeah.

[02:04:28:22 - 02:04:36:06]
Speaker 1
 Yeah, it's just sitting on a rent-a-castle. I feel like photos on the, I feel like you're running on the beach with a water.

[02:04:36:06 - 02:04:40:15]
Speaker 1
 No you need like a horse on the beach in this dress. You should like take a castle from her music.

[02:04:40:15 - 02:04:42:00]
Speaker 1
 Yes, yes.

[02:04:43:10 - 02:04:43:21]
 (Laughing)

[02:04:45:00 - 02:04:48:09]
Speaker 1
 Oh it's gorgeous. Oh my gosh. The back is so pretty.

[02:04:48:09 - 02:04:50:00]
Speaker 3
 The back is gorgeous.

[02:04:50:00 - 02:04:52:19]
Speaker 1
 I imagine the back also goes down like this, right?

[02:04:52:19 - 02:04:54:20]
Speaker 3
 It does. It does, yeah.

[02:04:54:20 - 02:04:55:17]
Speaker 1
 Yeah.

[02:04:55:17 - 02:04:56:01]
Speaker 3
 Yeah.

[02:04:56:01 - 02:04:58:17]
Speaker 2
 Is this your yes dress? Is this the dress?

[02:04:58:17 - 02:05:00:05]
Speaker 3
 I think this is the dress.

[02:05:00:05 - 02:05:01:03]
Speaker 2
 This is the dress.

[02:05:02:12 - 02:05:02:16]
 (Cheering)

[02:05:02:16 - 02:05:05:17]
Speaker 3
 Yes, so exciting.

[02:05:05:17 - 02:05:07:20]
Speaker 2
 Good job. All right, good job.

[02:05:07:20 - 02:05:10:07]
Speaker 3
 Awesome. You guessed it right. She wins.

[02:05:12:01 - 02:05:12:02]
 (Laughing)

[02:05:12:02 - 02:05:14:22]
Speaker 3
 I was a close contender. I'm gonna have to go to the club.

[02:05:14:22 - 02:05:17:12]
Speaker 2
 Yay, I'm so glad we're done.

[02:05:17:12 - 02:05:17:22]
Speaker 3
 It's beautiful.

[02:05:17:22 - 02:05:19:04]
Speaker 1
 Okay I can't keep looking at myself.

[02:05:19:04 - 02:05:21:01]
 (Laughing)

[02:05:21:01 - 02:05:22:19]
Speaker 3
 I love it. Oh my gosh, it's amazing.

[02:05:22:19 - 02:05:29:01]
Speaker 2
 Is this what you envisioned like since you were a little girl? It's better than what? Better? Oh my gosh. Oh my gosh, chills look.

[02:05:29:01 - 02:05:32:03]
Speaker 1
 Oh, you're making me cry. I've been trying not to cry.

[02:05:32:03 - 02:05:32:22]
Speaker 1
 I've already been.

[02:05:32:22 - 02:05:34:15]
Speaker 2
 My cheeks are gonna blow up.

[02:05:34:15 - 02:05:34:22]
 (Laughing)

[02:05:34:22 - 02:05:42:13]
Speaker 1
 You're just like blowing right now. Like genuinely, like you're just, oh my gosh, you're glowing. And it just shows that this dress was like made for you.

[02:05:42:13 - 02:05:43:11]
Speaker 1
 Yes.

[02:05:43:11 - 02:05:44:05]
Speaker 2
 I think so.

[02:05:44:05 - 02:05:46:03]
Speaker 3
 Yes, it looks made for you.

[02:05:46:03 - 02:05:48:11]
Speaker 1
 Garrison is not gonna, know what, hit him.

[02:05:48:11 - 02:05:49:05]
Speaker 3
 He's not.

[02:05:49:05 - 02:05:50:12]
 (Laughing)

[02:05:50:12 - 02:05:52:09]
Speaker 1
 I just know he's gonna ball his eyes out.

[02:05:52:09 - 02:05:53:13]
Speaker 3
 He's gonna ball his eyes out.

[02:05:53:13 - 02:05:54:06]
Speaker 1
 I'm gonna walk down to this dress.

[02:05:55:10 - 02:05:58:18]
Speaker 3
 I'm so excited for you. Yeah. Aw. You look great.

[02:06:00:06 - 02:06:00:06]
 (Laughing)

[02:06:00:06 - 02:06:01:03]
Speaker 3
 All right Dom.

[02:06:02:11 - 02:06:06:21]
Speaker 3
 I'm like stuck. You're getting ready to tear up yourself. All right. You're so funny.

[02:06:06:21 - 02:06:10:03]
Speaker 2
 do you wanna veil? You gonna wear a veil? Ooh, yeah. All right,

[02:06:10:03 - 02:06:12:12]
Speaker 2
 so I'm going to pick a veil. All right.

[02:06:12:12 - 02:06:15:08]
Speaker 3
 I want to see it. I want to come look at it.

[02:06:15:08 - 02:06:18:13]
Speaker 1
 Yes, I am. I want to see it up close, too.

[02:06:18:13 - 02:06:23:13]
Speaker 3
 Oh, my goodness. Yes. You look great. Oh, my goodness.

[02:06:23:13 - 02:06:26:17]
Speaker 16
 I got to give you a hug, too, because you said you have to give me a hug. I love that.

[02:06:26:17 - 02:06:31:21]
Speaker 1
 Congratulations. I love that. Congratulations. I love a hug as well. Congratulations. Thank you. It's like a princess.

[02:06:31:21 - 02:06:33:01]
Speaker 3
 So beautiful.

[02:06:33:01 - 02:06:37:00]
Speaker 16
 This is so exciting. Wow. Yeah. Unreal.

[02:06:37:00 - 02:07:36:05]
Speaker 18
 Thanks, Dave. Sit down, please. Three, two, one, action.

[02:07:36:05 - 02:07:42:00]
Speaker 8
 I wanna see it. I wanna see it. Okay, cool. I can't. I can't. I just gave you a hug. It was amazing.

[02:07:43:05 - 02:07:47:00]
Speaker 8
 Congratulations. Thank you. Thank you. It's so beautiful.

[02:07:48:06 - 02:07:58:16]
Speaker 8
 You look so great. You look like a princess. This detail is it. I love the deep V. That's my favorite part. Perfect. Yeah. Gorgeous. So flattering.

[02:07:59:23 - 02:08:03:08]
Speaker 8
 The neckline just suits you. Yeah, that's how it kinda comes out like this.

[02:08:03:08 - 02:08:04:03]
Speaker 18
 Mm-hmm.

[02:08:05:05 - 02:08:09:06]
Speaker 8
 Oh my gosh, the belt. The moment we're waiting for. Four tears.

[02:08:09:06 - 02:08:10:07]
 (Laughing)

[02:08:11:14 - 02:08:25:15]
Speaker 8
 Wow. Oh my gosh. I actually have chills right now. I have never seen a veil. In a veil. Okay. Ooh, that just turned it up a notch. Wow. Yeah, you better not turn around. You can't let go. It literally looked like a prince.

[02:08:25:15 - 02:08:29:03]
Speaker 2
 Everything can step down. That way you can get the full effect of it.

[02:08:29:03 - 02:08:30:03]
Speaker 8
 Wow.

[02:08:31:21 - 02:08:32:11]
Speaker 8
 Amazing.

[02:08:36:17 - 02:08:37:03]
Speaker 2
 Wow.

[02:08:38:18 - 02:08:41:01]
Speaker 18
 Can we have our turn, can we have our turn this way? Yeah. Turn this

[02:08:42:12 - 02:08:43:22]
Speaker 18
 way? No. Step up and go again.

[02:08:45:23 - 02:08:47:15]
Speaker 18
 Okay, bye. Tiffany,

[02:08:52:03 - 02:08:54:22]
Speaker 18
 come here and get the mirror shot. Yeah.

[02:08:57:00 - 02:08:59:16]
Speaker 18
 Come on in and shot me.

[02:09:00:22 - 02:09:02:01]
Speaker 8
 Oh yeah, I guess we get this.

[02:09:03:08 - 02:09:03:14]
Speaker 8
 You good?

[02:09:03:14 - 02:09:04:17]
Speaker 2
 Mm-hmm. Got it.

[02:09:04:17 - 02:09:08:16]
Speaker 18
 What do you want us to do? I'm just going in. No, you're good there. Okay.

[02:09:12:02 - 02:09:12:07]
Speaker 2
 Wow.

[02:09:15:16 - 02:09:19:12]
Speaker 8
 Girls, come, come, come, come. Come here, come here, please. Come, come here.

[02:09:19:12 - 02:09:20:14]
Speaker 2
 Oh my gosh.

[02:09:20:14 - 02:09:26:18]
Speaker 18
 Sir, we will be out if you can move me here. Kinda out of your face. Stay. That's where you're going. Down,

[02:09:29:10 - 02:09:31:14]
Speaker 18
 girls down. Down, girls down. Girls, awake.

[02:09:33:23 - 02:09:34:21]
Speaker 8
 Oh my God, guys.

[02:09:34:21 - 02:09:39:19]
Speaker 18
 You have it to look. All right, three, two, one, action.

[02:09:42:06 - 02:09:45:00]
 (Laughing)

[02:09:46:07 - 02:09:46:12]
Speaker 8
 Aww.

[02:09:49:18 - 02:10:00:01]
Speaker 8
 You feel like a wife? I feel like a wife. Yeah. Yeah. Oh man. Amazing. Stunning. Grace. Wow. You see, come. Absolutely stunning.

[02:10:01:16 - 02:10:10:11]
Speaker 8
 This ties the whole look together. It's unreal. Yep. Oh, look at that. That looks so pretty. Yes. Every detail is stunning.

[02:10:12:03 - 02:10:12:13]
Speaker 2
 Oh, I love it.

[02:10:13:14 - 02:10:14:08]
Speaker 2
 Is this the veil?

[02:10:16:03 - 02:10:17:00]
Speaker 2
 I think so.

[02:10:17:00 - 02:10:19:13]
Speaker 8
 Imagine it dragging along the face.

[02:10:19:13 - 02:10:20:01]
Speaker 2
 Yep. All right.

[02:10:20:01 - 02:10:21:02]
Speaker 8
 It's so pretty.

[02:10:22:14 - 02:10:26:23]
Speaker 2
 And then looking garrison in his eyes. I can't even think about that. He's seeing you for the first time.

[02:10:28:18 - 02:10:30:00]
Speaker 8
 You can cry one, two, three, two.

[02:10:30:00 - 02:10:31:07]
Speaker 2
 Okay, good.

[02:10:32:18 - 02:10:34:14]
Speaker 2
 Well, it's a story, it's y'all's story, you know?

[02:10:35:22 - 02:10:37:14]
Speaker 2
 Thanks for letting us be a part of it, you know?

[02:10:37:14 - 02:10:40:21]
Speaker 18
 Yeah, thank you. Yes, thank you so much.

[02:10:40:21 - 02:10:55:00]
Speaker 28
 is this the yes dress? Yes. Awesome. Good job, everybody. We have to go celebrate. Yeah. Let's do it. Let's do it. Let's go. Can I be at the Texas Hospital? Yeah. For now.

[02:13:45:06 - 02:14:02:17]
Speaker 15
 My first thoughts when I met the bride is she's beautiful and I could tell the energy of her and Garrison was real. And, you know, they were really in love and I love the way he looked at her and she was genuinely so excited to be a part of the experience. So I felt excited.

[02:14:04:04 - 02:14:16:22]
Speaker 3
 Well, my favorite part about the dress that Sarah chose today was the corset. I'm a corset girly, so anything that's like tugging your body and your waist is right up my alley. I really love the sleeves.

[02:14:16:22 - 02:14:31:06]
Speaker 3
 They ended at her knuckles, so I think in photos, that's going to be like amazing in their wedding photos with their rings as a detail. And honestly, just seeing her in it, like she was glowing. So I don't know if I would like the dress myself, but having it and seeing it on her,

[02:14:32:07 - 02:14:32:16]
Speaker 3
 loved it.

[02:14:34:12 - 02:15:09:03]
Speaker 1
 it means to me being a part of her journey today is so much deeper than you could ever imagine. It's helping somebody that has had the dream wedding in their head and having it come to life. It's seeing the motion and being a part of such a vulnerable, intimate moment. And seeing how beautiful she felt, it just warmed my heart. And just sitting there on the couch, I was holding back tears. And this is just something I'm so excited this project of just giving back to so many women that have the dream of getting married. And I'm just excited, so.

[02:15:11:00 - 02:15:22:14]
Speaker 2
 When Sarah started crying, whenever she tried on her wedding dress, for me, it kind of brought my whole vision together. Being, you know, this whole vision came about from

[02:15:22:14 - 02:15:25:22]
 (Blank Audio)

[02:15:25:22 - 02:15:48:08]
Speaker 3
 I'm crying.

[02:15:52:08 - 02:15:53:21]
Speaker 2
 She's like, "I can't stop looking at myself."

[02:16:04:05 - 02:16:04:20]
Speaker 2
 Are

[02:16:09:02 - 02:16:10:03]
Speaker 2
 you getting us?

[02:16:10:03 - 02:16:10:22]
Speaker 23
 It's fire.

[02:16:17:18 - 02:16:22:00]
Speaker 14
 Wait, wait, wait. It's definitely a breath.

[02:16:22:00 - 02:16:24:01]
Speaker 18
 It looks so pretty on you. No.

[02:16:24:01 - 02:16:28:02]
Speaker 14
 I'm gonna have to give it a shot. Yeah.

[02:16:31:02 - 02:16:31:18]
Speaker 24
 He's a sichin.

[02:16:33:09 - 02:16:33:20]
Speaker 18
 Yeah, you did.

[02:16:33:20 - 02:16:35:10]
Speaker 24
 Yeah, you did.

[02:16:35:10 - 02:16:35:20]
Speaker 18
 Yeah.

[02:16:37:21 - 02:16:43:18]
Speaker 3
 Like, how is she going to go into another breath and have her actually feeling like that in order? Right. Right. Right.

[02:16:45:07 - 02:16:54:08]
Speaker 3
 Right. Oh, yeah. That's what she said. Yeah. Yeah. Yeah. Yeah.

[02:16:55:08 - 02:16:56:02]
Speaker 3
 Yeah.

[02:16:58:02 - 02:17:06:11]
Speaker 18
 I'm trying to look at her. She said, "I'm trying to get her out of here." Yeah. Yeah, she's like, "I'm trying to get her out of here."

[02:17:06:11 - 02:17:13:20]
Speaker 2
 have to go through in life, you know? And so being in Bridal, one, I love fashion.

[02:17:15:15 - 02:17:40:15]
Speaker 2
 I love to empower women. I think it's really important for women to feel seen and beautiful and loved, encouraged. And so getting into Bridal, it's that first opportunity to, you're being a part of somebody's forever, right? It's the beginning of someone's possible forever. And so having a Bridal store, being able to serve a community

[02:17:42:23 - 02:17:50:03]
Speaker 2
 and still encourage people after divorce, I feel like my testimony and my story can actually encourage people

[02:17:51:05 - 02:17:55:19]
Speaker 2
 to know that, this guy, why did he get in Bridal? Why is he

[02:17:56:21 - 02:18:01:09]
Speaker 2
 helping him? Why does he still love marriage? How does he still love marriage after everything that he's been through?

[02:18:02:12 - 02:18:19:03]
Speaker 2
 Because I think marriage is beautiful. And I've seen what marriage actually looks like when two people love each other and they work together and they work hard about loving one another and caring for one another. Like I've seen it with my own eyes, my family. And so,

[02:18:21:16 - 02:18:25:00]
Speaker 2
 if we, Bridal, we get, this is the beginning. This is a covenant love.

[02:18:26:08 - 02:18:39:06]
Speaker 2
 That bride is in that white dress and it's purity and it's pure and the moment is so pure. And then I just love to be able, when you're sitting there in an appointment and,

[02:18:41:20 - 02:19:20:13]
Speaker 2
 to me, I kind of think of it like when she was a little girl, she kind of pictured in her head what her dream dress was gonna look like. You know? So when I look at them, I look at them probably how their mom's looking at them. You know, this is my little baby and she's always been, you know, and so she kind of knew. And so to be able to curate the process, I'm a creative and I love to be able to create that moment for these brides. So just being a creative, you know, being a servant at heart and a creative and I love fashion. And so I'm just blessed to have this opportunity to be at the beginning of these brides forever moment.

[02:19:20:13 - 02:19:26:16]
Speaker 19
 going back tonight? He hired me to bridal risers. I love their rings.

[02:19:27:23 - 02:19:34:08]
Speaker 19
 Oh, yeah? So it's like the dressing room. They keep showing my eyes. Oh, yeah? So the dresses are dragging. And Shopee is the...

[02:19:36:04 - 02:19:36:09]
Speaker 19
 Right.

[02:19:38:01 - 02:19:39:12]
Speaker 19
 How did Chris play?

[02:19:41:08 - 02:19:43:05]
Speaker 27
 I'm a blonde dance instructor. I know.

[02:19:44:09 - 02:19:45:09]
Speaker 15
 He had to be on Instagram.

[02:19:49:11 - 02:19:50:20]
Speaker 27
 I'm not the best at seeing you guys.

[02:19:53:03 - 02:19:54:13]
Speaker 19
 I am.

[02:19:54:13 - 02:19:55:19]
Speaker 1
 I am. I am. I am. I am. I am.

[02:19:55:19 - 02:19:56:14]
Speaker 27
 I am. I am. I am.

[02:19:59:17 - 02:20:02:06]
Speaker 1
 Oh, like for lunch?

[02:20:02:06 - 02:20:03:20]
Speaker 15
 How much is bar taco for lunch?

[02:20:03:20 - 02:20:07:20]
Speaker 1
 I mean, honestly, just everything, you know, helping people do this whole project.

[02:20:07:20 - 02:20:12:08]
Speaker 15
 You know the margaritas go down like water. Oh, wow. You ever go there?

[02:20:13:10 - 02:20:14:09]
Speaker 15
 I could, maybe.

[02:20:14:09 - 02:20:15:04]
Speaker 1
 Oh, really?

[02:20:15:04 - 02:20:20:05]
Speaker 19
 I know it's glass full. I know it's glass full. Yeah, when I was in here, I'd go to— Thank you.

[02:20:20:05 - 02:20:21:09]
Speaker 15
 I'm going to get a break from Frankie.

[02:20:21:09 - 02:20:27:08]
Speaker 1
 I'm going to go to glass. Just break from Frankie? I do. I'm an army soul soldier. I should tell. Yeah, I'm sorry.

[02:20:44:01 - 02:20:44:06]
Speaker 1
 laughter]

[02:20:46:22 - 02:20:49:01]
Speaker 1
 I'm gonna go back in the theater room and have a nap.

[02:20:52:06 - 02:20:54:14]
Speaker 15
 They're really good dogs.

[02:20:57:18 - 02:20:58:01]
Speaker 1
 I like my dress.

[02:20:59:04 - 02:21:01:08]
Speaker 1
 I like my dress. I'm really cute.

[02:21:03:01 - 02:21:04:19]
Speaker 19
 I was like welcome back.

[02:21:06:18 - 02:21:07:08]
Speaker 19
 laughter Yeah.

[02:21:09:03 - 02:21:09:10]
Speaker 19
 Yeah.

[02:21:10:12 - 02:21:11:01]
Speaker 19
 I did that.

[02:21:12:15 - 02:21:14:23]
Speaker 19
 I was like my

[02:21:18:17 - 02:21:20:08]
Speaker 15
 hair is not working so hot it is.

[02:21:21:17 - 02:21:22:09]
Speaker 15
 I was like my hair is not working so hot it is. I love you Ryan.

[02:21:25:10 - 02:21:26:22]
Speaker 19
 I'm coming back to talk to you.

[02:21:26:22 - 02:21:28:14]
Speaker 15
 I'm going to talk to you. Yeah. Come

[02:21:29:20 - 02:21:30:04]
Speaker 15
 on girls.

[02:21:30:04 - 02:21:33:16]
Speaker 1
 You don't have a drink do you want one? Sorry guys.

[02:21:33:16 - 02:21:34:22]
Speaker 19
 Alright.

[02:21:36:08 - 02:21:36:15]
Speaker 15
 Come on.

[02:21:38:07 - 02:21:38:15]
Speaker 19
 Get

[02:21:40:00 - 02:21:40:07]
Speaker 19
 the money.

[02:21:42:00 - 02:21:42:09]
Speaker 19
 Girls.

[02:21:43:18 - 02:21:45:02]
Speaker 19
 She's my friend Quinn.

[02:21:45:02 - 02:21:48:06]
Speaker 1
 Thank you not to support. Gia. Yousif.

[02:21:52:03 - 02:21:53:07]
Speaker 27
 What are you wanting?

[02:21:53:07 - 02:21:54:08]
Speaker 19
 I'll get you some.

[02:21:55:22 - 02:22:00:06]
Speaker 19
 Oh. Stay here. I don't think you guys are here.

[02:22:01:10 - 02:22:04:18]
Speaker 1
 I've only had a special moment of like help in here.

[02:22:04:18 - 02:22:05:15]
Speaker 1
 I think

[02:22:07:00 - 02:22:13:00]
Speaker 1
 you. I'm really good. I'm so good. I'm so proud of myself. That's the biggest thing.

[02:22:13:00 - 02:22:16:10]
Speaker 15
 Thank you. I'm proud.

[02:22:19:17 - 02:22:24:12]
Speaker 1
 I'm not dating right now. I'm just like happy I don't have a plan. I genuinely.

[02:22:24:12 - 02:22:33:19]
Speaker 1
 I've done a lot of shadow work on myself. I'm really looking at the patterns I have. Like why am I attracting people? Why am I not loving myself enough?

[02:22:33:19 - 02:22:40:02]
Speaker 19
 And not having standards. A lot. Well I think that you can see. Okay.

[02:22:41:11 - 02:22:45:10]
Speaker 19
 Okay. Yeah. Okay.

[02:22:49:13 - 02:22:49:23]
Speaker 27
 Okay.

[02:22:49:23 - 02:22:53:04]
Speaker 19
 So it's that type of place. I think I might be eight though. I'm really cry.

[02:22:56:00 - 02:23:00:22]
Speaker 19
 Okay. I feel like I can fit in. But I don't. You know

[02:23:02:09 - 02:23:06:02]
Speaker 19
 what I'm doing. What are you doing? What are you doing?

[02:23:07:02 - 02:23:07:07]
Speaker 19
 Okay.

[02:23:09:18 - 02:23:10:05]
Speaker 19
 Thank you.

[02:23:12:22 - 02:23:19:09]
Speaker 19
 Thank you. I did do this. Thank you. I appreciate it. Close your round.

[02:23:19:09 - 02:23:22:09]
Speaker 1
 I'm proud of you. You're glowing and doing amazing.

[02:23:22:09 - 02:23:28:18]
Speaker 19
 Okay. I went to a taco place in that area. That's the closest to Nashville. Are

[02:23:29:23 - 02:23:30:17]
Speaker 19
 they still in town?

[02:23:31:20 - 02:23:33:06]
Speaker 15
 I want to see mom and dad.

[02:23:33:06 - 02:23:35:10]
Speaker 1
 I love your parents.

[02:23:35:10 - 02:23:36:15]
Speaker 19
 My mom.

[02:23:37:22 - 02:23:38:20]
Speaker 19
 So I did kind of.

[02:23:41:05 - 02:23:42:00]
Speaker 1
 Shut up.

[02:23:43:17 - 02:23:45:00]
Speaker 1
 Yes. TikTok shop.

[02:23:46:00 - 02:23:46:08]
Speaker 19
 I'm joking.

[02:23:47:13 - 02:23:49:12]
Speaker 1
 They don't have Broncos on TikTok shop.

[02:23:50:13 - 02:23:52:14]
Speaker 1
 I order all my quotes on TikTok shop.

[02:23:52:14 - 02:23:54:20]
Speaker 15
 There we go.

[02:23:54:20 - 02:23:58:09]
Speaker 1
 Oh, same. I think the ride from Amazon.

[02:23:59:09 - 02:23:59:17]
Speaker 1
 I'm like.

[02:24:00:22 - 02:24:05:03]
Speaker 19
 Oh, is that one night? He was out two days a week. I don't know.

[02:24:06:20 - 02:24:09:03]
Speaker 19
 He was across the street. I don't know.

[02:24:12:02 - 02:24:12:06]
Speaker 19
 I could

[02:24:13:14 - 02:24:14:07]
Speaker 19
 be telling stories.

[02:24:15:07 - 02:24:21:08]
Speaker 1
 She had a Jeep previously, right? She had a Bronco. Oh, she had a Bronco. We talked about that one. You have a Jeep.

[02:24:21:08 - 02:24:21:15]
Speaker 1
 I remember

[02:24:22:19 - 02:24:27:14]
Speaker 1
 one day we went to Hot Yoga. My mom loves. I don't know why I thought I was doing it.

[02:24:29:10 - 02:24:30:11]
Speaker 1
 So what color is it?

[02:24:31:13 - 02:24:32:12]
Speaker 1
 You'll have to show me a photo.

[02:24:32:12 - 02:24:35:07]
Speaker 1
 I'm like a very good person. I barely ate today.

[02:24:37:00 - 02:24:37:15]
Speaker 1
 Gorgeous.

[02:24:37:15 - 02:24:41:13]
Speaker 1
 I'm going to take a video of it. How are you doing? I'm good.

[02:24:41:13 - 02:24:42:19]
Speaker 27
 Are you enjoying

[02:24:44:06 - 02:24:45:10]
Speaker 27
 your time? Yes.

[02:24:45:10 - 02:24:46:05]
Speaker 15
 Thank

[02:24:48:21 - 02:24:51:19]
Speaker 15
 you. It's been a very smooth three days of filming.

[02:24:51:19 - 02:24:53:00]
Speaker 27
 It's been what?

[02:24:53:00 - 02:24:58:10]
Speaker 15
 It's been a smooth three days of filming. It's been good. It's not a natural credit.

[02:24:58:10 - 02:25:00:03]
Speaker 27
 Have you all been able to get on and have a good time?

[02:25:00:03 - 02:25:04:03]
Speaker 15
 Yeah, we went to full classes for dinner. I've heard of that place.

[02:25:05:15 - 02:25:07:11]
Speaker 15
 I'm just going

[02:25:09:22 - 02:25:11:23]
Speaker 15
 to get a drink. Can I speak to behind you?

[02:25:11:23 - 02:25:12:19]
Speaker 1
 Thank you.

[02:25:15:22 - 02:25:16:05]
Speaker 15
 Hi.

[02:25:17:13 - 02:25:23:01]
Speaker 15
 Hi. Nice to meet you. You're one of my best friends. I invited her and Kia.

[02:25:23:01 - 02:25:23:20]
Speaker 1
 Glad you made it.

[02:25:26:00 - 02:25:29:00]
Speaker 1
 She's an artist. She sings as well. I do.

[02:25:30:11 - 02:25:32:23]
Speaker 15
 Country pop, basically.

[02:25:34:01 - 02:25:36:03]
Speaker 15
 Sorry, I'm a little disoriented. I'm going to

[02:25:37:06 - 02:25:42:04]
Speaker 15
 have a red wine, please. Can I have a red wine, please? Yeah. She's taking care of her dogs, too. Those

[02:25:43:06 - 02:25:43:19]
Speaker 15
 are my puffins.

[02:25:44:21 - 02:25:47:07]
Speaker 15
 Great to Frankie. Oh, I love it.

[02:25:48:22 - 02:25:51:07]
Speaker 15
 They've been really good dogs, actually, this whole time.

[02:25:51:07 - 02:25:57:00]
Speaker 1
 It's just a lot to take about. They go to loving kids. That's what they said. They're like, "No,

[02:25:58:02 - 02:25:59:01]
Speaker 1
 she's a cute dog."

[02:25:59:01 - 02:26:01:11]
Speaker 15
 Did you want to get it for Frankie? Okay, yeah. Yeah,

[02:26:02:13 - 02:26:03:18]
Speaker 15
 they're cute. Oh,

[02:26:05:04 - 02:26:05:18]
Speaker 15
 yeah.

[02:26:05:18 - 02:26:11:21]
Speaker 1
 I was like, because I swing dance, I was like, "You two swing dance?" I was like, "I'll do swing dance." Yeah, you have to do it in the night, too. We've got to get numbers and stuff.

[02:26:11:21 - 02:26:13:00]
Speaker 27
 I

[02:26:14:15 - 02:26:24:02]
Speaker 27
 do a lot of corporate and private events right now at the factory in Franklin. You know where that's at? Yeah. I've been doing that for the last three weeks. Next Monday will be my last Monday there.

[02:26:25:02 - 02:26:33:00]
Speaker 27
 But then I think we're figuring out how to get a bigger space. It's been such a big turnout. I guess people in Franklin didn't realize they went on the line dance.

[02:26:33:00 - 02:26:34:12]
Speaker 19
 Wow.

[02:26:35:22 - 02:26:37:15]
Speaker 27
 I'm excited that y'all didn't come. I know.

[02:26:37:15 - 02:26:40:02]
Speaker 15
 I know. I'll be back for CMAFS.

[02:26:40:02 - 02:26:42:01]
Speaker 27
 Okay. I'll see you at home. I'm

[02:26:43:12 - 02:26:45:02]
Speaker 27
 sure we'll have some. Y'all got to come out.

[02:26:45:02 - 02:26:49:04]
Speaker 15
 Oh, yeah. No, I need to line dance with you. That's a lot. It's happening.

[02:26:49:04 - 02:26:52:10]
Speaker 1
 It's right. Line dancing is so fun.

[02:26:52:10 - 02:26:59:19]
Speaker 27
 It is fun. I believe in the beginning of the club, absolutely. There's one in New York and one in Texas. I'm happy to be back

[02:27:00:20 - 02:27:01:02]
Speaker 27
 to bed.

[02:27:01:02 - 02:27:04:16]
Speaker 1
 It would be fun. Yeah. Yeah. This one. Great. Sorry.

[02:27:05:23 - 02:27:15:14]
Speaker 19
 I have a fear. Danielle. Nice to meet you. I love the outfit. Nice jacket. That's cool. I feel something really nice. I'm going to grab a jacket.

[02:27:16:17 - 02:27:22:18]
Speaker 15
 They look so pretty. They're like, "Hey, how are you?" Oh, yeah. No, isn't it beautiful out here? No. Sorry. It's so gorgeous.

[02:27:22:18 - 02:27:24:07]
Speaker 27
 These houses. I love it.

[02:27:24:07 - 02:27:27:06]
Speaker 15
 They're like, "I love it."

[02:27:27:06 - 02:27:34:08]
Speaker 1
 I love this. I love this. I'm manifesting this. I'm like, "I want the pool, the barbecue area. We're on the same bike." Oh, yeah. Well, this one is going to buy land.

[02:27:34:08 - 02:27:57:12]
Speaker 15
 And I need to look out to Minnie Ponies. Oh, my goodness. Yeah. I found my house in Leifer's Fork. I was out there winery around. I was at wineries. And this house was so mean. You look right outside. There's too many ponies. There's people like dogs running around. It was gated. It was just like rolling hills. Oh, my gosh. It's a big, tall entryway. I'm like, "Yeah."

[02:27:57:12 - 02:28:05:03]
Speaker 1
 Yeah. See myself out here. It's just the real estate is so expensive, though, because everybody's moving here. We were talking about that earlier. It's like, "Leifer's Fork is my dream as well."

[02:28:05:03 - 02:28:10:01]
Speaker 1
 But I looked it up one day. I was like, "There has to be a cheaper area." No. Over a million everywhere.

[02:28:10:01 - 02:28:20:00]
Speaker 15
 Oh, that's Toronto? Like, you're going to get a bungalow for a million. Really? I was like, "Everywhere's expensive." It's one of those. Wow. Oh, Toronto's insane.

[02:28:20:00 - 02:28:25:04]
Speaker 1
 Is that why you're in the real estate market there? She does commercial and... And residential.

[02:28:25:04 - 02:28:37:00]
Speaker 15
 That's amazing. Yeah. It's just like I like selling homes. I was an interior designer for eight years, so I'm very detail-oriented. I like two-oriented homes. Oh, I see that. I see that now.

[02:28:37:00 - 02:28:37:23]
Speaker 1
 I'm going to book everything.

[02:28:37:23 - 02:28:41:17]
Speaker 1
 But I like that about you, because I feel like she's that way, too.

[02:28:41:17 - 02:28:44:15]
Speaker 1
 I need funds that are very... Everybody has their driven-through challenges,

[02:28:44:15 - 02:28:53:07]
Speaker 1
 but it brings out the best of me. I love my detail-oriented funds. I know what they want. I don't have a question. If you're feeling something, you're just going to say it. I can be very

[02:28:53:07 - 02:28:59:10]
Speaker 1
 type A, but I'm going to be type B, but I'm going to be a type A. I'm fine. Whatever she likes to drive. I agree with that.

[02:28:59:10 - 02:29:07:05]
Speaker 15
 I want to be honest with the point where I'm like... Right now, I'm kind of like a type B, because I'm so tired from filming. I have to drive 11 hours to come to a car

[02:29:08:06 - 02:29:21:05]
Speaker 15
 with my dogs. Where do you drive you when you're like that? I am going to be on like 75, and anyways, I'm going to weave around and go through Buffalo. I came through Detroit. I'm going to go back to Buffalo. I'm more of a senior drive.

[02:29:22:14 - 02:29:24:11]
Speaker 1
 I kind of like a stolen too.

[02:29:25:19 - 02:29:39:04]
Speaker 15
 At first. So, because I'm Canadian, my phone carrier won't connect my phone. So I literally have to drive 9 hours with no contact from anyone unless I stop and get Wi-Fi. It only works on Wi-Fi.

[02:29:40:06 - 02:29:42:00]
Speaker 15
 Yeah. That's what I'm feeling with.

[02:29:43:04 - 02:29:59:23]
Speaker 15
 Is your car... I bought the same car. Oh yeah. I got a random car. Yeah, I'm good that way. It's just more like... It's going to be a long drive. You know? I'm talking to my dog. I'm looking around. We're going to the radio. Yeah. Right.

[02:30:01:06 - 02:30:07:02]
Speaker 15
 Yeah. I'm always singing along, but it's just... Yeah. It's been quite the trip. One thing after

[02:30:07:02 - 02:30:12:22]
Speaker 15
 another. Are you from here, or...? I'm originally from Brooklyn, Ohio. Oh. So, I'm fine.

[02:30:14:00 - 02:30:16:07]
Speaker 15
 I have actually been to Ohio before.

[02:30:17:09 - 02:30:20:13]
Speaker 15
 Pretty. It's cute. It's so cute. I feel

[02:30:21:23 - 02:30:31:17]
Speaker 15
 like we were just about right there. It was a great place to grow up. Let me come back home and visit. Specifically in the summer. Hey, so I'm going to have Barbara Pittsburg. Am I wrong? Being a kid two and a half times. Okay.

[02:30:31:17 - 02:30:33:16]
Speaker 19
 Yeah. So I definitely have been there. Yeah.

[02:30:34:18 - 02:30:35:22]
Speaker 19
 Yeah. Yeah.

[02:30:35:22 - 02:30:42:05]
Speaker 15
 Yeah. So what made you move here? I moved here more than once. You seem like you're doing two girls there for a few years before I moved here.

[02:30:42:05 - 02:30:47:14]
Speaker 1
 Okay. I was in the bathroom. You're glowing. I walked on your chair. Yeah. Yeah.

[02:30:47:14 - 02:30:55:01]
Speaker 1
 I get down here doing good. What's happening? I'm like, "How are you doing?" Oh, can you guys go to LA together? No. Oh, okay.

[02:30:55:01 - 02:31:00:06]
Speaker 15
 Oh, okay. Okay. I'm getting good. And you know, life always happens in town. I introduced that. Okay.

[02:31:01:13 - 02:31:08:05]
Speaker 15
 Yeah. I thought it would be... Yeah. I know. I know. It is rare to find girls. They're probably your first year. Genuine

[02:31:09:23 - 02:31:14:13]
Speaker 15
 people. Yeah. There's a lot of... Yeah. ...cater... Yeah. ...is miserable.

[02:31:14:13 - 02:31:15:14]
Speaker 1
 Exactly. It's the worst.

[02:31:15:14 - 02:31:20:09]
Speaker 15
 It's the worst. Yeah. Female friendship. That's why I like them here because Toronto's very much that scene.

[02:31:20:09 - 02:31:28:05]
Speaker 1
 They're very entitled like dating there. Yeah. Is a nightmare. Or it's like because you don't have that kind of... Absolute sour. ...of that. The men are very like...

[02:31:28:05 - 02:31:52:05]
Speaker 15
 No, I really like them now. They're not really like men. I mean, y'all are just... I don't know. I've heard that same thing here. The dating... What? ...is... Yeah. I feel like the men are nicer. It's a Southern-western talent. That's it. Yeah. I'm just gonna cry. You're so good about it. Here, like I walked in the four seasons and this guy picks me and my friend and I. Nice to meet you. I'm Samantha. Are you gorgeous? Yeah. I love your haircut.

[02:31:53:09 - 02:32:00:06]
Speaker 15
 Yeah, because he's like a good potential. Maybe. Yeah. And like that just doesn't really happen at home. This is just... I love...

[02:32:01:07 - 02:32:07:00]
Speaker 15
 It's fun, right? Oh, yeah. I mean, you probably had that happen here too. And LA is... Yeah. It can be like that.

[02:32:07:00 - 02:32:08:01]
Speaker 1
 It can be.

[02:32:08:01 - 02:32:12:00]
Speaker 19
 Hey, so listen up. Are you three? Yeah. You have to stay together.

[02:32:12:00 - 02:32:17:19]
Speaker 27
 Oh, got it. Because you're having side conversations and you're most picky at all of them. Everybody's talking about your face.

[02:32:17:19 - 02:32:22:19]
Speaker 1
 Yeah. Yeah, so you guys are always having... You three are always in the same conversation. That's what you need to be.

[02:32:22:19 - 02:32:27:04]
Speaker 19
 Okay, so back to work. Good idea. Thank you. Okay. I'm Danielle.

[02:32:27:04 - 02:32:33:19]
Speaker 1
 Nice to see you. Nice to meet you. I'm gonna fill this up a little bit so it looks good for camera. How are you? I'm here. Are you dog-scrambled?

[02:32:33:19 - 02:32:35:09]
Speaker 19
 Okay, now it's time.

[02:32:35:09 - 02:32:37:04]
Speaker 15
 What do you think of it?

[02:32:37:04 - 02:32:39:19]
Speaker 1
 I don't have a clue. I'm gonna take the next one.

[02:32:39:19 - 02:32:41:10]
Speaker 15
 Yeah, that's how you get there.

[02:32:41:10 - 02:32:44:07]
Speaker 19
 Big round to yourself. Thank you, by the way.

[02:32:45:23 - 02:32:46:01]
Speaker 15
 Thank

[02:32:47:16 - 02:32:48:03]
Speaker 15
 you, Danielle.

[02:32:48:03 - 02:32:54:03]
Speaker 1
 Nice to meet you. Okay, so where is both? Just like so nice. Stick together, I guess. What do you do?

[02:32:54:03 - 02:32:55:18]
Speaker 15
 I just meet you. Oh,

[02:32:56:21 - 02:33:05:07]
Speaker 15
 you make music too. Nice. Are you from Nashville or are you moved here? I moved here. Okay, nice. I live in here. I have four years. Okay. Yeah, I love it here. I want to move.

[02:33:06:18 - 02:33:07:12]
Speaker 15
 I'm thinking about it.

[02:33:07:12 - 02:33:07:23]
Speaker 1
 I'm gonna go to the next one.

[02:33:07:23 - 02:33:07:09]
Speaker 15
 I'm thinking about it.

[02:33:07:09 - 02:33:08:10]
Speaker 1
 I'm gonna... Yeah.

[02:33:08:10 - 02:33:19:01]
Speaker 15
 If something happens with the show, I think I'm gonna have to. Yeah. Have a place here, so. I'm doing a show right here. Yeah, I mean, with all the development here, I think getting my real estate license would be a good idea, so.

[02:33:20:07 - 02:33:21:04]
Speaker 15
 Okay, here we are.

[02:33:21:04 - 02:33:21:10]
Speaker 19
 Are

[02:33:22:13 - 02:33:25:00]
Speaker 19
 you getting another tequila? I am. Okay.

[02:33:26:07 - 02:33:36:10]
Speaker 19
 I'm from Pennsylvania, but I live in Maryland. I'm really close to DC. I'm very close to DC. Yeah, it's fine. Girl, it is fine. See, I have a good girlfriend.

[02:33:36:10 - 02:33:39:11]
Speaker 15
 Our friend, Patrick, she moved to Nashville from

[02:34:09:23 - 02:35:02:12]
 (Crowd Talking)

[02:35:02:12 - 02:35:05:10]
Speaker 6
 That's your secret weapon.

[02:35:06:10 - 02:35:07:03]
Speaker 6
 That's your secret weapon.

[02:35:09:17 - 02:35:17:09]
 (Crowd Talking)

[02:35:17:09 - 02:35:20:21]
Speaker 6
 Are you going to see a mane-thag?

[02:35:24:00 - 02:35:24:12]
 (Crowd Talking)

[02:35:25:17 - 02:35:27:02]
Speaker 6
 That's a four-five.

[02:35:28:15 - 02:35:31:08]
Speaker 6
 Yeah, have you hit his face? Yeah, that's good.

[02:35:31:08 - 02:35:32:11]
 (Crowd Talking)

[02:35:35:10 - 02:35:36:07]
Speaker 6
 Yeah, just with everyone.

[02:35:37:22 - 02:35:38:16]
Speaker 6
 Marveia.

[02:35:40:08 - 02:35:42:13]
Speaker 6
 I travel like everyone.

[02:35:44:04 - 02:35:47:04]
Speaker 6
 I love Europe.

[02:35:51:02 - 02:35:51:22]
Speaker 6
 Why was there any questions?

[02:35:51:22 - 02:35:53:18]
Speaker 6
 I just need to hide.

[02:35:56:05 - 02:36:01:03]
Speaker 6
 I'm just gonna open a child's door and have us at like three feet. I'll walk around.

[02:36:02:14 - 02:36:03:21]
Speaker 6
 There's like 30 people in.

[02:36:05:10 - 02:36:19:07]
 (Crowd Talking)

[02:36:20:11 - 02:36:24:09]
Speaker 6
 Yes, bro, mom, baby. No, this is what I had. Shut the front door.

[02:36:25:18 - 02:36:28:00]
 (Crowd Talking)

[02:36:39:17 - 02:36:42:16]
Speaker 6
 You guys, you guys, you guys. I said, "Postcard."

[02:36:43:22 - 02:36:44:08]
Speaker 6
 You guys, you guys, you guys. I said, "Postcard."

[02:36:45:12 - 02:36:47:06]
Speaker 6
 There's like totally different things.

[02:36:49:03 - 02:36:57:18]
 (Crowd Talking)

[02:37:01:08 - 02:37:01:11]
Speaker 6
 Because

[02:37:03:10 - 02:37:04:09]
Speaker 6
 that's like everywhere.

[02:37:04:09 - 02:37:14:03]
 (Crowd Talking)

[02:37:14:03 - 02:37:35:20]
Speaker 6
 It's very like to your face, like directed on it. Yeah, like, it's just a vibe I like. Yeah, I like that in a friend. Like, I feel like that's why we've been friends for so many years because they're like, "I'm here to help." And that's why I feel like there's people that are very directed on us, but with girls, that's why I operate. Because I feel like real love is on us. But it's also how you do it.

[02:37:35:20 - 02:37:39:07]
 (Crowd Talking)

[02:37:39:07 - 02:37:44:10]
Speaker 6
 I thought

[02:37:45:17 - 02:37:45:22]
Speaker 6
 I

[02:37:47:00 - 02:37:47:05]
Speaker 6
 would.

[02:37:49:05 - 02:37:50:02]
 (Crowd Talking)

[02:37:52:15 - 02:37:55:07]
Speaker 6
 I'm an artist. I'm like, "I wish I was a student of mine."

[02:37:57:05 - 02:38:04:01]
 (Crowd Talking)

[02:38:04:01 - 02:38:06:11]
Speaker 6
 We're literally bonding.

[02:38:07:19 - 02:38:11:08]
 (Crowd Talking)

[02:39:00:13 - 02:39:07:02]
Speaker 26
 about Ogforth leaving And that's my pain to purpose story.

[02:39:07:02 - 02:39:08:07]
Speaker 6
 And that's my pain to be friendly.

[02:39:08:07 - 02:39:12:18]
Speaker 26
 I literally have a note, my home that says, "Trolls the match." Okay.

[02:39:13:21 - 02:39:14:13]
 (Chattering)

[02:39:16:16 - 02:39:18:08]
Speaker 6
 Okay, you guys. That's pretty cool.

[02:39:20:22 - 02:39:21:22]
 (Upbeat Music)

[02:39:21:22 - 02:39:22:04]
Speaker 6
 Oh my

[02:39:23:04 - 02:39:23:21]
Speaker 6
 gosh, I love it.

[02:39:23:21 - 02:39:26:20]
Speaker 26
 You too. I just live off this and why?

[02:39:27:22 - 02:39:30:07]
Speaker 6
 Yeah, she could really why. Oh my gosh.

[02:39:31:10 - 02:39:40:00]
 (Chattering)

[02:39:40:00 - 02:39:40:04]
Speaker 6
 I

[02:39:41:07 - 02:39:41:14]
Speaker 6
 know.

[02:39:43:15 - 02:39:45:07]
 (Chattering)

[02:39:45:07 - 02:39:45:08]
Speaker 6
 Yeah, come

[02:39:46:23 - 02:39:54:07]
Speaker 6
 here. I was like, now we shouldn't be. That's all I can think about. I'm putting my first out. You're doing better.

[02:39:55:21 - 02:40:01:01]
 (Chattering) (Upbeat Music)

[02:40:01:01 - 02:40:27:17]
Speaker 1
 Like, you're gonna be on the show, like, I have big plans for you, and... Oh my. You gotta come film the teaser, I'm like, okay. This is good exposure, you know? Big it. Yeah, if it goes somewhere. Yeah. Oh my gosh, literally. I know, right? Yeah, it's amazing. Exactly. Yes. I haven't really eaten one. Wait, who hurt? Yeah. Oh. Oh yeah. So does mine. Oh

[02:40:29:09 - 02:40:42:14]
Speaker 1
 yeah, I know. Um, my friend from Miami actually just joined his team. Oh yeah? Yeah, uh, named Mark. I'm biased. I've never pronounced his last name. Yeah, I think I'm gonna say Dr. The T's gonna be on owning Miami. I think they're just a little sweeter than me.

[02:40:42:14 - 02:40:45:17]
Speaker 1
 Alright, that's gonna be a little juicier. Uh-huh.

[02:40:45:17 - 02:40:48:17]
Speaker 1
 So you go to, like, Ryan's seminars and stuff?

[02:40:48:17 - 02:40:55:08]
Speaker 1
 No. No, he's a little better. Oh, cool. Well, I'm wondering when you'll be back. I'm sitting in the studio.

[02:40:56:14 - 02:40:59:17]
Speaker 1
 Oh yeah? Mmm. Oh, are you guys in the studio? Yeah.

[02:40:59:17 - 02:41:01:18]
Speaker 1
 I have a good feeling. I don't know.

[02:41:01:18 - 02:41:02:12]
Speaker 1
 About everything.

[02:41:02:12 - 02:41:03:21]
Speaker 1
 Like social media, then you.

[02:41:03:21 - 02:41:05:17]
Speaker 1
 I can

[02:41:07:18 - 02:41:09:06]
Speaker 1
 see that. Now his whole thing

[02:41:10:11 - 02:41:19:16]
Speaker 1
 is so crazy. Now his whole thing is like building California back up after the fires. And he's got a whole plan there. Okay.

[02:41:21:21 - 02:41:27:10]
Speaker 15
 Yeah. I was wondering where they were at. Yeah, they've been hanging out in the theater room.

[02:41:28:16 - 02:41:32:04]
Speaker 1
 Boiled dogs. I got a little like, not a one-year-old. Yeah.

[02:41:32:04 - 02:41:32:10]
Speaker 1
 I know. I know. I was

[02:41:34:06 - 02:41:35:20]
Speaker 1
 like, oh, you're like a life-sou.

[02:41:35:20 - 02:41:38:19]
Speaker 1
 No, I do that too. My entire life. I like that. You enjoy yourself?

[02:41:38:19 - 02:41:46:21]
Speaker 1
 Isn't that cool? Isn't that cool? It's like the music. It's like the music. It's like the song that it has. It's like the song that it has. He designed the house himself. Yeah.

[02:41:48:07 - 02:41:48:15]
Speaker 1
 Uh-oh.

[02:41:50:15 - 02:41:54:21]
Speaker 1
 Yeah. It's like new ones? You have new ones. All right. Girls, people, sorry. No.

[02:41:56:00 - 02:41:57:05]
Speaker 1
 Or I had to get them out there with parking.

[02:41:57:05 - 02:42:01:05]
Speaker 1
 But yeah. What I love about, like, my girlfriend and her family. Actually, like, should I roll up with the dogs? I don't know.

[02:42:03:02 - 02:42:08:10]
Speaker 1
 It's like people will be aligned with you. You made a comment earlier that said that to me. People are a mirror. Oh, I should get my wine.

[02:42:08:10 - 02:42:13:08]
Speaker 1
 And I am so strong on that. Would you like pass me that wine? I'm supposed to run in there. Thank you.

[02:42:13:08 - 02:42:21:08]
Speaker 1
 Really value yourself. Come on, girls. And like boundaries of humans. And really value yourself in no way. Babe, can you move your drink? No. Thank you.

[02:42:22:10 - 02:42:42:02]
Speaker 1
 If you sit with the other ones and do that, then... Hi, girls. I think everything kind of lines after that. It's not that life's going to be easy. And you don't have to, like, in the dating world. The joining the party for a second. In the fighting world. It's not like you're not going to have to set boundaries. I'm just going to take her. Just to recap what we're talking about. Oh, let's hear you say it. What are you talking about?

[02:42:42:02 - 02:42:46:19]
Speaker 15
 Yeah, I was just saying the dogs are just joining the party for a quick second. Oh, I was just going to say hi.

[02:42:46:19 - 02:42:53:22]
Speaker 1
 Hey, girls. They're so beautiful. Like, we want food. I know. You know, I'm still a sucker for that. Like, if I'm, like, eating, it's just like, I'm not going to be able to do anything.

[02:42:53:22 - 02:42:45:06]
Speaker 15
 I'm just going to say hi.

[02:42:47:11 - 02:43:00:22]
Speaker 1
 Hey, girls. They're so beautiful. Like, we want food. I know. I know. I'm still a sucker for that. Like, if I'm, like, eating, it's... I hate to say it, but my dog is... They're like, "Don't let her be a beggar, because they'll be trained." Yeah, there are not a lot of people who...

[02:43:00:22 - 02:43:09:20]
Speaker 15
 Oh, really? Well, they're just too tiny, and they're, like, allergic to chicken. Oh, yeah. They're just not like this big. Yeah. So, it's just not worth it for them to go to the vet. Oh, I would never.

[02:43:09:20 - 02:43:12:22]
Speaker 1
 I would never give them food. Yeah. Two hours later. Great. I'm not going to give them food.

[02:43:12:22 - 02:43:17:04]
Speaker 15
 I wonder who that was.

[02:43:17:04 - 02:43:26:10]
Speaker 1
 I will know who the call-up party is. I will know. Actually, probably anyone would give them food. I see. Here. They're cute. Yeah. They're too cute.

[02:43:27:18 - 02:43:31:19]
Speaker 1
 I know. I find that, like, I like the nice two-night You're

[02:43:31:19 - 02:43:35:18]
Speaker 15
 so cute. Go say hi. You want to go say hi? Oh, no. You want to go say hi?

[02:44:03:21 - 02:44:09:22]
Speaker 1
 You chose me. I

[02:44:12:21 - 02:44:13:21]
Speaker 1
 chose you.

[02:45:01:18 - 02:45:08:00]
Speaker 15
 I

[02:45:08:00 - 02:45:12:22]
Speaker 1
 chose you.

[02:45:31:02 - 02:45:44:08]
Speaker 1
 I chose you.

[02:46:04:09 - 02:46:04:13]
Speaker 15
 I

[02:46:07:02 - 02:46:13:02]
Speaker 15
 chose you.

[02:46:50:03 - 02:46:50:16]
Speaker 1
 I chose you.

[02:47:22:00 - 02:47:22:10]
Speaker 1
 I chose you.

[02:47:33:06 - 02:47:33:07]
Speaker 15
 I chose

[03:09:01:11 - 03:09:02:20]
Speaker 29
 You guys got a nice little day night.

[03:09:04:03 - 03:09:05:16]
Speaker 29
 Yeah, how you guys feeling? Good.

[03:09:06:20 - 03:09:07:01]
Speaker 29
 Yeah.

[03:09:07:01 - 03:09:09:12]
 (Music Playing)

[03:09:09:12 - 03:09:14:17]
Speaker 29
 Letting us know where you guys probably had an even still week here. Yeah.

[03:09:17:11 - 03:09:20:04]
Speaker 29
 So I'm going to introduce you to my friends.

[03:09:22:21 - 03:09:23:02]
 (Music Playing)

[03:09:26:11 - 03:09:27:05]
Speaker 29
 Congratulations.

[03:38:10:11 - 03:38:12:11]
 (Blank Audio)

[03:46:22:06 - 03:46:26:21]
Speaker 15
 I'm Danielle, nice to meet you. I went line dancing for Carlos.

[03:46:28:00 - 03:46:29:10]
Speaker 1
 So, um, yeah, we're partnering for you.

[03:46:29:10 - 03:46:30:10]
Speaker 19
 From where?

[03:46:30:10 - 03:46:46:21]
Speaker 15
 Toronto. Nice, did you line for this? I actually drove here with my puppies. Which was 11 hours for the show. I've been here a week. I'm gonna get up tomorrow morning and head home. Hi, Danielle. Nice to meet you. Thank you, you too. No, I wish I did.

[03:46:46:21 - 03:46:48:13]
Speaker 19
 I'm working on it.

[03:46:49:19 - 03:46:52:02]
Speaker 15
 Have y'all been to Toronto? I've been to Toronto.

[03:46:53:06 - 03:46:56:04]
Speaker 15
 No? Oh, yeah.

[03:46:57:15 - 03:47:03:23]
Speaker 15
 Now is the time to go. Because the patio is open up and it starts to get nice. Our winters are so bad.

[03:47:03:23 - 03:47:07:17]
Speaker 6
 I think in my country, then, it was like... I like her style. She reminds me of me.

[03:47:07:17 - 03:47:12:11]
Speaker 1
 I love the mold, like that. You know what I mean?

[03:47:12:11 - 03:47:14:03]
Speaker 19
 It was nice and

[03:47:15:13 - 03:47:17:05]
Speaker 19
 even. So I kind of pulled her like this.

[03:47:19:06 - 03:47:21:00]
Speaker 19
 Yeah. And in early mornings, I'd be like,

[03:47:22:09 - 03:47:26:09]
Speaker 19
 "Who just wants to have 50 minutes?" And then I'd go into the

[03:47:27:13 - 03:47:28:04]
Speaker 19
 market.

[03:47:28:04 - 03:47:55:20]
Speaker 15
 Yeah, it's cute. We have so many great restaurants. There's lots to do, but it's not like here. I like it better. I guess I can say that because you're not from here. Yeah, but Toronto is not good. Our taxes are crazy. We're getting all these immigrants coming in. There's a lot of break-ins. I say that because... Yeah, if you compare them, you probably pick here. Okay, cool. Y'all have more to do.

[03:47:56:21 - 03:48:03:06]
Speaker 19
 I can see that because we have more fees and more months available versus you guys probably have more. And you have more people.

[03:48:04:11 - 03:48:06:19]
Speaker 15
 So like you have happy hours? We don't have that.

[03:48:07:21 - 03:48:08:17]
Speaker 15
 It's so boring.

[03:48:09:21 - 03:48:10:12]
Speaker 15
 Oh, like everyone.

[03:48:11:19 - 03:48:12:20]
Speaker 15
 I can't just move. I

[03:48:13:20 - 03:48:18:16]
Speaker 15
 can't just move and work. I have to get a visa, which is like a whole roster.

[03:48:18:16 - 03:48:20:15]
Speaker 19
 I'm married to my ex-tear. I tried that.

[03:48:22:12 - 03:48:29:02]
Speaker 15
 See that you get to get your papers and stuff? That's a whole story in itself. Yeah, it's a crazy

[03:48:30:02 - 03:48:38:11]
Speaker 15
 story. Kind of. I was married for three months. And then we went to do Bikes at a Model and Gig there and he stayed. So when you were right here...

[03:48:40:05 - 03:48:42:11]
Speaker 15
 Yeah, when he found out I was seeing someone else.

[03:48:42:11 - 03:48:44:22]
Speaker 6
 He's like, "But you can't get your visa."

[03:48:45:22 - 03:48:48:05]
Speaker 6
 He's going through like the door, seeing a single user.

[03:48:50:07 - 03:48:55:11]
Speaker 15
 Because meanwhile he lied to me and said he owned a company that was on display. He believed in him. He's a quick two.

[03:48:56:21 - 03:49:14:03]
Speaker 27
 He's still there. If you don't know me, my name is Justin Lee. Not that that matters right now. But I am a country line dancer instructor. So we're going to learn how to do a line dance. Make it look real fun, make it look real good. And I've got a feeling everybody out here can dance. But what we're going to do... First of all, let's get in our lines where we're going to be.

[03:49:15:04 - 03:49:17:21]
Speaker 27
 So we're going to do the first line right here. Maybe I should let you all do it.

[03:49:17:21 - 03:49:20:06]
Speaker 1
 No, we're all doing it together.

[03:49:20:06 - 03:49:22:19]
Speaker 15
 I haven't done it in years.

[03:49:22:19 - 03:49:23:20]
Speaker 1
 I feel like we should be in front.

[03:49:23:20 - 03:49:26:09]
Speaker 6
 He's a professional teacher.

[03:49:27:18 - 03:49:33:09]
Speaker 6
 Let's be in front, guys. I feel bold to me. Two passes a woman. I'm feeling good. I'm feeling

[03:49:35:22 - 03:49:38:12]
Speaker 15
 good. I'm all sticky and all the cheese.

[03:49:38:12 - 03:49:41:04]
Speaker 1
 I had to keep you waiting for me.

[03:49:41:04 - 03:49:42:06]
Speaker 15
 Don't let me over there.

[03:49:42:06 - 03:49:43:10]
Speaker 1
 You're so bougie.

[03:49:44:12 - 03:49:45:06]
Speaker 1
 It's the line.

[03:49:45:06 - 03:49:48:08]
Speaker 15
 I already know. Here's how you learn. Oh,

[03:49:49:09 - 03:49:50:17]
Speaker 15
 you can learn me it easy.

[03:49:50:17 - 03:49:54:07]
Speaker 19
 Everybody take a step to the left.

[03:49:54:07 - 03:49:55:11]
Speaker 21
 One step to the left.

[03:49:55:11 - 03:49:56:21]
Speaker 2
 Are we doing it this way?

[03:49:59:03 - 03:50:03:06]
Speaker 28
 I really got to get in the front. You got to get in here. Okay, wait.

[03:50:05:11 - 03:50:08:18]
Speaker 1
 And nobody falls in the back. No one falls in the back. Come on in.

[03:50:10:21 - 03:50:14:19]
Speaker 6
 I went on this side for a reason. So, let me get you a chance to please.

[03:50:14:19 - 03:50:15:16]
Speaker 27
 Behind the scenes.

[03:50:17:01 - 03:50:40:20]
Speaker 27
 All right. First thing first. I'm going to do a lot of talking. That way you can understand what we're doing. I'm not going to spend too much time on this. Before we start, just to get everybody excited. On three, we're going to do a big yeehaw. She likes yeehaw. On three. One, two, three. Yeehaw. There we go.

[03:50:42:03 - 03:51:09:01]
Speaker 27
 Don't we do this a lot? Okay, so this just means from the top, say we're halfway through the dance, so we need to go back to the beginning. I'll say from the top, we'll start at the beginning up until what we learned. All right. Here we go. So, if you don't know how to do the right-bound, it's going to be the first thing we do. We're going to do the right-bound to the left. If you don't know how to do it, whichever direction we're going, you're going to start off with that foot. So, if we're going to the right, you start off with your right foot, left foot goes behind. We need to kind of see through.

[03:51:10:06 - 03:51:15:01]
Speaker 27
 And then if we're going to the left, you start off with your left foot, right foot goes behind. Take that last step and then we clap.

[03:51:16:02 - 03:53:05:17]
Speaker 27
 So, I count you at five, six, seven, eight. We're going to go right, left, right with the cap, and left, right, left with the cap. Yeehaw. Yeehaw. Let's do it again because I saw a lot of people at the game. Five, six, seven, eight, go right, left, right, and left, right, left. I'm going to explain that one more time. You want to come in? You start off with that foot. So, if we're going to the right, you start off with your right foot. Left foot is going to follow behind that right foot. You're going to the left. You start off with the left foot, right foot goes behind. So, one more time. Do the right. Five, six, seven, eight, go right, left, right, and left, right, left. Everybody get that right? Yeehaw. Okay, y'all scoot forward. Say two steps. Everybody scoot forward two steps. There we go. So, we just did our great body to the right, great body to the left. Now, what we're going to do is three steps back, starting on our right foot. We're going to go right, left, right, and end on our left heel. Take your three steps back. Can you in five, six, seven, eight? We're going to go right, left, right, heel. Let's do it again. Three steps back. Five, six, seven, eight, go right, left, right, heel. One more time. Three steps back. Five, six, seven, eight, go right, left, right, heel. Hold right there. Next part, we're going to call this our rock steps. You lean forward on your left foot, tap that right toe, lean back on that toe. Lean back on that right foot, tap that left heel. So, again, lean, tap, back, tap. Five, six, seven, eight, lean, tap, back, tap. Just one more time. We're going to move our feet. Lean that body weight to the front, tap that right toe. Lean to the back, tap that left heel. So, again, lean, tap, back, tap. Five, six, seven, eight, lean, tap, back, tap. I'm struggling. Let's do it from the top.

[03:53:05:17 - 03:53:07:02]
Speaker 6
 Harder than you.

[03:53:07:02 - 03:53:08:02]
Speaker 15
 I know. It is.

[03:53:08:02 - 03:53:08:17]
Speaker 6
 No, it is.

[03:53:08:17 - 03:53:10:03]
Speaker 21
 It looks extremely intense.

[03:53:10:03 - 03:53:31:10]
Speaker 27
 You know what I'm about to call the full school board just a little bit, all right? Okay. Great bound to the right. Great bound to the left. Three steps back, going to our rock steps, all right? Five, six, seven, eight, go right, left, right, with the tap. Left, right, left, go back. Right, left, right, heel. And toe, and heel. How many people got that right?

[03:53:33:02 - 03:53:33:17]
 (Cheering)

[03:53:33:17 - 03:53:39:01]
Speaker 27
 Yeah. If you didn't get there, we can do it one more time. One more time.

[03:53:39:01 - 03:53:40:07]
Speaker 15
 All right, from the top, ready?

[03:53:40:07 - 03:53:49:21]
Speaker 27
 Eight, go right, left, right, and left, right, left, go back. Right, left, right, heel. And toe, and heel.

[03:53:49:21 - 03:53:51:13]
 (Cheering)

[03:53:51:13 - 03:53:52:15]
Speaker 27
 I know that.

[03:53:53:20 - 03:53:54:00]
 (Laughter)

[03:53:54:00 - 03:53:54:11]
Speaker 27
 Take it off.

[03:53:55:12 - 03:54:32:13]
Speaker 27
 We're almost there. I'm sorry. We have four walls that we go off of. Let's just know if we're going to do a quarter turn, half turn, three quarter turn, full turn, all right? Good. Ball one, ball two, ball three, wall four. In this instance, we're only going to do a quarter turn, so we'll be facing this duration, all right? Okay. How we're going to do that? We just did our rock steps. Lean, tap, tap, tap. So we got that left heel in front of us. We're going to take a step forward on this left foot, stuff that right foot across the ground, quarter turn, affect this wall. As soon as that right foot comes down, it's our first step back into the grapevine, all right? So we're back at the beginning of the dance.

[03:54:33:15 - 03:54:38:17]
Speaker 21
 Like the Charlie Shuffle thing. Yeah. Watch me real quick. I'll count you in five, six, seven, eight.

[03:54:38:17 - 03:54:39:20]
Speaker 6
 Got this. Yeah.

[03:54:40:21 - 03:54:42:22]
Speaker 6
 I'm going to turn up your feet.

[03:54:42:22 - 03:55:07:01]
Speaker 27
 Kick it right, go right, left. Oh, okay. And left, right, left. Let's do it one more time, and then we're going to do it all the way from the top. Here we go. Five, six, seven, you got that left foot in front of you. Five, six, seven, eight, go step. Kick, right, left, right with the clap, and left, right, left with the clap. Yeehaw! Yeehaw! All right, let's do it one more time.

[03:55:07:01 - 03:55:10:08]
Speaker 28
 Thank you for taking it on. Here we go. No, no, no. From the top.

[03:55:11:09 - 03:55:14:21]
Speaker 1
 It's hard to watch it because if I was on the other side, I could see it.

[03:55:14:21 - 03:55:33:20]
Speaker 27
 Five, six, seven, eight, go right, left, right, and left, right, left, go back, right, left, right, heel, and toe. And heel, go step, kick, right, left, right, and left, right, left. All right, we have to do this real quick. Now y'all are my new friend. You're the friend. Thank you for watching.

[03:55:33:20 - 03:55:35:18]
Speaker 1
 I'm so glad he moved because I can't see any.

[03:55:37:11 - 03:55:58:15]
Speaker 27
 We're doing it right. Which one are we going to be facing if we're doing it right? There we go. Here we go. From the top. Five, six, seven, eight, go right, left, right, and left, right, left, go back, right, left, right, heel, and toe. And heel, go step, kick, right, left, right, and left, right, left, left, left, and left, right, left. All right.

[03:56:00:11 - 03:56:00:15]
Speaker 27
 Okay.

[03:56:00:15 - 03:56:03:01]
Speaker 21
 Like patty-kitty patty-kitty.

[03:56:05:02 - 03:56:06:07]
Speaker 1
 Okay,

[03:56:07:08 - 03:56:10:06]
Speaker 1
 this is wrong to do after drinking. This is wrong.

[03:56:10:06 - 03:56:11:18]
Speaker 21
 I need to do this.

[03:56:11:18 - 03:56:18:01]
Speaker 27
 Okay, ready? Okay, go right, left, right, and left, right, left, go back.

[03:56:18:01 - 03:56:21:09]
Speaker 15
 One, two, three. And heel, and bow.

[03:56:23:12 - 03:56:24:19]
Speaker 6
 You didn't see it? You didn't see it?

[03:56:24:19 - 03:56:26:02]
Speaker 27
 I'm trying.

[03:56:27:18 - 03:56:28:11]
Speaker 27
 Yeehaw.

[03:56:30:16 - 03:56:32:02]
Speaker 6
 Yeah, yeah, yeah, you didn't see it. It's the heels.

[03:56:32:02 - 03:56:33:08]
Speaker 27
 Ready?

[03:56:37:20 - 03:56:38:05]
Speaker 19
 Right.

[03:56:38:05 - 03:56:46:03]
Speaker 1
 How can you? It's, it's, oh, it's tight. Okay. You know? You're good at this. You're so good. You're kind of fast.

[03:56:46:03 - 03:56:48:03]
Speaker 6
 Oh, good teacher classes.

[03:56:49:09 - 03:56:54:18]
Speaker 6
 Cheater. Cheater. You guys swinged it. That was so fun. Thank you very much. Again. I'm a swing dancer.

[03:56:54:18 - 03:56:57:21]
Speaker 1
 I'm a swing dancer. But I'm not. I've really done my dance.

[03:56:58:22 - 03:56:59:16]
Speaker 1
 Oh my gosh, you're,

[03:57:00:22 - 03:57:17:20]
Speaker 1
 teacher. Can I teach you a little swing dance for you? Yeah, you want me to teach you actually? Yeah, because the thing is, I've never done that. So I was uncomfortable doing something I've never done. But you pick it up like the pickleball. Yeah. Okay, hand behind back. Ready? Yeah. Are we still learning more? No, we're not doing it. Oh, we're about to do it. We're about to do it. Oh, we're doing it.

[03:57:17:20 - 03:57:35:16]
Speaker 15
 Oh, we're doing it. Oh, we're doing the songs. We're doing the song. Oh. I need to try slide dance. Are you doing another tequila? I love it. Really? Okay, so my first song. We're doing it. But I see it. Yeah. I used to do it too. Oh, wait. I used to have another bit of badminton to get a sense of.

[03:57:35:16 - 03:57:36:21]
Speaker 6
 Let's dance later.

[03:57:36:21 - 03:57:38:10]
Speaker 15
 Wait, oh my god, I love this.

[03:57:38:10 - 03:57:40:05]
Speaker 27
 I love this. I don't think we have it.

[03:57:40:05 - 03:57:43:08]
Speaker 1
 Okay. Do they want me to do this? They're fighting where you at.

[03:57:43:08 - 03:57:44:20]
Speaker 21
 Oh, I'm doing it.

[03:57:46:09 - 03:57:48:01]
Speaker 28
 Just don't think. I'm really good at this.

[03:57:48:01 - 03:57:54:18]
Speaker 1
 So if I like, am offbeat. And if you tell them, "Wow." I'm like, "I'm good at this." Okay, ready? Okay. I got

[03:57:56:14 - 03:57:56:17]
Speaker 1
 this.

[03:57:58:02 - 03:57:58:11]
Speaker 1
 I got this.

[03:57:58:11 - 03:58:01:05]
Speaker 15
 Y'all didn't see this. My eight breakings.

[03:58:01:05 - 03:58:05:05]
Speaker 19
 Just don't think. Everybody put your hands together. Here we

[03:58:06:11 - 03:58:06:16]
Speaker 19
 go.

[03:58:06:16 - 03:58:29:14]
Speaker 27
 Here we go! Go back, left, seven, four. And right, move right. And left, right, move left. Go back, right, move left. Left, left, left, and four. Okay. You got it. Let's do it. Okay. Left, left, and toe. And here we go. Step, kick, right, left. Right, and left, right, left. Go back, right, left, right. And toe. And here we go. Step, kick, right, left, right.

[03:58:29:14 - 03:58:32:14]
Speaker 21
 Okay. You got it. Just not my thing. Right?

[03:58:32:14 - 03:58:33:06]
Speaker 27
 Look at you.

[03:58:33:06 - 03:58:34:19]
Speaker 21
 You got my thing. That's it.

[03:58:34:19 - 03:58:41:10]
Speaker 27
 And here we go. Okay. Right, left, right, and left, right, left. Go back, right,

[03:58:42:14 - 03:58:50:06]
Speaker 27
 hip, ho. Okay. Okay, six. And here we go. Right, left, right, left, go back and right.

[03:58:51:15 - 03:58:52:09]
Speaker 27
 Yeah!

[03:58:52:09 - 03:58:56:10]
Speaker 6
 Okay, now I'm gonna go up and kill this man.

[03:58:57:20 - 03:58:58:20]
Speaker 6
 Don't say I'm wrong.

[03:58:58:20 - 03:59:04:01]
Speaker 27
 Left, right, heel, toe, heel, hip, right,

[03:59:05:12 - 03:59:08:00]
Speaker 27
 and left, go back, right,

[03:59:09:04 - 03:59:09:12]
Speaker 27
 heel,

[03:59:11:04 - 03:59:18:09]
Speaker 27
 heel, hip, and left, go back to up and so forth. Left, right, heel,

[03:59:18:09 - 03:59:23:17]
Speaker 21
 heel, heel, hip, right,

[03:59:23:17 - 03:59:26:10]
Speaker 19
 left, go back, right, heel, heel, heel, heel, hip, left, right, left, go back.

[03:59:26:10 - 03:59:27:10]
Speaker 27
 Okay, we're going.

[03:59:27:10 - 03:59:29:09]
Speaker 6
 Yeah, you got it. This is hard.

[03:59:30:18 - 03:59:31:02]
Speaker 21
 Okay.

[03:59:32:21 - 03:59:32:21]
Speaker 6
 Thank

[03:59:34:14 - 03:59:34:17]
Speaker 6
 you.

[03:59:36:14 - 03:59:39:12]
Speaker 6
 I like that one. I tried, I tried.

[03:59:40:15 - 03:59:43:13]
Speaker 6
 It was so fun. Thank you. I'm gonna stick to swinging.

[03:59:46:15 - 03:59:51:03]
Speaker 1
 It's not my thing. It's not my thing. It was fun. Oh my God.

[03:59:51:03 - 03:59:52:03]
Speaker 6
 I love that.

[03:59:53:20 - 03:59:55:10]
Speaker 19
 I'm gonna watch a YouTube.

[03:59:56:12 - 03:59:58:20]
Speaker 19
 I think

[03:59:59:22 - 04:00:02:04]
Speaker 1
 the reason why I think it's so like,

[04:00:04:08 - 04:00:04:15]
Speaker 1
 slow.

[04:00:04:15 - 04:00:05:12]
Speaker 6
 I

[04:00:08:15 - 04:00:12:00]
Speaker 6
 don't

[04:00:12:00 - 04:00:17:20]
Speaker 19
 like that. I don't like that. I was just like, well, it's more than that. Well, I was like, they were all judges.

[04:00:19:01 - 04:00:20:07]
Speaker 1
 I know we're all judges.

[04:00:20:07 - 04:00:21:19]
Speaker 6
 Oh,

[04:00:23:00 - 04:00:23:15]
Speaker 6
 that's fine.

[04:00:26:06 - 04:00:31:21]
Speaker 6
 She was like, yeah, yeah, I was. I grabbed it on the wine and the heels. It's not easy to do in heels. It's not.

[04:00:31:21 - 04:00:35:06]
Speaker 1
 Yeah, that's why I'm doing lingo. I'm like, it's the wine and the heels.

[04:00:36:19 - 04:00:41:08]
Speaker 19
 Oh, it did good, babe. It did. It did. And

[04:00:42:14 - 04:00:51:05]
Speaker 1
 the pickle wall. We definitely need to play again. These are all things, ironically, that I don't do. I would love to show you guys and get you guys to do things I'm really good at.

[04:00:51:05 - 04:00:54:15]
Speaker 15
 That y'all don't do. I love to dance.

[04:00:55:21 - 04:01:01:18]
Speaker 15
 Oh, I love. Did y'all ever go out dancing together? Yeah. I think you're really good losers.

[04:01:01:18 - 04:01:08:09]
Speaker 1
 Oh, my gosh, really? We're going to play as a loser. Really? Oh, so Chris? Alex. We were in the last night.

[04:01:09:16 - 04:01:10:00]
Speaker 15
 Yeah.

[04:01:10:00 - 04:01:15:02]
Speaker 19
 You might go to John Daly.

[04:01:16:13 - 04:01:18:17]
Speaker 19
 John Daly. Yeah.

[04:01:20:04 - 04:01:21:03]
Speaker 19
 It's in Midtown.

[04:01:22:15 - 04:01:28:19]
Speaker 1
 I know. You know how to do this. Especially on Thursdays. Midtown on Thursday. You

[04:01:30:10 - 04:01:38:04]
Speaker 1
 too. Oh, Thursday? Yeah. Losers on Thursday. Was it Tuesday? Whiskey Jam night? I feel like that's where it was fun. Don't go.

[04:01:40:05 - 04:01:40:20]
Speaker 19
 Thursday?

[04:01:40:20 - 04:01:42:09]
Speaker 15
 It's town on Thursday.

[04:01:43:15 - 04:01:44:05]
Speaker 15
 It's so good.

[04:01:45:18 - 04:01:50:07]
Speaker 1
 It's like the room is so tiny. I'm over here like... I get anxiety and big crowds.

[04:01:51:09 - 04:01:51:14]
Speaker 1
 What?

[04:01:53:00 - 04:01:54:01]
Speaker 1
 You know what?

[04:01:55:11 - 04:02:00:03]
Speaker 1
 You can't work. You want to go together? You're supposed to stay here.

[04:02:01:18 - 04:02:03:09]
Speaker 15
 Stay with me, maybe, and then we'll find Mom.

[04:02:03:09 - 04:02:04:04]
Speaker 6
 Thank you.

[04:02:04:04 - 04:02:05:12]
Speaker 15
 You guys want to sing along there?

[04:02:07:03 - 04:02:07:16]
Speaker 1
 I'm going to do a song.

[04:02:09:11 - 04:02:10:14]
Speaker 1
 I'm going to do a cheer.

[04:02:11:19 - 04:02:12:04]
Speaker 1
 I want a cheer.

[04:02:12:04 - 04:02:13:17]
Speaker 19
 I want a cheer.

[04:02:13:17 - 04:02:14:21]
Speaker 6
 That was

[04:02:16:04 - 04:02:17:22]
Speaker 6
 so fun. I want to do that again.

[04:02:17:22 - 04:02:18:23]
Speaker 19
 You did good.

[04:02:18:23 - 04:02:21:18]
Speaker 15
 Thank you. It's hard and heal.

[04:02:21:18 - 04:02:23:08]
Speaker 27
 I bet. It's so fun.

[04:02:23:08 - 04:02:24:14]
Speaker 15
 I see her.

[04:02:26:09 - 04:02:26:14]
Speaker 15
 Oh,

[04:02:28:16 - 04:02:30:02]
Speaker 15
 yeah. I'll be going down.

[04:02:31:09 - 04:02:33:11]
Speaker 27
 No, that was good. That was fun.

[04:02:34:12 - 04:02:35:07]
Speaker 27
 That was so fun.

[04:02:35:07 - 04:02:37:20]
Speaker 21
 Yeah, it was cool.

[04:02:37:20 - 04:02:38:18]
Speaker 19
 But that's your party?

[04:02:40:06 - 04:02:41:03]
Speaker 19
 What's your drink tonight?

[04:02:41:03 - 04:02:43:09]
Speaker 27
 No, mostly just like that.

[04:02:44:10 - 04:02:45:10]
Speaker 27
 It's not all pantry-dots.

[04:02:47:03 - 04:02:47:22]
Speaker 27
 I'll do that.

[04:02:50:03 - 04:02:52:07]
Speaker 27
 I'm like, okay, you look super hot.

[04:02:52:07 - 04:02:50:17]
Speaker 21
 I feel like

[04:02:53:13 - 04:02:55:01]
Speaker 21
 it's a nice little mall.

[04:02:56:09 - 04:02:58:10]
Speaker 21
 You should have one of your parties. That would be fun.

[04:02:58:10 - 04:03:02:17]
Speaker 15
 I would love to have one. Yes. Let's go.

[04:03:05:03 - 04:03:06:05]
Speaker 15
 I'm trying to.

[04:03:07:11 - 04:03:20:23]
Speaker 15
 It's not that easy to get a visa. I'm going through the process of getting my visa. And then, yes, I want to. Oh, okay. Because I'm trying to. I keep forgetting that. I know. What

[04:03:20:23 - 04:03:22:11]
Speaker 27
 is the process? How long is it like?

[04:03:23:20 - 04:03:24:19]
Speaker 15
 It's actually

[04:03:26:06 - 04:03:43:21]
Speaker 15
 just got a visa here. Like he bought a business and it came with 10 visas. So he's going to get me one. So we're going through the process right now. But then they have to take my passport for a little bit and stamp it. And then I have to go back and get it after a couple weeks. I have to make sure I'm not traveling.

[04:03:45:05 - 04:04:00:01]
Speaker 15
 It's an E2. Oh, it's a vessel. Yeah. So you can do a five or a 10 with an E2. Those are expensive. They have to be done for you. Yeah, but he's already spent all the money and done it. So I just get. Yeah, I just got to pay the lawyer.

[04:04:01:08 - 04:04:02:17]
Speaker 27
 So you'd be a bachelor in no time.

[04:04:02:17 - 04:04:06:20]
Speaker 15
 Yeah, basically. I'm on my way and then I can pass all your parties. I'm not going to lie.

[04:04:08:17 - 04:04:09:18]
Speaker 15
 No, no, you don't.

[04:04:11:16 - 04:04:14:17]
Speaker 19
 Whatever's easier. Instagram or number? You can only put that.

[04:04:14:17 - 04:04:17:20]
Speaker 15
 Yeah, we'll do Instagram.

[04:04:21:09 - 04:04:26:18]
Speaker 15
 Then you can see also when I'm in town. If we don't keep in touch.

[04:04:26:18 - 04:04:28:02]
Speaker 19
 Oh, sorry.

[04:04:29:12 - 04:04:30:09]
Speaker 6
 What kind

[04:04:31:14 - 04:04:32:15]
Speaker 6
 of doctor are you?

[04:04:33:20 - 04:04:37:18]
Speaker 21
 This is my wife. Okay. Yeah.

[04:04:38:19 - 04:04:39:08]
Speaker 15
 Oh, really?

[04:04:41:09 - 04:04:49:06]
Speaker 15
 That's me. Yeah, you are. What kind

[04:04:52:20 - 04:04:55:06]
Speaker 15
 of surgery are you doing? Everybody was in the hospital.

[04:04:57:05 - 04:04:57:15]
Speaker 19
 Okay.

[04:04:59:10 - 04:05:03:02]
Speaker 1
 It's like every safety hall. Like, look at what you did.

[04:05:04:17 - 04:05:09:13]
Speaker 21
 Wow. What are you doing? What are you doing? What are you doing? What are you doing? What are you doing? What are you doing? Yes.

[04:05:09:13 - 04:05:10:04]
Speaker 28
 I think

[04:05:11:22 - 04:05:13:09]
Speaker 28
 it is because they're all sitting here.

[04:05:13:09 - 04:05:13:15]
Speaker 19
 Okay.

[04:05:14:19 - 04:05:20:12]
Speaker 19
 That's exactly what you're saying. That's what I'm looking for.

[04:05:20:12 - 04:05:26:16]
Speaker 15
 Sam, we're doing a cheer. Sorry, I will catch up with you in a sec. I'm going to work.

[04:05:26:16 - 04:05:29:11]
Speaker 1
 I said if I go missing, this is my lip imprint.

[04:05:32:02 - 04:05:33:11]
Speaker 19
 Thank you, guys. I'm just kidding.

[04:05:34:22 - 04:05:35:03]
Speaker 19
 Okay.

[04:05:37:16 - 04:05:39:16]
Speaker 19
 I'm just kidding. I'm just kidding.

[04:05:39:16 - 04:05:40:15]
Speaker 28
 Everybody,

[04:05:42:18 - 04:05:43:06]
Speaker 28
 this is fine.

[04:05:43:06 - 04:05:43:18]
Speaker 6
 I got it.

[04:05:46:00 - 04:05:47:19]
Speaker 27
 I'm on the side.

[04:05:47:19 - 04:05:49:11]
Speaker 6
 You said you're on the side. You said you're on the side.

[04:05:49:11 - 04:05:55:05]
Speaker 15
 We're going to do some use of. I think this might be your calling. I was so much fun. I can tell.

[04:05:58:13 - 04:05:59:05]
Speaker 1
 He's so wild.

[04:06:00:13 - 04:06:02:02]
Speaker 6
 I love you. I love

[04:06:03:06 - 04:06:03:09]
Speaker 6
 you.

[04:06:03:09 - 04:06:04:23]
Speaker 21
 You said get in the video.

[04:06:04:23 - 04:06:07:19]
Speaker 6
 I'll be shot. Get in the video.

[04:06:07:19 - 04:06:12:17]
Speaker 1
 Oh, it's going to get in. Everybody get in. Behind the scenes. You said everybody.

[04:06:13:19 - 04:06:16:21]
Speaker 28
 We're doing a cheer.

[04:06:18:16 - 04:06:22:05]
Speaker 2
 This is like a getting ready film and scene for me giving the cheers.

[04:06:23:11 - 04:06:27:05]
Speaker 19
 If I can get everybody to stand behind. Hello.

[04:06:28:11 - 04:06:28:19]
Speaker 1
 You're freaking

[04:06:30:02 - 04:06:31:07]
Speaker 1
 me out. I was trying to sound like you.

[04:06:31:07 - 04:06:31:23]
Speaker 21
 Stay

[04:06:33:02 - 04:06:33:07]
Speaker 21
 awake.

[04:06:34:11 - 04:06:36:12]
Speaker 28
 Play along. Play along.

[04:06:36:12 - 04:06:38:02]
Speaker 15
 Play along.

[04:06:38:02 - 04:06:38:20]
Speaker 19
 Yeah.

[04:06:41:09 - 04:06:43:05]
Speaker 27
 Okay.

[04:06:46:08 - 04:06:47:01]
Speaker 27
 Come over

[04:06:48:13 - 04:06:48:18]
Speaker 27
 here.

[04:06:48:18 - 04:06:49:20]
Speaker 2
 I'll put you next to me.

[04:06:49:20 - 04:06:51:11]
Speaker 6
 Aww. I need you

[04:06:52:19 - 04:06:53:05]
Speaker 6
 here.

[04:06:53:05 - 04:06:55:10]
Speaker 28
 I need you right here. You're my support.

[04:06:55:10 - 04:06:57:07]
Speaker 6
 He needs us brother.

[04:06:57:07 - 04:06:58:03]
Speaker 28
 Go on.

[04:07:00:11 - 04:07:01:21]
Speaker 28
 Are you ready? Okay.

[04:07:04:16 - 04:07:05:01]
Speaker 19
 Are

[04:07:06:02 - 04:07:07:20]
Speaker 19
 you what? You're my new job.

[04:07:07:20 - 04:07:09:10]
Speaker 28
 You got some back up here.

[04:07:12:06 - 04:07:13:21]
Speaker 1
 You'll come out. I'll come in soon.

[04:07:15:01 - 04:07:16:01]
Speaker 15
 I'll come in soon.

[04:07:17:12 - 04:07:19:12]
Speaker 1
 What did you say? I

[04:07:20:15 - 04:07:24:03]
Speaker 1
 know how to get you. I know how to get you. I know

[04:07:26:04 - 04:07:28:00]
Speaker 1
 how to fish in. You do.

[04:07:29:00 - 04:07:33:21]
Speaker 1
 That's a thing. That's why we have such a big sister relationship. You do things yourself.

[04:07:35:03 - 04:07:35:21]
Speaker 1
 I actually am.

[04:07:35:21 - 04:07:39:18]
Speaker 2
 I suck at cheers. I'm going to work.

[04:07:39:18 - 04:07:40:06]
Speaker 19
 I don't know.

[04:07:40:06 - 04:07:40:18]
Speaker 2
 I'm going to try.

[04:07:40:18 - 04:07:41:15]
Speaker 15
 You should

[04:07:43:01 - 04:07:45:23]
Speaker 15
 be... Let it out. You talk

[04:07:48:03 - 04:07:49:08]
Speaker 15
 from the heart. You know how to do it.

[04:07:50:11 - 04:07:51:12]
Speaker 15
 You're good with words.

[04:07:51:12 - 04:07:52:21]
Speaker 19
 You're chewing your head.

[04:07:53:23 - 04:07:58:06]
Speaker 15
 Just be like, everyone raise your glasses. Thank you for coming.

[04:08:01:12 - 04:08:03:06]
Speaker 27
 You'll be good. You can do it.

[04:08:05:06 - 04:08:10:11]
Speaker 15
 I'm like, raise your glasses. Thank you all for coming. This is for the show.

[04:08:11:15 - 04:08:13:13]
Speaker 15
 I want to raise your glasses.

[04:08:13:13 - 04:08:26:13]
Speaker 2
 I'm going to do two separate cheers. The first cheers is going to be for the show. And the second cheers is going to be completely for everybody. For you guys. Thank you for everything. For us. For everybody. Thank you for

[04:08:26:13 - 04:08:28:06]
Speaker 21
 everything.

[04:08:29:16 - 04:08:33:07]
 (Laughter)

[04:08:33:07 - 04:08:34:22]
Speaker 2
 I know, right?

[04:08:34:22 - 04:08:36:23]
Speaker 27
 Does anybody want to shout out for the cheering?

[04:08:36:23 - 04:08:39:14]
Speaker 6
 Everyone does. Oh, I love her.

[04:08:39:14 - 04:08:42:03]
Speaker 15
 Who's that? That's my friend.

[04:08:42:03 - 04:08:58:15]
Speaker 1
 I don't know who she is, but I love her. It was her. I love her. She's so cute. I love her. I don't know her. It's cute because it's like, that's our future. I'm looking at it. She's like us. And we need that. What's that? She's like,

[04:08:59:19 - 04:09:00:15]
Speaker 1
 everyone needs a shot.

[04:09:00:15 - 04:09:02:00]
Speaker 15
 They're so cute.

[04:09:03:01 - 04:09:04:06]
Speaker 15
 That's

[04:09:04:06 - 04:09:04:07]
Speaker 1
 what me

[04:09:05:08 - 04:09:05:22]
Speaker 1
 and Danielle.

[04:09:05:22 - 04:09:06:22]
Speaker 21
 Those are my people.

[04:09:06:22 - 04:09:08:13]
Speaker 1
 I love them.

[04:09:09:18 - 04:09:13:19]
Speaker 1
 I need like a man. Oh, when I went. I love them.

[04:09:13:19 - 04:09:15:01]
Speaker 2
 Mark and Lisa.

[04:09:16:04 - 04:09:18:09]
Speaker 6
 Lisa, right? We're talking about which we love you.

[04:09:18:09 - 04:09:20:09]
Speaker 1
 Yeah, we love you guys.

[04:09:20:09 - 04:09:21:09]
Speaker 15
 You guys are so cute.

[04:09:21:09 - 04:09:22:22]
Speaker 28
 They taught me how to play tennis.

[04:09:25:22 - 04:09:27:15]
Speaker 6
 Oh, y'all are going to win.

[04:09:28:16 - 04:09:28:21]
Speaker 6
 She's

[04:09:31:10 - 04:09:33:15]
Speaker 6
 telling me to shoot. She's telling me to shoot. She's so generous for the shot.

[04:09:35:02 - 04:09:37:21]
Speaker 15
 Oh my God, my feet. I need to get these heels off.

[04:09:37:21 - 04:09:39:06]
Speaker 21
 My heels.

[04:09:39:06 - 04:09:39:15]
Speaker 6
 You're going to hang out with

[04:09:41:04 - 04:09:42:19]
Speaker 6
 me, right? Yeah, okay, good.

[04:09:43:22 - 04:09:47:12]
 (Singing)

[04:09:47:12 - 04:09:52:13]
Speaker 19
 Where can I to find a way to make some difference?

[04:09:52:13 - 04:09:53:06]
Speaker 2
 Take dinner?

[04:09:54:20 - 04:09:56:01]
Speaker 2
 Oh, Justin is taking dinner.

[04:09:56:01 - 04:09:57:10]
Speaker 21
 Oh, how about that?

[04:09:59:07 - 04:10:01:02]
Speaker 2
 He didn't know he was teaching lawn dancing tonight.

[04:10:01:02 - 04:10:05:08]
Speaker 27
 I did not know that business. Somehow, a few people already knew that was happening. Right.

[04:10:06:19 - 04:10:11:06]
Speaker 6
 You know, some people are just very shy. I didn't know anything.

[04:10:12:12 - 04:10:13:14]
Speaker 27
 We just know things.

[04:10:15:03 - 04:10:19:07]
Speaker 15
 No, that was perfect. You did great. I want to do it again.

[04:10:22:06 - 04:10:25:21]
 (Singing)

[04:10:25:21 - 04:10:31:08]
Speaker 1
 Oh, I just took a shot by the way. Behind closed doors I just did. I did. You said JV one.

[04:10:32:13 - 04:10:34:15]
Speaker 15
 I need to get these heels off.

[04:10:34:15 - 04:10:35:09]
Speaker 21
 I know.

[04:10:35:09 - 04:10:36:06]
Speaker 6
 Justin Lee.

[04:10:37:12 - 04:10:37:18]
Speaker 28
 Oh,

[04:10:39:07 - 04:10:41:08]
Speaker 28
 Tennessee back roads? Hey.

[04:10:43:11 - 04:10:43:12]
Speaker 28
 Justin

[04:10:45:19 - 04:10:47:17]
Speaker 28
 Lee, Tennessee back roads.

[04:10:49:09 - 04:10:50:02]
Speaker 2
 And then I'll put

[04:10:51:12 - 04:10:55:09]
Speaker 2
 line dance. No, I'm going to put the date that Tennessee became a state.

[04:10:57:10 - 04:10:58:13]
Speaker 2
 17 something.

[04:11:01:00 - 04:11:09:14]
Speaker 2
 Whatever it is, I'm going to put it on you. I have no idea when Tennessee Kentucky was 1792. I can't tell you that much.

[04:11:09:14 - 04:11:10:07]
Speaker 27
 What?

[04:11:10:07 - 04:11:12:12]
Speaker 2
 Kentucky was 1792.

[04:11:14:05 - 04:11:14:13]
Speaker 28
 Yeah.

[04:11:14:13 - 04:11:18:02]
Speaker 19
 All right. Three, two, one. Action.

[04:11:18:02 - 04:11:22:21]
Speaker 2
 So everybody, I just want to I want to take a second to

[04:11:24:01 - 04:11:25:01]
Speaker 2
 cheers to

[04:11:26:08 - 04:12:16:04]
Speaker 2
 this week. It's been amazing. I want to thank these amazing women for coming from all around the United States to be here to help me fulfill this dream to to help brides to to empower women to feel beautiful and seen and heard and accomplished. And I just want to take a minute to think Sarah and Garrison for being a part of a lot when those to just be in this moment with you guys. We know that, you know, life can life can knock us all out. They can hit us from the left from the right. And we just want to thank you guys for being open and being able to share your story. I'll just say that, you know, when you guys came to what you didn't you didn't get to come. But

[04:12:17:15 - 04:12:21:15]
Speaker 2
 Sarah, when you came to the store and you walked in and I got to meet you for the first time,

[04:12:23:10 - 04:12:25:16]
Speaker 2
 it really was a blessing to me because

[04:12:27:15 - 04:12:56:14]
Speaker 2
 I know how I know how much this moment meant to you. You know, going from, you know, just going somewhere and buying the dress that you could afford to actually having the girls come and be a part of your special moment. Be your sisters, you know, and to allow us to style you and find that dress that was going to make you feel empowered and pretty and garrison to tear up and cry whenever you're walking on the aisle. I got to see it before you wrote.

[04:12:58:09 - 04:13:07:08]
Speaker 2
 It just honestly for me, this was a dream that I've had for a long time. And I didn't know that

[04:13:08:13 - 04:13:11:03]
Speaker 2
 in the middle of it that I was going to ball like a baby like I did.

[04:13:12:13 - 04:13:35:12]
Speaker 2
 But it was a real thing. This whole moment was real for me. And, you know, when you bring your dream together, you never know how God is going to bring amazing people together. And this is all God. Everybody here to celebrate you guys. They are here because God brought us together to celebrate love and union and what he's getting ready to do in your life.

[04:13:36:14 - 04:13:56:17]
Speaker 2
 And so I'm just thankful that they were able to come here to be able to connect to you guys and give you new relationships, new friends. These people are my family. And that's why they're here. These girls family. And this is my family. And so we just want to give an awesome Tennessee cheer to you guys. Can we give a cheer to these guys?

[04:13:56:17 - 04:14:00:05]
Speaker 15
 Cheers to y'all! Cheers!

[04:14:02:10 - 04:14:05:10]
Speaker 1
 Cheers to y'all! And a little you! Cheers to all of us!

[04:14:05:10 - 04:14:07:09]
Speaker 2
 Cheers to all of us!

[04:14:08:11 - 04:14:12:15]
Speaker 2
 And then this real cheer is for me.

[04:14:13:18 - 04:14:16:04]
Speaker 2
 A lot of you guys, some of you didn't even know why you were here.

[04:14:19:20 - 04:14:21:19]
Speaker 28
 I don't think anybody knew finally we were here.

[04:14:21:19 - 04:14:24:20]
Speaker 2
 But I'm okay with that because I'm a man of surprise.

[04:14:26:20 - 04:14:31:08]
Speaker 2
 But I do, first of all, want to thank Olu. Olu, thank you so much.

[04:14:32:09 - 04:14:40:05]
Speaker 2
 Thank you. Thank you. For opening up your beautiful home and trusting me and my friends to be here.

[04:14:42:03 - 04:14:45:16]
Speaker 2
 Yes. To celebrate, you know, this

[04:14:47:11 - 04:15:02:06]
Speaker 2
 television series means so much to me because I had to give up a lot to get to this point. And a lot of people that really don't, there's some people in here that know my story. They know my real story. And they know how hard I had to work to get to this point.

[04:15:03:18 - 04:15:20:10]
Speaker 2
 Tim and Timmy and their crew, we do a men's group together. And meeting these guys, it was totally, always said, people ask me, "How did you get into Bridal?" I didn't choose Bridal. Bridal chose me. "How did you get to Tennessee?" I love, everybody knows, I love Kentucky. I'm a Kentucky man through them.

[04:15:21:19 - 04:15:32:09]
Speaker 2
 God brought me to Tennessee and I've been able to meet so many awesome and amazing people. You guys have no idea. So I live in Columbia.

[04:15:33:16 - 04:15:35:19]
Speaker 2
 Probably about five years ago,

[04:15:36:20 - 04:15:38:02]
Speaker 2
 Sherry and Sergio

[04:15:39:06 - 04:15:44:08]
Speaker 2
 tried to convince me to open up a Bridal store in a place called Columbia, Tennessee.

[04:15:45:15 - 04:15:52:23]
Speaker 2
 And I was like, "Oh, no, I'm going to be in Nashville. I'm going to be where it's booming." And this was before Nashville was saturated with Bridal stores.

[04:15:54:05 - 04:16:09:15]
Speaker 2
 And so it was kind of one of those things. I feel like God knew that it wasn't the time, but he knew that it was the destination. And so here I am. I end up on a random somehow in Columbia, Tennessee. And I forgot the name of the town at the time.

[04:16:11:01 - 04:16:39:08]
Speaker 2
 And so one morning, it was like three o'clock in the morning, and I woke up and you know how most of us here are creators. You know how it is when God puts something on your heart and it's time to create, you get up, you write it down, you take a picture, you do it. Right? I woke up, I went to my studio, and I was like, "God must have a song for me." And he's like, "No, it's not a song. It's not anything like that." So I woke up and I drove to my most favorite place in the world to eat whenever it's late, which is Waffle House.

[04:16:41:06 - 04:17:16:21]
Speaker 2
 And I went to Waffle House, and nothing came to mind. And so I was on my way back home, and God clearly said, "I need you to open up a Bridal store in Columbia, Tennessee." I've been in Bridal for five years, and my ex-partner and I, we separated in business. And I was kind of like in the desert for a while. God clearly said, "Open the store in Columbia, Tennessee." So I called Sergio and Sherry, and I said, "Hey, what was the name of that town? Can you believe I'm in Columbia, Tennessee?" And God put it on my heart to open up a Bridal store five years after they told me that I should go to Columbia, Tennessee.

[04:17:16:21 - 04:17:20:20]
Speaker 21
 So

[04:17:20:20 - 04:18:00:09]
Speaker 2
 along the way in Columbia, I've met so many amazing people. These girls are my friends. These are some of my most precious people in my life. And even just God bringing us together. I had a whole like 10-girl lineup for this project. And God's like, "No, you need to dumb it down a little bit, because these women right here, they care about you, they love you, and they want to see you succeed, and you want to see them succeed, and we all know each other's story, and we've been through it." And so God chose these women to be able to do this project, this TV show. And so...

[04:18:00:09 - 04:18:01:15]
Speaker 28
 Wait, material?

[04:18:02:20 - 04:18:03:01]
Speaker 21
 Sorry,

[04:18:04:05 - 04:18:04:15]
Speaker 21
 I'm wrong.

[04:18:04:15 - 04:18:10:15]
Speaker 2
 I'm with Kentucky. You give me a bourbon in a microphone, you know? Baptist Church around here.

[04:18:10:15 - 04:18:13:22]
Speaker 28
 So anyway, I just want to say

[04:18:13:22 - 04:18:20:14]
Speaker 2
 thank everybody for being here. My producer, this man right here makes me sound like...

[04:18:22:17 - 04:18:43:15]
Speaker 2
 We got some new projects that we're working on. Justin, my man Justin came in here, he was with the line dance manager Mark, my great friend. This guy right here makes me feel like I can conquer the whole world. Literally. If I call Mark and I'm like, "Hey man, I'm down," he's like, "Bro, pick it up, bro, you got this. Go to the gym, hit some weights."

[04:18:43:15 - 04:18:46:00]
Speaker 19
 So, like a thousand people don't drink beer down.

[04:18:46:00 - 04:18:46:20]
Speaker 2
 Exactly.

[04:18:48:03 - 04:19:27:15]
Speaker 2
 And that's the thing, God puts people in your life that when you're down and you're beat up and you're out, there's people in your life that you can call to be inspired. And really, just to be honest, looking around the room, you guys are my friends, you guys are my... I'm from Kentucky. You know, I don't have bloodline here, so the people that are here, I love you, I appreciate you, thank you for being here, taking time out of your lives to do this. You guys have no idea how much, like even when we were filming, their story is real. This is a real life. My goal was to help brides get married who can't afford their dream drinks. And Garrison,

[04:19:30:12 - 04:19:33:19]
Speaker 2
 I met this guy at a cigar shop. At the cigar bar.

[04:19:35:03 - 04:19:37:14]
Speaker 2
 And we were talking about God, we were talking about Jesus.

[04:19:38:17 - 04:19:39:07]
Speaker 2
 And

[04:19:40:23 - 04:19:50:15]
Speaker 2
 I go to this coffee shop and she works at the coffee shop. I had no idea they worked together. But she memorized it. She knows my drink that I get at the coffee shop. And

[04:19:51:15 - 04:19:54:00]
Speaker 2
 so once I started putting two and two together,

[04:19:55:18 - 04:20:08:19]
Speaker 2
 I called Garrison one day, my truck was having problems, and I thought it was my battery, so I said Garrison. I literally called like ten people, and I said wait, I met Garrison, maybe he'll come do it, because he had a good heart.

[04:20:09:19 - 04:20:17:01]
Speaker 2
 So I called Garrison, and I said Garrison, hey buddy, I need a favor. My truck's not starting, I think I need a battery.

[04:20:18:08 - 04:20:20:07]
Speaker 2
 Can you come pick me up? He said yeah bro, I got you.

[04:20:21:15 - 04:20:25:01]
Speaker 2
 They come to pick me up, and we had this whole escapade day.

[04:20:26:22 - 04:20:30:19]
Speaker 2
 And it led to him me asking him, tell me your story.

[04:20:31:20 - 04:21:08:16]
Speaker 2
 And he told me his story, and he said, yeah, you know, he told me about Sarah. And I was like, oh wait, that's your girl? Oh shoot, that's crazy, you know. And then I said, tell me about you guys. And he told me how she was a single mom. He came into her life, and he has been a great role model and man to her children, and friend, and just a great guy. And then he said, you know, he's like, yeah, and I asked him, I said, well why haven't you married her yet? You know, that's the question to me. I'm from Kentucky, so I'm like, why ain't y'all married? You know? And he said, you know, it's just been tough.

[04:21:10:02 - 04:21:39:20]
Speaker 2
 You know, it's been tough. And financially and all the things, sorry for making you proud. But guess what happened when you get my hands. And so I said, you guys are going to be perfect for this thing that's going on. And he's like, what? And I said, I want to sit down with both of y'all. And we sat down and we talked, I met there with kids. And they're awesome kids. At first it was like a rough patch, and then I started to play video games, and they fell in love with me. I'm pretty sure I'm going to be in their son's best man.

[04:21:42:00 - 04:21:59:23]
Speaker 2
 And then they agreed to do this. It's very humbling. And you know, people, we can put our pride, they put their pride aside the whole thing to be a part of this project. And when we walked in, like even picking the dresses, like I literally was like, all right, I'm going to find dresses that I think Sarah was like.

[04:22:01:08 - 04:22:08:18]
Speaker 2
 And I had no idea, but I just put it in God's hands and she came to the store and she literally like found her dream dress.

[04:22:10:02 - 04:22:12:10]
Speaker 15
 Oh, yeah. It looks amazing. Right. Yeah.

[04:22:12:10 - 04:22:15:14]
Speaker 2
 She really found her dream dress. Right.

[04:22:16:17 - 04:22:17:15]
Speaker 2
 And

[04:22:19:06 - 04:22:20:06]
Speaker 2
 it made me cry a lot.

[04:22:21:22 - 04:22:22:16]
Speaker 2
 I really cried.

[04:22:22:16 - 04:22:24:20]
Speaker 28
 It really was real tears. It wasn't fake.

[04:22:26:02 - 04:22:26:23]
Speaker 15
 I tear it up.

[04:22:26:23 - 04:22:27:22]
Speaker 28
 I tear it up.

[04:22:27:22 - 04:22:30:18]
Speaker 2
 Because I realized like, whoa, this is bigger than the whole thing.

[04:22:32:03 - 04:22:33:22]
Speaker 2
 You know? And so

[04:22:35:06 - 04:22:37:21]
Speaker 2
 again, thanks for letting us be a part of that moment. It was special.

[04:22:39:13 - 04:23:06:05]
Speaker 2
 These people love you like they love me. And we're here celebrating. We're praying for you guys. God is going to do amazing things in your life. He loves you. He cares about you financially, physically, emotionally. He's going to do so many cool things in your life. So to all my friends and my family, Olu, thank you for allowing us to be here. Cameron, my production team, I love you all. Thank you. And I just want to give a big salute and a cheers to you guys.

[04:23:06:05 - 04:23:12:13]
Speaker 15
 Cheers, everyone. Cheers. Cheers to Dom. Cheers. And that's a wrap.

[04:23:12:13 - 04:23:13:04]
Speaker 6
 That's a wrap.

[04:23:15:09 - 04:23:15:14]
Speaker 21
 Yeah.

[04:23:16:20 - 04:23:17:21]
Speaker 21
 Yeah. I'm going to do a wrap.

[04:23:19:22 - 04:23:20:05]
Speaker 15
 Yes.

[04:23:21:13 - 04:23:25:00]
Speaker 6
 Yes. These heels are coming off. I'm sorry, Jim. I can

[04:23:27:07 - 04:23:27:16]
Speaker 6
 not ask.

[04:23:29:05 - 04:23:29:08]
Speaker 6
 Take

[04:23:30:18 - 04:23:32:05]
Speaker 6
 this. I want to get to know you.

[04:23:32:05 - 04:24:09:12]
Speaker 4
 element into ours. So what do you think that's gonna go?

[04:24:10:18 - 04:24:43:10]
Speaker 1
 My initial thoughts bringing the bride into our world is it's exciting. I mean, we live an exciting life getting to help people and I feel like, you know, it's a very happy environment. So whatever the bride's going through, you know, it's very stressful planning a wedding and, you know, life in general. So we get to take all her worries away for a day and just make her feel great and get, she gets to see our side of life, which is happy and fun. And that's a good feeling to be able to, you know, help somebody and

[04:24:44:11 - 04:24:46:07]
Speaker 1
 make them feel happier, even happier.

[04:24:47:21 - 04:25:06:18]
Speaker 4
 And she is going through a lot of stresses being a mom, planning a wedding. She lives in a concert set of payoffs. And how do you feel navigating bringing somebody away from that? And how do you really help them transition into one part of life into another?

[04:25:08:00 - 04:25:22:11]
Speaker 1
 Sarah definitely has a chaotic lifestyle and she is trying to find a balance. I feel like I'm able to give her more of a, you know, life balance outside of her home life.

[04:25:24:02 - 04:25:29:07]
Speaker 1
 Not so much. That's a hard question. I feel like I need to redo that.

[04:25:29:07 - 04:25:31:13]
Speaker 4
 I don't know what I asked.

[04:25:31:13 - 04:25:37:04]
Speaker 1
 You asked me how do I transition her out of her home life?

[04:25:37:04 - 04:25:52:19]
Speaker 4
 How do I transition from chaotic home life into being... Don't re-ask it. I'm going to bring her comfort. She's got kids, she's in the same life. I guess not single life.

[04:25:52:19 - 04:25:57:07]
Speaker 1
 Yeah, I mean, just talk to her about her life and then change the subject.

[04:25:57:07 - 04:26:04:06]
Speaker 4
 It's kind of a... From a chaotic wedding planning motherhood into being a wife and going into a new stage of life.

[04:26:06:15 - 04:26:10:09]
Speaker 4
 What advice do you give her from her with her transition?

[04:26:11:17 - 04:26:35:00]
Speaker 1
 So the advice I would give Sarah in transitioning and enjoying the experience is to just let loose, have fun, enjoy every moment that we bring her into, and just try to take her worries away. Just offer her food and drinks and get her to bring up happy memories of her and her fiancé to each other.

[04:26:36:14 - 04:26:44:04]
Speaker 1
 Just try to make her have as much fun as possible. Make her laugh and just take anything that's on her mind away.

[04:26:50:12 - 04:26:52:02]
Speaker 1
 That's very good at this vlog.

[04:26:52:02 - 04:26:55:09]
 (Laughter)

[04:26:55:09 - 04:26:59:00]
Speaker 4
 Thank you. We'll cook it for you in a second.

[04:27:03:17 - 04:27:14:08]
Speaker 4
 She is going to... Sarah's going to feel a little bit out of her element being here and being around all these people. How do you plan on helping her feel comfortable and being welcomed?

[04:27:15:12 - 04:27:34:17]
Speaker 1
 Sarah's definitely going to feel a little out of her element going through this process. I've always been this way with everyone. I make them feel comfortable. I try to create a bond right off the start and just ask them about themselves and their day and

[04:27:35:20 - 04:27:45:19]
Speaker 1
 what's going on in their life. I just try to make them feel comfortable. I think that helps their worries go away and it enables them to just relax and have fun and enjoy

[04:27:46:22 - 04:27:56:22]
Speaker 1
 the experience. When they're comfortable. We're strangers coming into their life for a day. Just trying to create some type of bond with them I think really helps.

[04:27:58:09 - 04:28:01:00]
Speaker 1
 That's fine. Am I done?

[04:28:02:19 - 04:28:03:09]
 (Laughter)

[04:28:03:09 - 04:28:07:17]
Speaker 1
 I know you wanted to talk about the bond. I feel like my throat is so scratchy today.

[04:28:07:17 - 04:28:10:05]
Speaker 4
 I wonder if there's a part of the same bond with types of things like...

[04:28:10:05 - 04:28:11:16]
Speaker 1
 Yeah.

[04:28:11:16 - 04:28:15:17]
 (Laughter)

[04:28:15:17 - 04:28:17:11]
Speaker 1
 I know. I'm like, you know.

[04:28:17:11 - 04:28:18:23]
 (Laughter)

[04:28:18:23 - 04:28:23:05]
Speaker 4
 You don't have enough time for that? What do you want me to do? Okay.

[04:28:24:10 - 04:28:31:07]
Speaker 4
 We're kind of getting... Act like we're doing the party. He's going to ask you a question about the party and just like make something fun and fly like... Act like you're in jail already.

[04:28:31:07 - 04:28:35:08]
Speaker 1
 Ask him about the party? We're in party mode. We just asked you from the party mode.

[04:28:35:08 - 04:28:37:13]
Speaker 4
 You can't talk about him. I'm a line dancer.

[04:28:37:13 - 04:28:38:23]
 (Laughter)

[04:28:38:23 - 04:28:41:02]
Speaker 1
 Oh, I actually met him so I can talk about him.

[04:28:41:02 - 04:28:41:15]
Speaker 4
 Okay.

[04:28:41:15 - 04:28:42:04]
Speaker 1
 Yeah.

[04:28:42:04 - 04:28:46:18]
Speaker 4
 Okay. Line dancer? I'm kind of a line dancer. I can cook up that.

[04:28:46:18 - 04:28:47:04]
Speaker 1
 Yeah.

[04:28:47:04 - 04:28:52:19]
Speaker 4
 So there's a line dancer here tonight. How do you feel? Have you ever line danced before? What was that experience like?

[04:28:52:19 - 04:29:01:17]
Speaker 1
 There is a line dancer here tonight and I'm excited about it because I used to take line dancing classes as a kid. My mom made me do it.

[04:29:01:17 - 04:29:02:19]
 (Laughter)

[04:29:02:19 - 04:29:15:23]
Speaker 1
 And I'm excited to get back into it. I think it's such a fun thing to do and you know music is a part of my life so dancing and music and drinks and it's flowing. It's fun. It's a good night.

[04:29:17:07 - 04:29:21:04]
Speaker 4
 And how are the vibes of the party right now? What would you say the vibes are?

[04:29:21:04 - 04:29:35:16]
Speaker 1
 I would say everyone's just happy to be out. You know it's great weather and everyone's dressed beautifully and we're all happy. It's been a great experience for everyone. Everything has flowed smoothly so it's fun. It's great.

[04:29:35:16 - 04:29:59:18]
Speaker 3
 So far I really like Sarah. She's really cool. I know she's out of her environment, but it's going way better than I expected, to be honest. Her personality really meshes with us. Even though she's a little bit mellow, I was expecting her to be like way more shy, but she's really cool and she knows what she wants. I didn't expect her to know what she wanted and she does. Um, yeah, I think I'm digging Sarah for sure.

[04:30:02:16 - 04:30:04:11]
Speaker 4
 The energy of the party, how would you describe it?

[04:30:05:23 - 04:30:19:04]
Speaker 3
 It's fine. Wait. So the energy of the party tonight is really fun. I'm here for work and I'm trying not to have too many drinks because then I'll be on the dance floor. I'm not trying to do all that, but

[04:30:20:11 - 04:30:28:03]
Speaker 3
 yeah, the energy is getting more intense and I'm ready for it to get popping now. Yeah.

[04:30:28:03 - 04:30:36:17]
Speaker 4
 How are you tonight?

[04:30:38:10 - 04:30:43:15]
Speaker 3
 On a scale from zero to Juicy J, like a four.

[04:30:45:00 - 04:30:59:08]
Speaker 3
 Ask the question. Oh, how drunk? No, you're not asking how drunk I am. You're asking how I'm feeling. How are you feeling? Oh, I'm feeling great tonight. Um, I'm just really excited to be here and really celebrate Sarah. Like I feel like that's, that's probably the,

[04:31:00:15 - 04:31:20:02]
Speaker 3
 like, I don't know how to explain it whenever you're like working and doing what you love at the same time. It's not really work. So I feel great, but I'm working. So it's like, I'm trying to be reserved and not show too much excitement because we're here for Sarah. So it's like, um, I'm trying to feel great without being too great because it's about Sarah.

[04:31:20:02 - 04:31:30:06]
Speaker 4
 And what's it like being with all the girls tonight after all the work has been done? You guys are enjoying each other's energy and enjoying the moment. What does that feel like after all the work has been done?

[04:31:30:06 - 04:31:44:07]
Speaker 3
 With all the work finally being done, I, you know, I always love hanging out with my girls. Um, yeah, they're my coworkers, but whenever we get to come together and do things like this, it's just like the bang at the end and it's, it's perfect. It's always a great time.

[04:31:45:13 - 04:31:47:08]
Speaker 4
 And what would you say your favorite part of this night?

[04:31:47:08 - 04:31:58:18]
Speaker 3
 My favorite part of the night was the line dancing for sure. I've never done anything like that before. So doing that with Jason. Yeah, Jason, it was fun.

[04:31:58:18 - 04:32:00:10]
Speaker 4
 Are you planning on doing line dancing again?

[04:32:00:10 - 04:32:03:13]
Speaker 3
 Absolutely. I'm going to do line dancing again. I'm a pro now.

[04:32:06:13 - 04:32:06:04]
Speaker 4
 love

[04:32:08:17 - 04:32:08:19]
Speaker 4
 it.

[04:32:08:19 - 04:32:44:22]
Speaker 2
 This is when we decided to put this together, our goal was to make sure that the bride and the groom felt noticed, seen, celebrated. And I think one of the biggest goals was to get them out of their comfort. They're so used to being at home, working, to pay bills. And we wanted them to be a part of the special. So we wanted to get them around our friends and kind of show them how we celebrate and celebrate things well. So just putting them in a different environment, I think it's going great. I think they're happy, they're smiling,

[04:32:46:00 - 04:33:01:11]
Speaker 2
 they got babysitters, they had on watch when they were kids. So I think for me to give them a big night and something that they'll never forget for the rest of their lives. And being around cool live dancers and singers and just

[04:33:01:11 - 04:33:03:02]
Speaker 2
 people who can possibly,

[04:33:04:10 - 04:33:18:02]
Speaker 2
 another thing was like, I want to help them get to where they want to go in life. And so another thing was using this opportunity to help them meet new people, make new friends. And that's what they're doing, they're out celebrating and making new friends. I can't be more happy.

[04:33:20:11 - 04:33:20:22]
 (Blank Audio)

[04:33:20:22 - 04:33:26:00]
Speaker 4
 Sarah's asking out for help when so is her husband. How do you think, what do you think they're feeling right now?

[04:33:26:00 - 04:33:43:07]
Speaker 2
 With Sarah and Garrison being out of the element, I think it doesn't hurt that they probably had a couple of martinis or whatever. So I think that helped them a little bit. But yeah, when they first walked in, I think it was overwhelming. And I think

[04:33:44:10 - 04:34:03:01]
Speaker 2
 when they saw us, it was like, okay, my people, my tribe, right? Especially Sarah, because we had to make some moments with her when we were in the store, and so I think we became her family. And even though the girls got to meet Garrison at their home, I think even he, when he saw us, they kind of,

[04:34:04:03 - 04:34:04:22]
Speaker 2
 so I think

[04:34:06:00 - 04:34:10:23]
Speaker 2
 at the end of the day, I think now they're doing fine, because they're probably like one or two drinks in a day.

[04:34:12:16 - 04:34:14:03]
Speaker 2
 But I think they're good.

[04:34:15:08 - 04:34:23:03]
Speaker 4
 Now that everything has been said and done, and all the work is over with, or just celebrate, how do you feel knowing that everything's done according to plan?

[04:34:24:14 - 04:34:26:03]
Speaker 2
 I think, I'll tell you what,

[04:34:27:19 - 04:34:29:04]
Speaker 2
 now that we've gotten to

[04:34:30:05 - 04:34:33:06]
Speaker 2
 this point in this experience for the bride,

[04:34:35:15 - 04:34:39:04]
Speaker 2
 I feel great. I feel like we've accomplished our mission.

[04:34:41:04 - 04:35:03:20]
Speaker 2
 We had a goal, the goal is set, and we embarked on this journey together as a team to make someone feel special and loved and cared for. And here we are celebrating them in a moment that, like I said, it'll last forever in our inner mind, so never forget this. And so to

[04:35:05:09 - 04:35:10:16]
Speaker 2
 think back whenever we came together to put this opportunity together,

[04:35:11:17 - 04:35:14:02]
Speaker 2
 I think to see it all kind of manifest,

[04:35:15:11 - 04:35:19:02]
Speaker 2
 to be at the store and to see Sarah's tears,

[04:35:20:10 - 04:35:25:11]
Speaker 2
 to be here, to see her smile. And like I said, we gave you love and celebrate, I think

[04:35:27:09 - 04:35:28:21]
Speaker 2
 I'm gonna want to enjoy it.

[04:35:30:19 - 04:35:35:15]
Speaker 2
 I don't know how long it took us to get here, and now that we're here, it's gonna be amazing.

[04:35:53:04 - 04:35:53:04]
 (Inaudible)

[04:35:53:04 - 04:35:53:09]
Speaker 2
 Yeah,

[04:35:54:22 - 04:36:16:23]
Speaker 2
 so as the creator, as the owner of the store, emotionally I'll tell you how I feel. I kinda am at a place where I don't think that it isn't doing really it. I don't think I'll really actually understand exactly what we're doing until I'm sitting on my back

[04:36:18:19 - 04:37:06:10]
Speaker 2
 porch and looking at the stars. I'm skipping time with God, and then he gives me that aha moment. But I think right now I'm just excited. I'm in the moment, it feels very, I'm surrounded by friends and family, and I've allowed the couple to be surrounded by new friends and family. And so I think when I get to a place where I'm in my quiet zone, I think it'll really, I'll tell you what though, I'll say whenever we were at the store and to see Sarah's tears, I think being around them in that moment and hearing their story, I think that's where I felt it the most. I think that's where I felt the presence of God and what we're doing here. So yeah, I think it'll make me, it just has to make me completely addicted.

[04:37:08:05 - 04:37:11:17]
 (Blank Audio)

[04:37:14:16 - 04:37:15:08]
Speaker 2
 So then you ready?

[04:37:15:08 - 04:37:16:14]
 (Blank Audio)

[04:37:34:22 - 04:38:06:18]
Speaker 1
 I'm feeling amazing. I have so much gratitude today and just seeing her glow and seeing her feel beautiful, just kind of retouching on that as well. It's like, I feel excited as a team what we've come together to do. And it's something so much bigger, a part of just marriage and helping, you know, newlyweds that are struggling financially to, you know, say yes to the right down for them. And I'm just really excited, so much gratitude. I'm excited to have fun tonight, you know, and really celebrate, so.

[04:38:09:19 - 04:38:11:00]
Speaker 4
 How is

[04:38:12:03 - 04:38:21:00]
Speaker 4
 the night with the two hosts? What does it feel like with them? Now that we've worked with them, we have two friends, what does it feel like working with them and everything being done?

[04:38:21:00 - 04:39:14:22]
Speaker 1
 Honestly, I like getting to know them since then moving to Nashville, like they're wonderful. Like I love Danielle and in the past we had mutual friends, so we knew of each other and she's just such a sweet angel and just such a positive person in a light. And it's so nice having her in the room when we're helping, you know, somebody say yes to their dream gown because she brings that positive energy and that light. And you know, same with Muff, she's very detail oriented. It's really nice having her behind the scenes of like the gown details and really helping the right person find their right dress for the right dress that is curated to them. So, you know, I think they kind of, them being in the room and through this journey with me, it's like, I always joke, I'm like, we're like the Powerpuff Girls. I mean, all three of us are changing lives and it's just so amazing getting to be a part of this with such amazing women.

[04:39:15:22 - 04:39:19:16]
Speaker 4
 There's a lot of fun dancing tonight. How did you feel about the line dancing? Can you do it?

[04:39:21:00 - 04:39:34:02]
Speaker 1
 Honestly, when it comes to the line dancing, I can't say that I'm a pro at it, but I tried. I did my thing. I have been one time in my life and I never even took lessons. I just went in there and pretended I knew what I was doing,

[04:39:35:06 - 04:39:43:16]
Speaker 1
 which is life, but I love to swing dance and I'm hoping at some point in the future, us girls go swing dancing and I can show them some of my moves.

[04:39:45:11 - 04:39:54:16]
Speaker 4
 And what do you say the energy of tonight was with Sarah getting out of her element and the part is doing well? How do you feel her going and what do you think everyone reminds up?

[04:39:56:02 - 04:40:07:10]
Speaker 1
 I think everybody's just in a really excited place. I think we're truly at a state of just celebrating and I think that's what makes the energy so good in this moment is

[04:40:08:15 - 04:40:20:13]
Speaker 1
 everybody is just on a high and it's just the snowball effect of what's to come of this team and what we're gonna do and this is only the beginning. I just literally get chills right now.

[04:40:21:19 - 04:40:23:05]
Speaker 1
 It's kind of getting emotional.

[04:40:23:05 - 04:40:28:19]
Speaker 4
 And what do you hope to see in the next bride that we bring up?

[04:40:30:06 - 04:41:05:07]
Speaker 1
 I mean, every bride is different, right? So every dress is the right dress for the right person, kind of like what I touched on earlier. But I can't say that there's one thing in specific that I'm looking for. I think the bride will find us and I'm excited for God to align us with the right person that needs the help and is seeking to find a dress and that we can use our resources to help them. So I can't say there's one thing in specific but it's the same thing for everyone which is I can't wait to make everyone feel so beautiful and leave hopefully them in tears when they find their dress.

[04:41:05:07 - 04:41:16:15]
Speaker 4
 And seeing Sarah and Gary's dress story, does that make you hope that you can find someone and what is that? What kind of relationship can't change when you're in an everything world?

[04:41:16:15 - 04:41:58:17]
Speaker 1
 Yeah, of course, yeah. Well, my parents, they have been together for like over 30 years and I'm one of six kids and I really saw the covenant of marriage and how important that is because they've chose to stay together through all these years. So I'm 28 and I'm single, very good. But I think through seeing their love story and just seeing like the little details of how he writes or love songs and stuff like that, it's like the highest form of love on a vibrational scale is consideration and it's somebody that's thoughtful and shows up in a little moment. So they really inspired me with their love story in the way that it inspired me what I'm looking for as someone that truly sees me and the little moments.

[04:41:58:17 - 04:41:58:17]
 (End of transcript)
